#ifdef HAVE_CONFIG_H
# include  "config.h"
#endif

#include  "soccer_manager.h"
#include  "sserver_player_connection.h"
#include  "debug_client_connection.h"
#include  "sserver_param.h"
#include  "field_recog.h"
#include  "field_recog_interface.h"
#include  "soccer_option_analyser.h"
#include  "command_queue.h"
#include  "command_queue.h"
#include  "soccer_action.h"
#include  "debugstream.h"

#include  "autogen_act_test_team.h"
#include  "autogen_act_test_team2.h"
#include  "autogen_act_test.h"

#include  <iostream>
#include  <cstdlib>
#include  <cfloat>
#include  <csignal>
#include  <stdexcept>
using namespace std;

#ifndef RETSIGTYPE
  typedef void RETSIGTYPE;
#endif


// for signal
static	SServer_Player_Connection *
			sig_serv = static_cast<SServer_Player_Connection *>(0);
static	RETSIGTYPE	signal_handler( int );

static
RETSIGTYPE   signal_handler( int )
{
	if ( sig_serv )
	{
		sig_serv -> send_bye();
	}

	exit( 0 );
}


int    main( int  argc ,  char *  argv[] )
{
	try
	{
		ios::sync_with_stdio();

		cout.precision( DBL_DIG );
		cerr.precision( DBL_DIG );

		Soccer_Option_Analyser
			opt( "test" /* default team name */ ,
			     false  /* default is field player */ );

		if ( ! opt.analyse( argc , argv ) )
		{
			opt.usage();
			return( 1 );
		}
		else if ( opt.help() )
		{
			opt.usage();
			return( 0 );
		}

		if ( opt.debug().inhibit )
		{
			Debug_Stream::dbg.inhibit( true );
		}


		SServer_Param	param;

		SServer_Player_Connection	server( param ,
							opt.hostname() ,
							opt.port_number() );

		if ( ! server )
		{
			cerr << "Illegal server connenction" << endl;
			return( 1 );
		}

		sig_serv = &server;
		if ( signal( SIGHUP  , signal_handler ) == SIG_ERR
		  || signal( SIGINT  , signal_handler ) == SIG_ERR
		  || signal( SIGINT  , signal_handler ) == SIG_ERR
		  || signal( SIGQUIT , signal_handler ) == SIG_ERR )
		{
			perror( "signal" );
			return( 1 );
		}


		Soccer_Manager	manager( param , server );

		Game_Info	game_info;
		if ( opt.reconnect() == false )
		{
			if ( manager.init_connection(
					opt.teamname() ,
					opt.goalie() ,
					&game_info ,
					opt.server_major_version() ,
					opt.server_minor_version() ) == (-1) )
			{
				cerr << "init command failed." << endl;
				return( 1 );
			}
		}
		else
		{
			if ( manager.reconnect_connection(
					opt.teamname() ,
					opt.reconnect_player_number() ,
					&game_info , opt.goalie() ) == (-1) )
			{
				cerr << "reconnect command failed." << endl;
				return( 1 );
			}
		}


		Debug_Client_Connection	debug( opt.debug_hostname() ,
					       opt.debug_port_number() );
		manager.register_debug_connection( &debug );

		Field_Recog		field_recog( param ,
						     game_info ,
						     opt.goalie() );
		Field_Recog_Interface	field( &field_recog );
		manager.register_field_recog( &field_recog );

		manager.send_change_view( View_Width::Narrow ,
					  View_Quality::High ,
					  true );
#if 1
		Command_Queue	q( new Act_Test_Team2( field ) );
#else
		Command_Queue	q( new Act_Test_Team( field ) );
		Command_Queue	q( new Act_Test( field ) );
#endif

		for(;;)
		{
			if ( manager.game_over() )
			{
				cout << "Game is Over" << endl;
				manager.send_bye();
				break;
			}
			else if ( manager.server_no_response() )
			{
				cout << "Server No Response" << endl;
				manager.send_bye();
				break;
			}

			manager.next_step();

			if ( q )
			{
				manager.send_composite_command( q.pop() );
			}
		}
	}
	catch( const std::exception &  e )
	{
		cerr << "exception caught!! [" << e.what() << "]" << endl;
		return( 1 );
	}
	catch(...)
	{
		cerr << "exception caught!!" << endl;
		return( 1 );
	}

	return( 0 );
}
