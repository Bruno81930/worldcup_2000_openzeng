#include  <iostream>
#include  "angle.h"

using namespace std;

int    main( void )
{
	Angle	a( Angle::Radian , 2.0 );
	Degree	b( 90.0 );

	if ( a < Degree( 180.0 ) )
	{
		cout << "true" << endl;
	}
	else
	{
		cout << "false" << endl;
	}

	a += b;

	cout << a.radian() << endl;
	cout << a.degree() << endl;

	cout << (-a).radian() << endl;
	cout << (-a).degree() << endl;

	cout << (3.0 * a).degree() << endl;

	return( 0 );
}
