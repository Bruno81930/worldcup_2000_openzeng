#ifndef	   D2_POINT_H_INCLUDED
#define	   D2_POINT_H_INCLUDED

#include  "d2_region.h"
#include  "d2_vector.h"

class  D2_Point : public D2_Region_Entity
{
protected:
	const D2_Vector	point;

public:
	 D2_Point( const D2_Vector &  p );
virtual	~D2_Point();

virtual	bool		in_region( const D2_Vector &  vec ) const;

virtual	ref_count_ptr<const D2_Region_Entity>	copy() const;

virtual	D2_Vector	barycenter() const throw();

virtual	double		area() const throw();

virtual	operator D2_Vector();
};


#endif	/* D2_POINT_H_INCLUDED */
