#include  "d2_straight_line.h"
#include  "d2_straight_line_divided_region.h"
#include  <cmath>
#include  <iostream>
#include  <cstdio>

#include  <signal.h>

using namespace std;

#if 1
#include  "d2_composite_straight_line_divided_region_interface.h"
#include  <vector>

int    main( void )
{
	D2_Composite_Straight_Line_Divided_Region_Interface	region;

	D2_Vector	org( 0.0 , 0.0 );

	D2_Vector	a1( -50.0 , -10.0 );
	D2_Vector	a2( -50.0 , +10.0 );

	D2_Vector	in( -1.0 , 0.0 );

	region.add( a1 , org , in );
	region.add( a2 , org , in );

	{
		vector<D2_Vector>	point_list = region.point_list();

		cout << "point = " << endl;
		for ( size_t  i = 0  ;  i < point_list.size()  ;  i ++ )
		{
			cout << "[" << point_list[i] << "]" << endl;
		}
		cout << endl;
	}

	region.add( a1 , a2 , in );

	{
		vector<D2_Vector>	point_list = region.point_list();

		cout << "point = " << endl;
		for ( size_t  i = 0  ;  i < point_list.size()  ;  i ++ )
		{
			cout << "[" << point_list[i] << "]" << endl;
		}
		cout << endl;
	}


	D2_Vector	b1( -40.0 , -10.0 );
	D2_Vector	b2( -30.0 , +10.0 );
	D2_Vector	in_2( -45.0 , 0.0 );

	region.add( b1 , b2 , in_2 );

	{
		vector<D2_Vector>	point_list = region.point_list();

		cout << "point = " << endl;
		for ( size_t  i = 0  ;  i < point_list.size()  ;  i ++ )
		{
			cout << "[" << point_list[i] << "]" << endl;
		}
		cout << endl;
	}

	return( 0 );
}
#endif




#if 0
#include  "d2_point.h"

int    main( void )
{
#if 0
	D2_Region	r = D2_Vector( 3.0 , 2.0 );
#else
	D2_Region	r;
#endif
	D2_Vector	a;

	for ( int  i = 0  ;  i < 10 * 1000  ;  i ++ )
	try
	{
		a = r.barycenter();
	}
	catch(...)
	{
#if 0
		cerr << "exception caught !!" << endl;
#endif
	}

	return( 0 );
}
#endif


#if 0
#include  "d2_composite_straight_line_divided_region_interface.h"

int    main( void )
{
	try
	{
		D2_Composite_Straight_Line_Divided_Region_Interface	region;

		region.add( 1.0 , 0.0 , -1.0 , true );

		region.add( 0.0 , 1.0 , -1.0 , true );

		region.add( 1.0 , 1.0 , -3.0 , false );

		region.add( 0.0 , 1.0 , -1.5 , true );

#if 0
		region.add( 0.0 , 1.0 , -1.25 , true );
#endif

		region.add( 1.0 , 0.0 , -1.25 , false );

		try
		{
			D2_Vector	g = region.barycenter();
			cout << "g = [" << g << "]" << endl;
		}
		catch(...)
		{
			cerr << "Can't calculate barycenter!!" << endl;
		}
	}
	catch(...)
	{
		cerr << "exception caught !!" << endl;
	}

	return( 0 );
}
#endif


#if 0
#include  "d2_composite_straight_line_divided_region_interface.h"

int    main( void )
{
	try
	{
		for(;;)
		{
			D2_Composite_Straight_Line_Divided_Region_Interface
				region;

			region.add( 1.0 , 0.0 , -1.0 , true );

			region.add( 0.0 , 1.0 , -1.0 , true );

			region.add( 1.0 , 1.0 , -3.0 , false );

			try
			{
				D2_Vector	g = region.barycenter();
				cout << "g = [" << g << "]" << endl;
			}
			catch(...)
			{
				cerr << "Can't calculate barycenter!!" << endl;
			}
		}
	}
	catch(...)
	{
		cerr << "exception caught !!" << endl;
	}

	return( 0 );
}
#endif




#if 0
int    main( void )
{
    try
    {
	D2_Composite_Straight_Line_Divided_Region	reg;

	ref_count_ptr< const D2_Straight_Line_Divided_Region >
		reg_1( new D2_Straight_Line_Divided_Region(
			    D2_Straight_Line( 1.0 , 0.0 , -1.0 ) , true ) );

	ref_count_ptr< const D2_Straight_Line_Divided_Region >
		reg_2( new D2_Straight_Line_Divided_Region(
			    D2_Straight_Line( 0.0 , 1.0 , -1.0 ) , true ) );

	ref_count_ptr< const D2_Composite_Straight_Line_Divided_Region >
		region = reg.add( reg_1 );

	region = region -> add( reg_2 );

	cout << region -> in_region(
			    D2_Vector( D2_Vector::XY , 2.0 , 2.0 ) )<< endl;

	try
	{
		cout << "g = " << region -> barycenter() << endl;
	}
	catch(...)
	{
		cerr << "Can't calculate barycenter!!" << endl;
	}

    }
    catch(...)
    {
	cerr << "exception caught !!" << endl;
    }

	return( 0 );
}
#endif




#if 0
int    main( void )
{
	D2_Composite_Straight_Line_Divided_Region	reg;

	ref_count_ptr< const D2_Straight_Line_Divided_Region >
		reg_1( new D2_Straight_Line_Divided_Region(
				D2_Straight_Line( 1.0 , 2.0 , 3.0 ) , true ) );

	ref_count_ptr< const D2_Composite_Straight_Line_Divided_Region >
		region = reg.add( reg_1 );

	region = region -> add( reg_1 );

	return( 0 );
}
#endif




#if 0
int    main( void )
{

	D2_Straight_Line_Divided_Region		reg(
		D2_Straight_Line( - 1.0 , 1.0 , -1.0 ) , true , true );

	cout << reg.in_region( D2_Vector(D2_Vector::XY , 0.0 , 0.0) ) << endl;
	cout << reg.in_region( D2_Vector(D2_Vector::XY , 0.0 , 1.0) ) << endl;
	cout << reg.in_region( D2_Vector(D2_Vector::XY , 0.0 , 2.0) ) << endl;

	return( 0 );
}
#endif


#if 0
int    main( void )
{
	D2_Vector		base1( D2_Vector::XY , 1.0 , 2.0 );
	D2_Vector		to1  ( D2_Vector::XY , 2.0 , 4.0 );
	D2_Vector		base2( D2_Vector::XY , 1.0 , 2.0 );
	D2_Vector		to2  ( D2_Vector::XY , 1.0 , 5.0 );

	D2_Straight_Line	a( base1 , M_PI * 5.0 / 4.0 );
	D2_Straight_Line	b( base1 , to1 );
	D2_Straight_Line	c( 2.0 , 1.0 , - 4.0 );
	D2_Straight_Line	d( 1.0 , 1.0 , - 2.0 );

#if 0
	printf( "a = %f\n" ,  a( D2_Vector(D2_Vector::XY ,
					   2.0 * pow( 3.0 , 0.5 ) ,
					   3.0) ) );
	printf( "b = %f\n" ,  b( D2_Vector(D2_Vector::XY , -2.0 , -2.0 ) ) );
#endif

	try{
		cout << c.cross_point( a ) << endl;
	}
	catch(...)
	{
		cout << "caught" << endl;
	}

	return( 0 );
}
#endif
