#include  "d2_straight_line.h"

#include  <iostream>
#include  <cmath>

using namespace std;

D2_Straight_Line::D2_Straight_Line( const D2_Vector &  base ,
				    double  direction )
{
	a = - sin( direction );
	b =   cos( direction );
	c = - (a * base.x() + b * base.y());

#if 0
	cout << "a = " << a << endl;
	cout << "b = " << b << endl;
	cout << "c = " << c << endl;
#endif
}

D2_Straight_Line::D2_Straight_Line( const D2_Vector &  base ,
				    const Angle &  direction )
{
	a = - direction.sin();
	b =   direction.cos();
	c = - (a * base.x() + b * base.y());
#if 0
	cout << "a = " << a << endl;
	cout << "b = " << b << endl;
	cout << "c = " << c << endl;
#endif
}


D2_Straight_Line::D2_Straight_Line( const D2_Vector &  point_1 ,
				    const D2_Vector &  point_2 )
{
	double	direction = (point_2 - point_1).theta().radian();

	a = - sin( direction );
	b =   cos( direction );
	c = - (a * point_1.x() + b * point_1.y());

#if 0
	// XXX
	cout << "a = " << a << endl;
	cout << "b = " << b << endl;
	cout << "c = " << c << endl;
#endif
}


D2_Straight_Line::D2_Straight_Line( double  aa ,  double  bb ,  double cc )
	: a(aa) , b(bb) , c(cc)
{
#if 0
	// XXX
	cout << "a = " << a << endl;
	cout << "b = " << b << endl;
	cout << "c = " << c << endl;
#endif
}


D2_Straight_Line::~D2_Straight_Line()
{
}


bool   D2_Straight_Line::in_region( const D2_Vector &  vec ) const
{
	return( (*this)(vec) == 0.0 );
}


double  D2_Straight_Line::area() const throw()
{
	return( 0.0 );
}


ref_count_ptr<const D2_Region_Entity>  D2_Straight_Line::copy() const
{
	return( ref_count_ptr<const D2_Region_Entity>(
				      new D2_Straight_Line( *this ) ) );
}




double  D2_Straight_Line::operator () ( const D2_Vector &  p ) const
{
	return( a * p.x() + b * p.y() + c );
}

D2_Vector  D2_Straight_Line::cross_point( const D2_Straight_Line &  line )
	const  throw( D2_Region::No_Region_Error )
{
	const	double	EPS = 1.0e-15;

	double	x;
	double	y;

#if 0
	// TTT
	cout << "line 1: a = " << a
	     << ", b = " << b
	     << ", c = " << c << endl;
	cout << "line 2: a = " << line.a
	     << ", b = " << line.b
	     << ", c = " << line.c << endl;
#endif

	double	tmp = (*this).a * line.b - line.a * (*this).b;

	if ( fabs( tmp ) < EPS )
	{
		throw D2_Region::No_Region_Error();
	}

	x = ((*this).b * line.c - line.b * (*this).c) / tmp;
	y = (line.a * (*this).c - (*this).a * line.c) / tmp;

	return( D2_Vector( D2_Vector::XY , x , y ) );
}


bool   D2_Straight_Line::parallel( const D2_Straight_Line &  line ) const
{
	const	double	EPS = 1.0e-15;

	return( ! (fabs( (*this).a * line.b - line.a * (*this).b ) < EPS) );
}


Angle  D2_Straight_Line::direction() const
{
	D2_Vector	v( D2_Vector::Pole , 1.0 , atan2( - a , b ) );

	v.normalize_theta();

	return( Angle( Angle::Radian , v.theta().radian() ) );
}


double  D2_Straight_Line::distance( const D2_Vector &  p ) const
{
	D2_Straight_Line	cross_line( p ,
					    this -> direction()
					    + Radian(M_PI / 2.0) );

	return( (this -> cross_point( cross_line ) - p).r() );
}

D2_Vector  D2_Straight_Line::sample_point() const
{
	// XXX
	if ( fabs(a) >= fabs(b) )
	{
		return( D2_Vector( D2_Vector::XY ,  - c / a   ,  0.0 ) );
	}
	else
	{
		return( D2_Vector( D2_Vector::XY ,  0.0  ,  - c / b ) );
	}
}

D2_Vector  D2_Straight_Line::project_point( const D2_Vector &  p ) const
{
	D2_Straight_Line	cross_line( p ,
					    this -> direction()
					    + Radian(M_PI / 2.0) );

	return( this -> cross_point( cross_line ) );
}
