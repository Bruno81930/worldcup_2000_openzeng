#ifdef    D2_VECTOR_TEST
#include  "d2_vector.h"
#include  <iostream>
#include  <cmath>

int    main( void )
{
	D2_Vector	vec1( D2_Vector::Pole , 2.0 ,
			      D2_Vector::deg_to_rad( 30.0 + 180.0 ) );
	D2_Vector	vec2( D2_Vector::XY , 3.0 , 3.0 );

	cout << "vec1(x,y)     = "
	     << vec1.x() << "," << vec1.y() << endl;
	cout << "vec1(r,theta) = "
	     << vec1.r() << "," << vec1.theta().radian() << endl;
	cout << endl;

	cout << "vec2(x,y)     = "
	     << vec2.x() << "," << vec2.y() << endl;
	cout << "vec2(r,theta) = "
	     << vec2.r() << "," << vec2.theta().radian() << endl;
	cout << endl;

	D2_Vector	vec3 = vec1 + vec2;
	cout << "vec3 = vec1 + vec2" << endl;
	cout << "vec3(x,y)     = "
	     << vec3.x() << "," << vec3.y() << endl;
	cout << "vec3(r,theta) = " << vec3.r()
	     << "," << vec3.theta().radian() << endl;
	cout << endl;

	cout << "vec3.rotate( 45.0 degree )" << endl;
	vec3 = vec3.rotate( D2_Vector::deg_to_rad( 45.0 ) );
	cout << "vec3(x,y)     = "
	     << vec3.x() << "," << vec3.y() << endl;
	cout << "vec3(r,theta) = "
	     << vec3.r() << "," << vec3.theta().radian() << endl;
	cout << endl;

	cout << "vec3.normalize()" << endl;
	vec3 = vec3.normalize();
	cout << "vec3(x,y)     = "
	     << vec3.x() << "," << vec3.y()     << endl;
	cout << "vec3(r,theta) = "
	     << vec3.r() << "," << vec3.theta().radian() << endl;

	return( 0 );
}
#endif // D2_VECTOR_TEST


#include  "d2_vector.h"
#include  <math.h>
#include  <cassert>
#include  <iostream>

using namespace std;

const double  D2_Vector::EPSILON = 1.0e-100;

double  D2_Vector::deg_to_rad( double  x )
{
	return( x * M_PI / 180.0 );
}

double  D2_Vector::rad_to_deg( double  x )
{
	return( x * 180.0 / M_PI );
}


D2_Vector::D2_Vector()
{
	x_value = 0.0;
	y_value = 0.0;
	xy_calculated = true;

	r_value     = 0.0;
	theta_value = 0.0;
	pole_calculated = true;
}

D2_Vector::D2_Vector( XY_or_Pole  type ,
		      double  x_or_r ,  double  y_or_theta )
{
	this -> set( type , x_or_r , y_or_theta );
}

D2_Vector::D2_Vector( XY_or_Pole  type ,
		      double  r ,  const Angle &  ang )
{
	this -> set( type , r , ang );
}

D2_Vector::D2_Vector( double  x ,  double  y )
{
	this -> set( D2_Vector::XY , x , y );
}

D2_Vector::D2_Vector( double  r ,  const Angle &  ang )
{
	this -> set( D2_Vector::Pole , r , ang );
}


D2_Vector::D2_Vector( const D2_Vector&  vec )
{
	this -> set( vec );
}

D2_Vector::~D2_Vector()
{
}


D2_Vector&  D2_Vector::set( XY_or_Pole  type ,
			    double  x_or_r ,  double  y_or_theta )
{
	if ( type == XY )
	{
		x_value = x_or_r;
		y_value = y_or_theta;
		xy_calculated   = true;
		pole_calculated = false;
	}
	else
	{
		r_value     = x_or_r;
		theta_value = y_or_theta;
		pole_calculated = true;
		xy_calculated   = false;
	}

	return( *this );
}

D2_Vector&  D2_Vector::set( XY_or_Pole  type ,
			     double  r ,  const Angle &  ang )
{
	assert( type == Pole );

	return( this -> set( D2_Vector::Pole , r , ang.radian() ) );
}

D2_Vector&  D2_Vector::set( double  r ,  const Angle &  ang )
{
	return( this -> set( D2_Vector::Pole , r , ang.radian() ) );
}

D2_Vector&  D2_Vector::set( double  x_val ,  double  y_val )
{
	return( this -> set( D2_Vector::XY , x_val , y_val ) );
}

D2_Vector&  D2_Vector::set( const D2_Vector&  vec )
{
	if ( vec.xy_calculated )
	{
		this -> xy_calculated = true;
		this -> x_value       = vec.x_value;
		this -> y_value       = vec.y_value;
	}
	else
	{
		this -> xy_calculated = false;
	}

	if ( vec.pole_calculated )
	{
		this -> pole_calculated = true;
		this -> r_value         = vec.r_value;
		this -> theta_value     = vec.theta_value;
	}
	else
	{
		this -> pole_calculated = false;
	}

	return( *this );
}

D2_Vector&  D2_Vector::operator = ( const D2_Vector&  vec )
{
	return( this -> set( vec ) );
}


double  D2_Vector::x() const
{
	if ( ! xy_calculated )
	{
		calculate_xy();
	}

	return( x_value );
}

double  D2_Vector::y() const
{
	if ( ! xy_calculated )
	{
		calculate_xy();
	}

	return( y_value );
}

double  D2_Vector::r() const
{
	if ( ! pole_calculated )
	{
		calculate_pole();
	}

	return( r_value );
}

Angle  D2_Vector::theta() const
{
	if ( ! pole_calculated )
	{
		calculate_pole();
	}

	return( Angle( Angle::Radian , theta_value ) );
}


D2_Vector  D2_Vector::normalize() const
{
	if ( ! pole_calculated )
	{
		calculate_pole();
	}
	if ( ! xy_calculated )
	{
		calculate_xy();
	}

	D2_Vector	ret = (*this);

	ret.x_value /= ret.r_value;
	ret.y_value /= ret.r_value;

	ret.r_value = 1.0;

	return( ret );
}


D2_Vector  D2_Vector::normalize_theta() const
{
	if ( ! pole_calculated )
	{
		calculate_pole();
	}

	D2_Vector	ret = (*this);

	// [-PI , +PI)
	if ( ret.theta_value  >=  M_PI )
	{
		do
		{
			ret.theta_value  -=  2.0 * M_PI;
		} while( ret.theta_value  >=  M_PI );
	}
	else if ( ret.theta_value  <  (- M_PI) )
	{
		do
		{
			ret.theta_value  +=  2.0 * M_PI;
		} while( ret.theta_value  <  (- M_PI) );
	}

	assert( - M_PI <= ret.theta_value  &&  ret.theta_value  < M_PI );

	return( ret );
}


D2_Vector  D2_Vector::rotate( const Angle &  d ) const
{
	if ( ! pole_calculated )
	{
		calculate_pole();
	}

	D2_Vector	ret = (*this);

	ret.theta_value += d.radian();
	ret.xy_calculated = false;

	return( ret );
}


void  D2_Vector::calculate_xy() const
{
	assert( pole_calculated );

	x_value = r_value * cos( theta_value );
	y_value = r_value * sin( theta_value );

	xy_calculated = true;
}

void  D2_Vector::calculate_pole() const
{
	assert( xy_calculated );

	double	r2 = x_value * x_value  +  y_value * y_value;

	if ( r2 < 0.0 )
	{
		r2 = 0.0;
	}

	r_value = sqrt( r2 );

	if ( r_value  ==  0.0 )
	{
		theta_value = 0.0;
	}
	else
	{
		theta_value = atan2( y_value , x_value );
	}

	pole_calculated = true;
}


D2_Vector  D2_Vector::operator + () const
{
	return( *this );
}

D2_Vector  D2_Vector::operator - () const
{
	return( D2_Vector::origin() - (*this) );
}

D2_Vector  D2_Vector::operator + ( const D2_Vector&  vec ) const
{
	if ( ! xy_calculated )
	{
		calculate_xy();
	}

	D2_Vector	ret( D2_Vector::XY ,
			     this -> x_value + vec.x() ,
			     this -> y_value + vec.y() );
	return( ret );
}

D2_Vector  D2_Vector::operator - ( const D2_Vector&  vec ) const
{
	if ( ! xy_calculated )
	{
		calculate_xy();
	}

	D2_Vector	ret( D2_Vector::XY ,
			     this -> x_value - vec.x() ,
			     this -> y_value - vec.y() );
	return( ret );
}

D2_Vector  D2_Vector::operator * ( double  d ) const
{
	if ( pole_calculated )
	{
		D2_Vector	ret( D2_Vector::Pole ,
				     this ->  r_value * d ,
				     this ->  theta_value );
		return( ret );
	}
	else
	{
		assert( xy_calculated );

		D2_Vector	ret( D2_Vector::XY ,
				     this ->  x_value * d ,
				     this ->  y_value * d );
		return( ret );
	}
}

D2_Vector  D2_Vector::operator / ( double  d ) const
{
	if ( d <= eps() )
	{
		cerr  <<  "Divided by zero."  <<  endl;
		D2_Vector	ret( D2_Vector::XY , 0.0 , 0.0 );
		return( ret );
	}

	if ( pole_calculated )
	{
		D2_Vector	ret( D2_Vector::Pole ,
				     this ->  r_value / d ,
				     this ->  theta_value );
		return( ret );
	}
	else
	{
		assert( xy_calculated );

		D2_Vector	ret( D2_Vector::XY ,
				     this ->  x_value / d ,
				     this ->  y_value / d );
		return( ret );
	}
}

D2_Vector&  D2_Vector::operator += ( const D2_Vector&  vec )
{
	// checked: OK. if (this == &vec)

	if ( ! xy_calculated )
	{
		calculate_xy();
	}

	x_value += vec.x();
	y_value += vec.y();

	pole_calculated = false;

	return( *this );
}

D2_Vector&  D2_Vector::operator -= ( const D2_Vector&  vec )
{
	// checked: OK. if (this == &vec)

	if ( ! xy_calculated )
	{
		calculate_xy();
	}

	x_value -= vec.x();
	y_value -= vec.y();

	pole_calculated = false;

	return( *this );
}

D2_Vector&  D2_Vector::operator *= ( double  d )
{
	if ( ! pole_calculated )
	{
		calculate_pole();
	}

	r_value *= d;

	xy_calculated = false;

	return( *this );
}

D2_Vector&  D2_Vector::operator /= ( double  d )
{
	if ( ! pole_calculated )
	{
		calculate_pole();
	}

	if ( d <= eps() )
	{
		cerr  <<  "Divided by zero."  <<  endl;
		return( *this );
	}

	r_value /= d;

	xy_calculated = false;

	return( *this );
}


D2_Vector  operator * ( double  d ,  const D2_Vector&  vec )
{
	return( vec * d );
}


bool   D2_Vector::equal( const D2_Vector&  vec , double  epsilon ) const
{
	return( (vec - *(this)).r() <= epsilon );
}


bool   D2_Vector::operator == ( const D2_Vector&  vec ) const
{
	return( (vec - *(this)).r() == 0.0 );
}

double  D2_Vector::eps()
{
	return( EPSILON );
}


D2_Vector  D2_Vector::origin()
{
	return( D2_Vector( D2_Vector::XY , 0.0 , 0.0 ) );
}


#include  <iostream>
std::ostream&  operator << ( std::ostream&  ostr , const D2_Vector&  vec )
{
	ostr << vec.x() << "," << vec.y();

	return( ostr );
}
