#include  "debugstream.h"

int    main( void )
{
	dbg << "Hello" << endl;

	dbg.inhibit( true );

	dbg << "Hello2" << endl;

	dbg.inhibit( false );

	dbg << "Hello3" << endl;

	return( 0 );
}
