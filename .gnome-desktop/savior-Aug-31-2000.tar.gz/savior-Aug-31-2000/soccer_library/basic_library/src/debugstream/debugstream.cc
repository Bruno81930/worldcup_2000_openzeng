#include  "debugstream.h"

namespace Debug_Stream {

// external
debugstream	dbg;


#include  <cstdio>
#include  <stdarg.h>

using namespace std;

int    debugstream::printf( const char *  fmt , ... )
{
	if ( this -> rdbuf()  !=  &null )
	{
		va_list	ap;
		va_start( ap , fmt );

		int	ret;
		ret = vprintf( fmt , ap );
		fflush( stdout );

		va_end( ap );

		return( ret );
	}

	return( 0 );
}

} // end of namespace Debug_Stream
