#ifndef	   DEBUGSTREAM_H_INCLUDED
#define	   DEBUGSTREAM_H_INCLUDED

// Author:		H. Shimora
// Created:		Mar 11 2000
// Last-Modified:	Mar 11 2000
// Version:		0.00

///-----------------------------------------------
/// Change Log:
///-----------------------------------------------
// version 0.00  Mar 11 2000    test version.
//
//

// XXX: interface might be changed!!

#include  <iostream>
#include  "nullbuf.h"

namespace Debug_Stream {

class  debugstream : public std::iostream
{
protected:
	nullbuf		null;

public:
	 debugstream() : std::iostream( cout.rdbuf() )	{}
virtual	~debugstream()					{}

virtual	void	inhibit( bool  flag = true )
		{
			if ( flag )
			{
				this -> rdbuf( &null );
			}
			else
			{
				this -> rdbuf( cout.rdbuf() );
			}
		}

	int	printf( const char *  fmt , ... );
};

extern	debugstream	dbg;

} // end of namespace Debug_Stream


#endif	/* DEBUGSTREAM_H_INCLUDED */
