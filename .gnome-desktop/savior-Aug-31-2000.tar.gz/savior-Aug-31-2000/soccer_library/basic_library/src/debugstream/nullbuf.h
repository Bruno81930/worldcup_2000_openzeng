#ifndef	   NULLBUF_H_INCLUDED
#define	   NULLBUF_H_INCLUDED

// Author:		H. Shimora
// Created:		Mar 11 2000
// Last-Modified:	Mar 11 2000
// Version:		1.00

///-----------------------------------------------
/// Change Log:
///-----------------------------------------------
// version 1.00  Mar 11 2000    base version.
//
//

#ifdef HAVE_STREAMBUF_HEADER
#include  <streambuf>
#else
#include  <streambuf.h>
#endif

class  nullbuf : public std::streambuf
{
public:
virtual	~nullbuf(){}
};


#endif	/* NULLBUF_H_INCLUDED */
