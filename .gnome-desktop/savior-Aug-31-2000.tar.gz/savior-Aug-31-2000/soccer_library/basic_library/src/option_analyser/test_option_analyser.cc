#include  "test_option_analyser.h"
#include  <iostream>
#include  <vector>
#include  <string>
#include  <cstdlib>

using namespace std;

int    main( int  argc ,  char *  argv[] )
{
	Test_Option_Analyser	opt;

	if ( ! opt.analyse( argc , argv ) )
	{
		cerr << "option error" << endl;
		exit( 1 );
	}

	std::cout << "flag = " << (opt.flag() ? "true" : "false") << std::endl;
	std::cout << "integer = " << opt.integer() << std::endl;
	std::cout << "float = " << opt.dbl() << std::endl;
	std::cout << "str = [" << opt.str() << "]" << std::endl;

	vector<string>	rest = opt.rest();

	for ( size_t  i = 0  ;  i < rest.size()  ;  i ++ )
	{
		cout << "rest[" << i << "] = "
		     << "[" << rest[i] << "]" << endl;
	}

	return( 0 );
}
