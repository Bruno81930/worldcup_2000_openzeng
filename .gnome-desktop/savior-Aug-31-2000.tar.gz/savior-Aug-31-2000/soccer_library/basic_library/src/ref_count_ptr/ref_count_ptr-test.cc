#include  "ref_count_ptr.h"
#include  <iostream>

#if 1
int    main( void )
{
	ref_count_ptr<int>		ptr( new int(1) );
	ref_count_ptr<const int>	const_ptr( ptr );
}
#endif


#if 0
int    main( void )
{
	ref_count_ptr<int>		ptr( new int(1) );
	ref_count_ptr<const int>	const_ptr( new int(2) );

	const_ptr = ptr;
}
#endif


#if 0
class B
{
};

class D : public B
{
};

int    main( void )
{
	ref_count_ptr<D>	d( new D );
	ref_count_ptr<B>	b( d );
}
#endif

#if 0
void   func( const ref_count_ptr<const int> )
{
}

void   func( const ref_count_ptr<double> )
{
}

int    main( void )
{
	ref_count_ptr<int>		ptr( new int(1) );
	ref_count_ptr<const int>	const_ptr( new int(2) );

	func( const_ptr );
#if 0
	func( ptr );
#endif
}
#endif


#if 0
class B
{
};

class D : public B
{
};

int    main( void )
{
	ref_count_ptr<B>	b( new D );

#if 0
	ref_count_ptr<D>	d = b;
#endif
}
#endif


#if 0
#include  "heap_status.h"
#include  <cstdlib>
#include  <cstdio>

static
void   report_new_delete()
{
	Heap_Status::report();
}

int    main( void )
{
	if ( atexit( report_new_delete ) == -1 )
	{
		perror( "atexit" );
	}

	ref_count_ptr<int>	p1;
	ref_count_ptr<int>	p2;
	ref_count_ptr<int>	p3;

	p1 = new int;
	*p1 = 1;

	p2 = p1;
	p3 = p2;

	cout << *p3 << endl;

	return( 0 );
}
#endif


#if 0
int    main( void )
{
	if ( atexit( report_new_delete ) == -1 )
	{
		perror( "atexit" );
	}

	ref_count_ptr< ref_count_ptr<int> >	p1;
	ref_count_ptr< ref_count_ptr<int> >	p2;

	p1 = new ref_count_ptr<int>;

	*p1 = new int;
	p2 = p1;

	**p2 = 1;

	cout << **p2 << endl;

	return( 0 );
}
#endif


#if 0
int    main( void )
{
	if ( atexit( report_new_delete ) == -1 )
	{
		perror( "atexit" );
	}

	ref_count_ptr<int>	p1;

	p1 = new int;
	*p1 = 1;

	p1 = p1;

	cout << *p1 << endl;

	return( 0 );
}
#endif


#if 0
class	A
{
public:
	void	print()
		{
			cout << "A" << endl;
		}
};

int    main( void )
{
	if ( atexit( report_new_delete ) == -1 )
	{
		perror( "atexit" );
	}

	ref_count_ptr<A>	a( new A );

	a -> print();

	return( 0 );
}
#endif


#if 0
#include  <memory>

int    main( void )
{
#if 1
	ref_count_ptr<int>	a( new int(3) );
#elif 0
	auto_ptr<int>		a( new int(3) );
#else
	int *			a( new int(3) );
#endif

	for ( int  i = 0  ;  i < 10 * 1000 * 1000  ;  i ++ )
	{
		*a = 1;
	}
}
#endif
