#ifndef	   ACTION_BASIC_H_INCLUDED
#define	   ACTION_BASIC_H_INCLUDED

#include  "soccer_action.h"
#include  "soccer_command.h"
#include  "soccer_composite_command.h"
#include  "command_queue.h"
#include  "d2_vector.h"
#include  "d2_region.h"
#include  "debugstream.h"

static	const	double	EPS = 0.001;

using namespace std;
using namespace Debug_Stream;

#endif	/* ACTION_BASIC_H_INCLUDED */
