#include  "soccer_manager.h"
#include  "sserver_player_connection.h"
#include  "debug_client_connection.h"
#include  "sserver_param.h"
#include  "field_recog.h"
#include  "field_recog_interface.h"
#include  "soccer_option_analyser.h"
#include  "command_queue.h"
#include  "debugstream.h"
#include  "command_queue.h"
#include  "soccer_action.h"
#include  <cstdio>
#include  <cstddef>
#include  <cstdlib>
#include  <csignal>
#include  <cfloat>

#ifdef HAVE_CONFIG_H
  #include  "config.h"
#endif
#ifndef RETSIGTYPE
  typedef void RETSIGTYPE;
#endif

using namespace std;


// for signal
static	SServer_Player_Connection *	sig_serv = NULL;
static	RETSIGTYPE			signal_handler( int );

static
RETSIGTYPE   signal_handler( int )
{
	if ( sig_serv )
	{
		sig_serv -> send_bye();
	}

	exit( 0 );
}


class  Test_Action : public Soccer_Action
{
public:
		Test_Action( const Field_Recog_Interface &  f )
			: Soccer_Action( f ) {}

	virtual	~Test_Action() {}

	virtual	Soccer_Composite_Command	action()
	{
		Soccer_Command	basic_com;

		if ( (random() >> 8 ) % 2  ==  0 )
		{
			basic_com.turn( Degree( random() % 3600000 - 1800000 )
					/ 10000.0 );
		}
		else
		{
			basic_com.dash( (random() % 2000000 - 1000000)
					/ 10000.0 );
		}

		Soccer_Composite_Command	com( basic_com );

		com.add_turn_neck( Degree( random() % 3600000 - 1800000 )
				   / 10000.0 );

		return( com );
	}

	virtual	ref_count_ptr<Soccer_Action>	copy() const
	{
		return( new Test_Action( *this ) );
	}
};


int    main( int  argc ,  char *  argv[] )
{
	try
	{
		ios::sync_with_stdio();

		cout.precision( DBL_DIG );
		cerr.precision( DBL_DIG );


		Soccer_Option_Analyser
			opt( "test" /* default team name */ ,
			     false  /* default is field player */ );

		if ( ! opt.analyse( argc , argv ) )
		{
			opt.usage();
			return( 1 );
		}
		else if ( opt.help() )
		{
			opt.usage();
			return( 0 );
		}

		if ( opt.debug().inhibit )
		{
			Debug_Stream::dbg.inhibit( true );
		}


		SServer_Param	param;

		SServer_Player_Connection	server( param ,
							opt.hostname() ,
							opt.port_number() );

		if ( ! server )
		{
			cerr << "Illegal server connenction" << endl;
			return( 1 );
		}

		sig_serv = &server;
		if ( signal( SIGHUP  , signal_handler ) == SIG_ERR
		  || signal( SIGINT  , signal_handler ) == SIG_ERR
		  || signal( SIGINT  , signal_handler ) == SIG_ERR
		  || signal( SIGQUIT , signal_handler ) == SIG_ERR )
		{
			perror( "signal" );
			return( 1 );
		}


		Soccer_Manager	manager( param , server );

		Game_Info	game_info;
		if ( opt.reconnect() == false )
		{
			if ( manager.init_connection(
					opt.teamname() ,
					opt.goalie() ,
					&game_info ,
					opt.server_major_version() ,
					opt.server_minor_version() ) == (-1) )
			{
				cerr << "init command failed." << endl;
				return( 1 );
			}
		}
		else
		{
			if ( manager.reconnect_connection(
					opt.teamname() ,
					opt.reconnect_player_number() ,
					&game_info , opt.goalie() ) == (-1) )
			{
				cerr << "reconnect command failed." << endl;
				return( 1 );
			}
		}


		Debug_Client_Connection	debug( opt.debug_hostname() ,
					       opt.debug_port_number() );
		manager.register_debug_connection( &debug );

		Field_Recog		field_recog( param ,
						     game_info ,
						     opt.goalie() );
		Field_Recog_Interface	field( &field_recog );
		manager.register_field_recog( &field_recog );


		manager.send_move( - 25.0 , 10.0 , true );
		manager.send_change_view( View_Width::Narrow ,
					  View_Quality::High ,
					  true );

		srandom( 1 );

		Command_Queue	q( new Test_Action( field ) );

		for(;;)
		{
			if ( manager.game_over() )
			{
				cout << "Game is Over" << endl;
				manager.send_bye();
				break;
			}
			else if ( manager.server_no_response() )
			{
				cout << "Server No Response" << endl;
				manager.send_bye();
				break;
			}

			manager.next_step();

			manager.send_composite_command( q.pop() );
		}
	}
	catch( const std::exception &  e )
	{
		cerr << "exception caught!! [" << e.what() << "]" << endl;
		return( 1 );
	}
	catch( ... )
	{
		cerr << "exception caught!!" << endl;
		return( 1 );
	}

	return( 0 );
}
