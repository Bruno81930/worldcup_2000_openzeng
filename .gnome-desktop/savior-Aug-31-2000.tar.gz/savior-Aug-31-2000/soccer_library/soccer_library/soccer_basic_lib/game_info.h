#ifndef	   GAME_INFO_H_INCLUDED
#define	   GAME_INFO_H_INCLUDED

#include  "s_basic.h"

struct   Game_Info
{
	Play_Mode	play_mode;

	int		our_score;
	int		opponent_score;

	S_Side_LR	our_side;
	int		my_player_number;

public:
	Game_Info()
		: play_mode( Play_Mode::Unknown ) ,
		  our_score( 0 ) , opponent_score( 0 ) ,
		  our_side( S_Side_LR::Unknown ) ,
		  my_player_number( -1 )
	{
	}
};


#endif	/* GAME_INFO_H_INCLUDED */
