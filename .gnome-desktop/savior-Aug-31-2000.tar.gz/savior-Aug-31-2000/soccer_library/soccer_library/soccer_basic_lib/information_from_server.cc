#include  "information_from_server.h"

using namespace std;

//
// Information_from_Server
//
Information_from_Server::Information_from_Server()
	: type_of_info( Type_Unknown ) ,
	  time_of_info( 0 ) ,
	  raw_mes() ,
	  sight  ( static_cast<Sight_Info_from_Server *>  (0) ) ,
	  audio  ( static_cast<Audio_Info_from_Server *>  (0) ) ,
	  whistle( static_cast<Whistle_Info_from_Server *>(0) ) ,
	  body   ( static_cast<Body_Info_from_Server *>   (0) ) ,
	  err    ( static_cast<Error_Info_from_Server *>  (0) ) ,
	  debug  ( static_cast<Debug_Info_from_Server *>  (0) )
{
}

Information_from_Server::~Information_from_Server()
{
}


void   Information_from_Server::reset_info()
{
	type_of_info = Type_Unknown;

	sight   = static_cast<Sight_Info_from_Server *>  (0);
	audio   = static_cast<Audio_Info_from_Server *>  (0);
	whistle = static_cast<Whistle_Info_from_Server *>(0);
	body    = static_cast<Body_Info_from_Server *>   (0);
	err     = static_cast<Error_Info_from_Server *>  (0);
	debug   = static_cast<Debug_Info_from_Server *>  (0);
}


void   Information_from_Server::set_raw_message( const string &  mes )
{
	this ->  raw_mes = mes;
}


void   Information_from_Server::set_time( int  t )
{
	time_of_info = t;
}


void   Information_from_Server::set_sight_info(
		 const ref_count_ptr< const Sight_Info_from_Server > &  si )
{
	reset_info();
	this -> type_of_info = Type_Sight;
	this -> sight = si;
}


void   Information_from_Server::set_audio_info(
		 const ref_count_ptr< const Audio_Info_from_Server > &  au )
{
	reset_info();
	this -> type_of_info = Type_Audio;
	this -> audio = au;
}

void   Information_from_Server::set_whistle_info(
		 const ref_count_ptr< const Whistle_Info_from_Server > &  wi )
{
	reset_info();
	this -> type_of_info = Type_Whistle;
	this -> whistle = wi;
}


void   Information_from_Server::set_body_info(
		 const ref_count_ptr< const Body_Info_from_Server > &  bd )
{
	reset_info();
	this ->  type_of_info = Type_Body;
	this ->  body = bd;
}

void   Information_from_Server::set_error_info(
		 const ref_count_ptr< const Error_Info_from_Server > &  er )
{
	reset_info();
	this ->  type_of_info = Type_Error;
	this ->  err = er;
}

void   Information_from_Server::set_debug_info(
		const  ref_count_ptr< const Debug_Info_from_Server > &  de )
{
	reset_info();
	this ->  type_of_info = Type_Debug;
	this ->  debug = de;
}


void   Information_from_Server::set_no_info()
{
	reset_info();
	this ->  type_of_info = Type_No_Info;
}




const string &  Information_from_Server::raw_message() const
{
	return( raw_mes );
}


Information_from_Server::Info_Type  Information_from_Server::type() const
{
	return( this ->  type_of_info );
}


int    Information_from_Server::time() const
{
	return( this ->  time_of_info );
}


bool   Information_from_Server::illegal() const
{
	return( this ->  type_of_info  ==  Type_Unknown );
}


bool   Information_from_Server::no_info() const
{
	return( this ->  type_of_info  ==  Type_No_Info );
}


const ref_count_ptr<const Sight_Info_from_Server> &
  Information_from_Server::get_sight_info() const
{
	return( sight );
}

const ref_count_ptr<const Audio_Info_from_Server> &
  Information_from_Server::get_audio_info() const
{
	return( audio );
}

const ref_count_ptr<const Whistle_Info_from_Server> &
  Information_from_Server::get_whistle_info() const
{
	return( whistle );
}

const ref_count_ptr<const Body_Info_from_Server> &
  Information_from_Server::get_body_info() const
{
	return( body );
}

const ref_count_ptr<const Error_Info_from_Server> &
  Information_from_Server::get_error_info() const
{
	return( err );
}

const ref_count_ptr<const Debug_Info_from_Server> &
  Information_from_Server::get_debug_info() const
{
	return( debug );
}
