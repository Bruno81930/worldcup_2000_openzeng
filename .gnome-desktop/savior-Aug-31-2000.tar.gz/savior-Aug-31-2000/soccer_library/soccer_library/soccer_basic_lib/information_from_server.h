#ifndef	   INFORMATION_FROM_SERVER_H_INCLUDED
#define	   INFORMATION_FROM_SERVER_H_INCLUDED

#include  "s_basic.h"
#include  "angle.h"

///////////////////////////////////////////////////////////////////////////////
//			      Body_Info					     //
///////////////////////////////////////////////////////////////////////////////
struct  Body_Info_from_Server
{
	View_Width	v_width;
	View_Quality	v_quality;

	double	stamina;
	double	effort;

	bool	have_speed_angle;
	double	speed;
	Angle	speed_angle;

	Angle	neck_angle;

	int	n_kick;
	int	n_dash;
	int	n_turn;
	int	n_say;
	int	n_turn_neck;

	Body_Info_from_Server()
		: v_width( View_Width::Normal ) ,
		  v_quality( View_Quality::High ) ,
		  stamina(0.0) , effort(0.0) ,
		  have_speed_angle(false) ,
		  speed(0.0) , speed_angle( Angle::Radian , 0.0 ) ,
		  neck_angle( Angle::Radian , 0.0 ) ,
		  n_kick(0) , n_dash(0) , n_turn(0) , n_say(0) , n_turn_neck(0)
		{
		}
};



///////////////////////////////////////////////////////////////////////////////
//			     Whistle_Info				     //
///////////////////////////////////////////////////////////////////////////////
struct  Whistle_Info_from_Server
{
	Judgement_Type	type;

	Play_Mode	play_mode;
	S_Side		side;
	int		player_number;
	int		score;

	Whistle_Info_from_Server()
		: type( Judgement_Type::Unknown ) ,
		  play_mode( Play_Mode::Unknown ) ,
		  side( S_Side::Unknown ) , player_number( 0 ) , score( 0 )
		{
		}
};


///////////////////////////////////////////////////////////////////////////////
//			   Audio_Info					     //
///////////////////////////////////////////////////////////////////////////////
#include  <string>

struct  Audio_Info_from_Server
{
	typedef  enum { ST_Self , ST_Player }  Sender_Type;

	Angle		direction;
	Sender_Type	sender;
	std::string	message;

	Audio_Info_from_Server()
		: direction( Angle::Radian , 0.0 ) , sender( ST_Self ) ,
		  message()
		{
		}
};



///////////////////////////////////////////////////////////////////////////////
//			      Sight_Info				     //
///////////////////////////////////////////////////////////////////////////////

#include  "d2_vector.h"
//
//  Object Location
//
struct  SObject_Locational_Info_from_Server
{
	bool	have_distance;
	bool	have_direction;
	bool	have_d_distance;
	bool	have_d_direction;
	bool	have_body_direction;
	bool	have_face_direction;

	double	distance;
	Angle	direction;
	double	d_distance;
	Angle	d_direction;
	Angle	body_direction;
	Angle	face_direction;

	bool	in_sight;

	SObject_Locational_Info_from_Server()
		: have_distance( false ) , have_direction( false ) ,
		  have_d_distance( false ) , have_d_direction( false ) ,
		  have_face_direction( false ) ,
		  in_sight( true )
		{
		}
};


//
//  Object and Locational Information
//
struct  Ball_Info_from_Server
{
	SObject_Ball_Identifier			entity;
	SObject_Locational_Info_from_Server	relative;
};

struct  Player_Info_from_Server
{
	SObject_Player_Identifier		entity;
	SObject_Locational_Info_from_Server	relative;
	bool	have_goalie_info;
	bool	goalie;

public:
	Player_Info_from_Server()
		: have_goalie_info( false ) , goalie( false ) {}
};

struct  Field_Marker_Info_from_Server
{
	SObject_Field_Marker_Identifier		entity;
	SObject_Locational_Info_from_Server	relative;
};

struct  Line_Info_from_Server
{
	SObject_Line_Identifier			entity;
	SObject_Locational_Info_from_Server	relative;
};

//
//  Sight_Info_from_Server
//
#include  <vector>

struct  Sight_Info_from_Server
{
	std::vector<         Ball_Info_from_Server >	ball;
	std::vector<       Player_Info_from_Server >	player;
	std::vector< Field_Marker_Info_from_Server >	field_marker;
	std::vector<         Line_Info_from_Server >	line;

	 Sight_Info_from_Server()
		 : ball() , player() , field_marker() , line()
		{
		}

#ifdef LIB_MEMORY
	~Sight_Info_from_Server()
		{
			ball.clear();
			player.clear();
			field_marker.clear();
			line.clear();
		}
#endif
};


///////////////////////////////////////////////////////////////////////////////
//			      Error_Info				     //
///////////////////////////////////////////////////////////////////////////////
#include  <string>

struct  Error_Info_from_Server
{
	// XXX
	std::string	error_message;

public:
	Error_Info_from_Server()
		: error_message()
	{
	}
};


///////////////////////////////////////////////////////////////////////////////
//			      OK_Info					     //
///////////////////////////////////////////////////////////////////////////////
struct  OK_Info_from_Server
{
	// XXX
	typedef  enum { Move , Look , Check_Ball ,
			Say , Ear , Chamge_Mode } OK_Type;
	OK_Type		type;

	typedef  enum { In_Field , Out_of_Field ,
			In_Our_Goal , In_Oppornent_Goal } Ball_Position;

	Ball_Position	ball_position;

	bool	ear;

	OK_Info_from_Server()
		: type( Move ) , ball_position( In_Field ) , ear( true )
		{
		}
};



///////////////////////////////////////////////////////////////////////////////
//			      Debug_Info				     //
///////////////////////////////////////////////////////////////////////////////
struct  Debug_Info_from_Server
{
	bool		have_info;

	D2_Vector	true_my_coordinate;
	Angle		true_my_body_angle;
	Angle		true_my_neck_angle;
	double		true_my_stamina;
	double		true_my_effort;
	double		true_my_speed;
	bool		offside_position;

	Debug_Info_from_Server()
		: have_info( false ) ,
		  true_my_coordinate( 0.0 , 0.0 ) ,
		  true_my_body_angle( Angle::Radian , 0.0 ) ,
		  true_my_neck_angle( Angle::Radian , 0.0 ) ,
		  true_my_stamina( 0.0 ) ,
		  true_my_effort( 0.0 ) ,
		  true_my_speed( 0.0 ) ,
		  offside_position( false )
	{
	}
};



///////////////////////////////////////////////////////////////////////////////
//		       Information_from_Server				     //
///////////////////////////////////////////////////////////////////////////////
#include  "ref_count_ptr.h"

class  Information_from_Server
{
public:
	enum  Info_Type
	{
		Type_Unknown ,
		Type_Sight , Type_Audio , Type_Whistle , Type_Body ,
		Type_OK ,
		Type_Error ,
		Type_No_Info ,
		Type_Debug
	};

protected:
	Info_Type			type_of_info;
	int				time_of_info;
	std::string			raw_mes;

	ref_count_ptr< const Sight_Info_from_Server   >	sight;
	ref_count_ptr< const Audio_Info_from_Server   >	audio;
	ref_count_ptr< const Whistle_Info_from_Server >	whistle;
	ref_count_ptr< const Body_Info_from_Server    >	body;
	ref_count_ptr< const Error_Info_from_Server   >	err;
	ref_count_ptr< const Debug_Info_from_Server   >	debug;

public:
	 Information_from_Server();
	~Information_from_Server();

	void	reset_info(); // to Type_Unknown

	void	set_raw_message( const std::string & );
	void	set_time( int );

	void	set_sight_info
		    ( const ref_count_ptr<const Sight_Info_from_Server> & );
	void	set_audio_info
		    ( const ref_count_ptr<const Audio_Info_from_Server> & );
	void	set_whistle_info
		    ( const ref_count_ptr<const Whistle_Info_from_Server> & );
	void	set_body_info
		    ( const ref_count_ptr<const Body_Info_from_Server> & );
	void	set_error_info
		    ( const ref_count_ptr<const Error_Info_from_Server> & );
	void	set_debug_info
		    ( const ref_count_ptr<const Debug_Info_from_Server> & );
	void	set_no_info(); // to Type_No_Info

public:
	const std::string &	raw_message() const;

	Info_Type		type() const;
	int			time() const;
	bool			illegal() const;
	bool			no_info() const;

	const ref_count_ptr<const Sight_Info_from_Server  > &
						get_sight_info() const;
	const ref_count_ptr<const Audio_Info_from_Server  > &
						get_audio_info() const;
	const ref_count_ptr<const Whistle_Info_from_Server> &
						get_whistle_info() const;
	const ref_count_ptr<const Body_Info_from_Server   > &
						get_body_info() const;
	const ref_count_ptr<const Error_Info_from_Server  > &
						get_error_info() const;
	const ref_count_ptr<const Debug_Info_from_Server  > &
						get_debug_info() const;
};


#endif	/* INFORMATION_FROM_SERVER_H_INCLUDED */
