#ifndef	   QUANTIZE_H_INCLUDED
#define	   QUANTIZE_H_INCLUDED

#include  "sserver_param.h"

static	const	double	SERVER_EPS = (1.0e-10);

extern	double	far_object_distance( const SServer_Param &  param ,
				     double  x ,  bool  move_object = false );
extern	void	far_object_unquantized_distance(
			const SServer_Param &  param ,
			double  x ,  bool  move_object ,
			double *  x_min ,
			double *  x_max );

extern	double	quantize( double  x ,  double  q );
extern	void	unquantize( double  x ,  double  q ,
			    double *  x_min ,  double *  x_max );


#endif	/* QUANTIZE_H_INCLUDED */
