#ifndef	   SOCCER_COMMAND_H_INCLUDED
#define	   SOCCER_COMMAND_H_INCLUDED

#include  "s_basic.h"
#include  <string>

class  Soccer_Command
{
public:
	typedef  enum { Move_Command , Dash_Command , Kick_Command ,
			Turn_Command , Catch_Ball_Command ,
			Turn_Neck_Command , Change_View_Command ,
			Sense_Body_Command , Say_Command ,
			Wait_Command , No_Command_Command ,
			Illegal_Command } Command_Type;

protected:
	Command_Type	command;

	double		arg1;
	double		arg2;
	Angle		angle;
	std::string	mes;
	View_Width	view_width;
	View_Quality	view_quality;

public:
	 Soccer_Command()
		: command( No_Command_Command ) ,
		  arg1( 0.0 ) , arg2( 0.0 ) , angle( Angle::Radian , 0.0 ) ,
		  mes() ,
		  view_width( View_Width::Normal ) ,
		  view_quality( View_Quality::High )
		{
		}

virtual	~Soccer_Command()
		{
		}

virtual	Command_Type	type() const
		{
			return( command );
		}

virtual	Soccer_Command &  move( double  x ,  double  y )
		{
			command = Move_Command;
			arg1    = x;
			arg2    = y;
			return( *this );
		}

virtual	Soccer_Command &  dash( double  power )
		{
			command = Dash_Command;
			arg1    = power;
			return( *this );
		}

virtual	Soccer_Command &  kick( double  power ,  const Angle &  direction )
		{
			command = Kick_Command;
			arg1    = power;
			angle   = direction;
			return( *this );
		}

virtual	Soccer_Command &  turn( const Angle &  moment )
		{
			command = Turn_Command;
			angle   = moment;
			return( *this );
		}


virtual	Soccer_Command &  catch_command( const Angle &  direction )
		{
			command = Catch_Ball_Command;
			angle   = direction;
			return( *this );
		}

virtual	Soccer_Command &  turn_neck( const Angle &  direction )
		{
			command = Turn_Neck_Command;
			angle   = direction;
			return( *this );
		}

virtual	Soccer_Command &  change_view( View_Width  width ,
				       View_Quality  quality )
		{
			command      = Change_View_Command;
			view_quality = quality;
			view_width   = width;

			return( *this );
		}

virtual	Soccer_Command &  sense_body()
		{
			command = Sense_Body_Command;
			return( *this );
		}

virtual	Soccer_Command &  say( const std::string &  m )
		{
			command     = Say_Command;
			this -> mes = m;
			return( *this );
		}

virtual	Soccer_Command &  wait()
		{
			command = Wait_Command;
			return( *this );
		}

virtual	Soccer_Command &  no_command()
		{
			command = No_Command_Command;
			return( *this );
		}

virtual	Soccer_Command &  illegal()
		{
			command = Illegal_Command;
			return( *this );
		}

virtual	operator Soccer_Command::Command_Type() const
		{
			return( command );
		}

virtual	double	move_x() const
		{
			return( arg1 );
		}

virtual	double	move_y() const
		{
			return( arg2 );
		}

virtual	double	dash_power() const
		{
			return( arg1 );
		}

virtual	double	kick_power() const
		{
			return( arg1 );
		}

virtual	const Angle &	kick_direction() const
		{
			return( angle );
		}

virtual	const Angle &	turn_moment() const
		{
			return( angle );
		}

virtual	const Angle &	catch_direction() const
		{
			return( angle );
		}

virtual	const Angle &	turn_neck_direction() const
		{
			return( angle );
		}

virtual	View_Width	change_view_view_width() const
		{
			return( view_width );
		}

virtual	View_Quality	change_view_view_quality() const
		{
			return( view_quality );
		}

virtual	std::string	say_message() const
		{
			return( mes );
		}


static	Soccer_Command	Move( double  x ,  double  y )
		{
			Soccer_Command	com;
			com.move( x , y );
			return( com );
		}

static	Soccer_Command	Dash( double  power )
		{
			Soccer_Command	com;
			com.dash( power );
			return( com );
		}

static	Soccer_Command	Kick( double  power ,  const Angle &  direction )
		{
			Soccer_Command	com;
			com.kick( power , direction );
			return( com );
		}

static	Soccer_Command	Turn( const Angle &  moment )
		{
			Soccer_Command	com;
			com.turn( moment );
			return( com );
		}


static	Soccer_Command	Catch_Ball( const Angle &  direction )
		{
			Soccer_Command	com;
			com.catch_command( direction );
			return( com );
		}

static	Soccer_Command	Turn_Neck( const Angle &  direction )
		{
			Soccer_Command	com;
			com.turn_neck( direction );
			return( com );
		}

static	Soccer_Command	Change_View( View_Width  width ,
				     View_Quality  quality )
		{
			Soccer_Command	com;
			com.change_view( width , quality );
			return( com );
		}

static	Soccer_Command	Sense_Body()
		{
			Soccer_Command	com;
			com.sense_body();
			return( com );
		}

static	Soccer_Command	Say( const std::string &  m )
		{
			Soccer_Command	com;
			com.say( m );
			return( com );
		}

static	Soccer_Command	Wait()
		{
			Soccer_Command	com;
			com.wait();
			return( com );
		}

static	Soccer_Command	No_Command()
		{
			Soccer_Command	com;
			com.no_command();
			return( com );
		}

static	Soccer_Command	Illegal()
		{
			Soccer_Command	com;
			com.illegal();
			return( com );
		}
};


#if 0
class  Move_Command : public Soccer_Command
{
public:
	Move_Command( double  x ,  double  y )
		{ this -> move( x , y ); }
};

class  Dash_Command : public Soccer_Command
{
public:
	Dash_Command( double  power )
		{ this -> dash( power ); }
};

class  Kick_Command : public Soccer_Command
{
public:
	Kick_Command( double  power ,  const Angle &  direction )
		{ this -> kick( power , direction ); }
};

class  Turn_Command : public Soccer_Command
{
public:
	Turn_Command( const Angle &  moment )
		{ this -> turn( moment ); }
};

class  Catch_Command : public Soccer_Command
{
public:
	Catch_Command( const Angle &  direction )
		{ this -> catch_command( direction ); }
};

class  Turn_Neck_Command : public Soccer_Command
{
public:
	Turn_Neck_Command( const Angle &  direction )
		{ this -> turn_neck( direction ); }
};

class  Change_View_Command : public Soccer_Command
{
public:
	Change_View_Command( View_Width  width ,  View_Quality  quality )
		{ this -> change_view( width , quality ); }
};

class  Sense_Body_Command : public Soccer_Command
{
public:
	Sense_Body_Command()
		{ this -> sense_body(); }
};

class  Say_Command : public Soccer_Command
{
public:
	Say_Command( const std::string &  m )
		{ this -> say( m ); }
};

class  Wait_Command : public Soccer_Command
{
public:
	Wait_Command()
		{ this -> wait(); }
};

class  No_Command : public Soccer_Command
{
public:
	No_Command()
		{ this -> no_command(); }
};

class  Illegal_Command : public Soccer_Command
{
public:
	Illegal_Command()
		{ this -> illegal(); }
};
#endif


#endif	/* SOCCER_COMMAND_H_INCLUDED */
