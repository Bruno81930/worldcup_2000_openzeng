#ifndef	   SSERVER_TIME_H_INCLUDED
#define	   SSERVER_TIME_H_INCLUDED

//
// SServer_Time
//
struct  SServer_Time
{
public:
	long	step;
	long	sub_step;

public:
	SServer_Time()
		: step(0) , sub_step(0) {}

	SServer_Time( int  n )
		: step(n) , sub_step(0) {}

	void	set( long  st ,  long  sub_st = 0 ) throw()
		{
			this -> step     = st;
			this -> sub_step = sub_st;
		}

	bool	operator == ( const SServer_Time &  t ) const throw()
		{
			return(    this -> step     == t.step
				&& this -> sub_step == t.sub_step );
		}

	bool	operator != ( const SServer_Time &  t ) const throw()
		{
			return( ! ((*this) == t) );
		}
#if 0
	operator int () const throw()
		{
			return( this -> step );
		}
#endif
};


#endif	/* SSERVER_TIME_H_INCLUDED */
