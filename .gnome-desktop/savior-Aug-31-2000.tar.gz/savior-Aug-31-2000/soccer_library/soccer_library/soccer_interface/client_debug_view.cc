#include  "client_debug_view.h"
#include  "debug_server_connection.h"
#include  "field_recog_interface.h"
#include  "s_basic.h"
#include  "d2_region.h"
#include  <strstream>
#include  <iostream>
#include  <cfloat>
#include  <cstring>
#include  <stdexcept>
#include  <cassert>

using namespace std;

Client_Debug_View::Client_Debug_View( const SServer_Param &  param )
	: param( param ) ,
	  b_comment() , t_comment( MAX_PLAYER ) , o_comment( MAX_PLAYER )
{
}

Client_Debug_View::~Client_Debug_View()
{
}

void   Client_Debug_View::set_field_snapshot
       ( const ref_count_ptr<const Field_Recog_Abstract
					::Field_Recog_Snapshot> &  f )
{
	field = f;
}

ref_count_ptr<const Field_Recog_Abstract::Field_Recog_Snapshot>
	Client_Debug_View::field_snapshot() const
{
	return( field );
}

const std::string &  Client_Debug_View::ball_comment() const
{
	return( b_comment );
}

const std::string &  Client_Debug_View::teammate_comment( int  num ) const
{
	assert( 1 <= num && num <= MAX_PLAYER );
	return( t_comment[num -1] );
}

const std::string &  Client_Debug_View::opponent_comment( int  num ) const
{
	assert( 1 <= num && num <= MAX_PLAYER );
	return( o_comment[num -1] );
}


bool   Client_Debug_View::encode( std::string *  buf ) const
try
{
	if ( ! field )
	{
		*buf = "";

		return( false );
	}


	struct  Buffer
	{
		char *	message_buffer;

	public:
		Buffer() : message_buffer( static_cast<char *>(0) ) {}

		void	assign() throw( std::bad_alloc )
		{
			message_buffer
			    = new char[ Debug_Server_Connection
					    ::MAX_MESSAGE_LENGTH ];
		}

		~Buffer(){ delete[] message_buffer; }

	} raw_buf;

	raw_buf.assign();


	ostrstream	str( raw_buf.message_buffer ,
			     Debug_Server_Connection::MAX_MESSAGE_LENGTH );

#if 0
	str.precision( DBL_DIG );
#endif

	Field_Recog_Interface	f( field );

	string	side;
	switch( f.our_team().side_lr() )
	{
	case S_Side_LR::Left_Side:
		side = "left";
		break;

	case S_Side_LR::Right_Side:
		side = "right";
		break;

	case S_Side_LR::Unknown:
	default:
		*buf = "";
		return( false );
	}

	int	my_uniform_number = f.self().player_number();

	str << "((debug (format-version 1))";

	str << " (time " << f.current_time().step << ")";

	str << " (self"
	    <<  " (side " << side << ")"
	    <<  " (uniform-number " << my_uniform_number << ")"
	    <<  " (coordinate "
	    <<     f.self().x() << " "
	    <<     f.self().y() << ")"
	    <<  " (body-direction "
	    <<     f.self().body_angle().degree() << "))";

	if ( f.ball().coordinate().have_info() )
	{
		str << " "
		    << "(ball "
		    <<  "(coordinate "
		    <<    f.ball().x() << " "
		    <<    f.ball().y() << ")";

#if 0
		if ( f.ball().velocity().have_info() )
		{
			str << " "
			    << "(velocity "
			    <<   f.ball().velocity().x() << " "
			    <<   f.ball().velocity().y() << ")";
		}
#endif

		if ( f.ball().coordinate().have_info() )
		{
			str << " (comment "
			    <<    f.ball().coordinate().accuracy_level()
			    <<   ")";
		}

		str << ")";
	}

	for ( int  i = 1  ;  i <= MAX_PLAYER  ;  i ++ )
	{
		if ( f.teammate(i).coordinate().have_info() )
		{
			if ( i == my_uniform_number )
			{
				continue;
			}

			str << " "
			    << "(teammate"
			    << " (uniform-number " << i << ")"
			    << " (coordinate "
			    <<	  f.teammate(i).x() << " "
			    <<    f.teammate(i).y() << ")"
			    << " (comment "
			    <<    f.teammate(i).coordinate().accuracy_level()
			    <<  ")";

			if ( f.teammate(i).body_angle().accuracy_check() )
			{
				str << " "
				    << "(body-direction "
				    <<   f.teammate(i).body_angle().degree()
				    << ")";
			}

			str << ")";
		}
	}

	for ( int  i = 1  ;  i <= MAX_PLAYER  ;  i ++ )
	{
		if ( f.opponent(i).coordinate().have_info() )
		{
			str << " "
			    << "(opponent"
			    << " (uniform-number " << i << ")"
			    << " (coordinate "
			    <<    f.opponent(i).x() << " "
			    <<    f.opponent(i).y() << ")"
			    << " (comment "
			    <<    f.opponent(i).coordinate().accuracy_level()
			    <<  ")";

			if ( f.opponent(i).body_angle().accuracy_check() )
			{
				str << " "
				    << "(body-direction "
				    <<   f.opponent(i).body_angle().degree()
				    << ")";
			}

			str << ")";
		}
	}

	for ( size_t  i = 0  ;  i < f.n_unknown_player()  ;  i ++ )
	{
		if ( f.unknown_player(i).coordinate().have_info() )
		{
			str << " "
			    << "(unknown-player"
			    << " (coordinate "
			    <<    f.unknown_player(i).x() << " "
			    <<    f.unknown_player(i).y() << "))";
		}
	}

#if 0
	str << " "
	    << "(defence-line " << f.our_team().defence_line() << ")";

	str << " "
	    << "(offence-line " << f.our_team().offence_line() << ")";
#endif

	str << ")" << ends;


	*buf = str.str();

	return( true );
}
catch( const std::bad_alloc & )
{
	cerr << "Not enough memory for send debug info !!" << endl;

	*buf = "";

	return( false );
}


bool   Client_Debug_View::decode( const std::string &  buf )
{
	ref_count_ptr<Field_Recog_Abstract::Field_Recog_Snapshot>	f
		= new Field_Recog_Abstract::Field_Recog_Snapshot( param );

	int	read_offset = 0;

	if ( std::sscanf( buf.c_str() ,
			  " ( ( debug ( format-version 1 ) ) %n" ,
			  &read_offset) != 0 )
	{
		std::cerr << "bad format-version" << endl;

		return( false );
	}


	for(;;)
	{
	    // time
	    {
		int	current_time = -1;
		int	n_read = 0;

		if ( std::sscanf( buf.c_str() + read_offset ,
				  " ( time %d ) %n" ,
				  &current_time , &n_read ) == 1
		     && (n_read != 0) )
		{
			f -> game_state.current_time.set( current_time );

			read_offset += n_read;

			continue;
		}
	    }


	    // ball
	    {
		int	n_read = 0;
		if ( std::sscanf( buf.c_str() + read_offset ,
				  " ( ball %n" , &n_read ) == 0
		     && (n_read != 0) )
		{
			read_offset += n_read;

			for(;;)
			{
			    // coordinate
			    {
				int	n = 0;
				double	ball_x = 0.0;
				double	ball_y = 0.0;
				if ( std::sscanf
				     ( buf.c_str() + read_offset ,
						  "( coordinate %lf %lf ) %n" ,
						  &ball_x , &ball_y ,
						  &n ) == 2
				     && (n != 0) )
				{
					read_offset += n;
					f -> ball.coordinate
					 .set( D2_Region::universal_region() ,
					       D2_Vector( ball_x , ball_y ) );
					f -> ball.coordinate_accuracy = 0;

					continue;
				}
			    }

			    // comment
			    {
				int	n = 0;
				char	buffer[256 + 1];
				if ( std::sscanf
				     ( buf.c_str() + read_offset ,
				       "( comment %256[^) ] ) %n" ,
				       buffer , &n ) == 1
				     && (n != 0) )
				{
					read_offset += n;
					this -> b_comment = buffer;

					continue;
				}
			    }

			    // close paren
			    {
				    int	n = 0;
				    if ( std::sscanf
					 ( buf.c_str() + read_offset ,
					   " ) %n" , &n ) == 0
					 && (n != 0) )
				    {
					    read_offset += n;
					    break;
				    }
			    }

			    return( false );
			}

			continue;
		}
	    }


	    // self
	    {
		int	n_read = 0;
		if ( std::sscanf( buf.c_str() + read_offset ,
				  " ( self %n" , &n_read ) == 0
		     && (n_read != 0) )
		{
			read_offset += n_read;

			int	uniform_number = -1;
			for(;;)
			{
			    // side
			    {
				int	n = 0;
				char	side[256 + 1];
				if ( std::sscanf( buf.c_str() + read_offset ,
						  "( side %256[^) ] ) %n" ,
						  side , &n ) == 1
				     && (n != 0) )
				{
					read_offset += n;
					if ( std::strcmp( side ,
						     "left" ) == 0 )
					{
						f -> game_state
							.game_info.our_side
						       = S_Side_LR::Left_Side;
					}
					else if ( std::strcmp( side ,
							       "right" ) == 0 )
					{
						f -> game_state
							.game_info.our_side
						       = S_Side_LR::Right_Side;
					}
					else
					{
						std::cerr << "bad team side"
							  << endl;
						return( false );
					}

					continue;
				}
			    }

			    // uniform-number
			    {
				int	n = 0;

				if ( std::sscanf( buf.c_str() + read_offset ,
						  "( uniform-number %d ) %n" ,
						  &uniform_number ,
						  &n ) == 1
				     && (n != 0) )
				{
					read_offset += n;

					if ( uniform_number < 1
					  || uniform_number > MAX_PLAYER )
					{
						std::cerr
						 << "bad uniform-number"
						 << endl;
						return( false );
					}

					f -> game_state.game_info
					      .my_player_number
						= uniform_number;

					continue;
				}
			    }

			    // coordinate
			    {
				int	n = 0;
				double	player_x = 0.0;
				double	player_y = 0.0;
				if ( std::sscanf( buf.c_str() + read_offset ,
						  "( coordinate %lf %lf ) %n" ,
						  &player_x , &player_y ,
						  &n ) == 2
				     && (n != 0) )
				{
					read_offset += n;

					f -> body.my_coordinate
					  .set( D2_Region::universal_region() ,
						D2_Vector( player_x ,
							   player_y ) );

					if ( uniform_number < 1
					  || uniform_number > MAX_PLAYER )
					{
						std::cerr
						 << "uniform-number must be "
						    "specified before "
						    "coordinate" << endl;

						return( false );
					}

					f -> teammate[uniform_number - 1]
					 .coordinate
					  .set( D2_Region::universal_region() ,
						D2_Vector( player_x ,
							   player_y ) );

					f -> teammate[uniform_number - 1]
					 .coordinate_accuracy = 0;

					continue;
				}
			    }

			    // body-direction
			    {
				int	n = 0;
				double	body_direction = 0.0;
				if ( std::sscanf
				     ( buf.c_str() + read_offset ,
				       " ( body-direction %lf ) %n" ,
				       &body_direction , &n ) == 1
				     && (n != 0) )
				{
					read_offset += n;

					f -> body.my_body_angle
						.set( Degree(body_direction) ,
						      Degree(body_direction) ,
						      Degree(body_direction) );

					if ( uniform_number < 1
					  || uniform_number > MAX_PLAYER )
					{
						std::cerr
						 << "body_direction must be "
						    "specified before "
						    "coordinate" << endl;
						return( false );
					}

					f -> teammate[uniform_number - 1]
					 .body_angle
					  .set( Degree(body_direction) ,
						Degree(body_direction) ,
						Degree(body_direction) );

					continue;
				}
			    }

			    // close paren
			    {
				    int	n = 0;
				    if ( std::sscanf
					 ( buf.c_str() + read_offset ,
					   " ) %n" , &n ) == 0
					 && (n != 0) )
				    {
					    read_offset += n;
					    break;
				    }
			    }

			    return( false );
			}

			continue;
		}
	    }


	    // teammate player
	    {
		int	n_read = 0;
		if ( std::sscanf( buf.c_str() + read_offset ,
				  " ( teammate %n" , &n_read ) == 0
		     && (n_read != 0) )
		{
			read_offset += n_read;

			int	uniform_number = -1;
			for(;;)
			{
			    // uniform-number
			    {
				int	n = 0;

				if ( std::sscanf( buf.c_str() + read_offset ,
						  "( uniform-number %d ) %n" ,
						  &uniform_number ,
						  &n ) == 1
				     && (n != 0) )
				{
					read_offset += n;

					if ( uniform_number < 1
					  || uniform_number > MAX_PLAYER )
					{
						std::cerr
						 << "bad uniform-number"
						 << endl;
						return( false );
					}

					continue;
				}
			    }

			    // coordinate
			    {
				int	n = 0;
				double	player_x = 0.0;
				double	player_y = 0.0;
				if ( std::sscanf( buf.c_str() + read_offset ,
						  "( coordinate %lf %lf ) %n" ,
						  &player_x , &player_y ,
						  &n ) == 2
				     && (n != 0) )
				{
					read_offset += n;

					if ( uniform_number < 1
					  || uniform_number > MAX_PLAYER )
					{
						std::cerr
						 << "uniform-number must be "
						    "specified before "
						    "coordinate" << endl;

						return( false );
					}

					f -> teammate[uniform_number - 1]
					 .coordinate
					  .set( D2_Region::universal_region() ,
						D2_Vector( player_x ,
							   player_y ) );

					f -> teammate[uniform_number - 1]
					 .coordinate_accuracy = 0;

					continue;
				}
			    }

			    // body-direction
			    {
				int	n = 0;
				double	body_direction = 0.0;
				if ( std::sscanf
				     ( buf.c_str() + read_offset ,
				       " ( body-direction %lf ) %n" ,
				       &body_direction , &n ) == 1
				     && (n != 0) )
				{
					read_offset += n;

					f -> body.my_body_angle
						.set( Degree(body_direction) ,
						      Degree(body_direction) ,
						      Degree(body_direction) );

					if ( uniform_number < 1
					  || uniform_number > MAX_PLAYER )
					{
						std::cerr
						 << "body_direction must be "
						    "specified before "
						    "coordinate" << endl;
						return( false );
					}

					f -> teammate[uniform_number - 1]
					 .body_angle
					  .set( Degree(body_direction) ,
						Degree(body_direction) ,
						Degree(body_direction) );

					continue;
				}
			    }

			    // comment
			    {
				int	n = 0;
				char	buffer[256 + 1];

				if ( std::sscanf
				     ( buf.c_str() + read_offset ,
				       "( comment %256[^) ] ) %n" ,
				       buffer , &n ) == 1
				     && (n != 0) )
				{
					read_offset += n;
					if ( uniform_number < 1
					     || uniform_number > MAX_PLAYER )
					{
						std::cerr
						 << "uniform-number must be "
						    "specified before comment"
						 << endl;

						return( false );
					}

					this -> t_comment
						 [uniform_number - 1] = buffer;

					continue;
				}
			    }

			    // close paren
			    {
				    int	n = 0;
				    if ( std::sscanf
					 ( buf.c_str() + read_offset ,
					   " ) %n" , &n ) == 0
					 && (n != 0) )
				    {
					    read_offset += n;
					    break;
				    }
			    }

			    cout << "rest = ["
				 << buf.c_str() + read_offset
				 << "]" << endl;

			    return( false );
			}

			continue;
		}
	    }


	    // opponent player
	    {
		int	n_read = 0;
		if ( std::sscanf( buf.c_str() + read_offset ,
				  " ( opponent %n" , &n_read ) == 0
		     && (n_read != 0) )
		{
			read_offset += n_read;

			int	uniform_number = -1;
			for(;;)
			{
			    // uniform-number
			    {
				int	n = 0;

				if ( std::sscanf( buf.c_str() + read_offset ,
						  "( uniform-number %d ) %n" ,
						  &uniform_number ,
						  &n ) == 1
				     && (n != 0) )
				{
					read_offset += n;

					if ( uniform_number < 1
					  || uniform_number > MAX_PLAYER )
					{
						std::cerr
						 << "bad uniform-number"
						 << endl;
						return( false );
					}

					continue;
				}
			    }

			    // coordinate
			    {
				int	n = 0;
				double	player_x = 0.0;
				double	player_y = 0.0;
				if ( std::sscanf( buf.c_str() + read_offset ,
						  "( coordinate %lf %lf ) %n" ,
						  &player_x , &player_y ,
						  &n ) == 2
				     && (n != 0) )
				{
					read_offset += n;

					if ( uniform_number < 1
					  || uniform_number > MAX_PLAYER )
					{
						std::cerr
						 << "uniform-number must be "
						    "specified before "
						    "coordinate" << endl;

						return( false );
					}

					f -> opponent[uniform_number - 1]
					 .coordinate
					  .set( D2_Region::universal_region() ,
						D2_Vector( player_x ,
							   player_y ) );

					f -> opponent[uniform_number - 1]
					 .coordinate_accuracy = 0;

					continue;
				}
			    }

			    // body-direction
			    {
				int	n = 0;
				double	body_direction = 0.0;
				if ( std::sscanf
				     ( buf.c_str() + read_offset ,
				       " ( body-direction %lf ) %n" ,
				       &body_direction , &n ) == 1
				     && (n != 0) )
				{
					read_offset += n;

					f -> body.my_body_angle
						.set( Degree(body_direction) ,
						      Degree(body_direction) ,
						      Degree(body_direction) );

					if ( uniform_number < 1
					  || uniform_number > MAX_PLAYER )
					{
						std::cerr
						 << "body_direction must be "
						    "specified before "
						    "coordinate" << endl;
						return( false );
					}

					f -> opponent[uniform_number - 1]
					 .body_angle
					  .set( Degree(body_direction) ,
						Degree(body_direction) ,
						Degree(body_direction) );

					continue;
				}
			    }

			    // comment
			    {
				int	n = 0;
				char	buffer[256 + 1];

				if ( std::sscanf
				     ( buf.c_str() + read_offset ,
				       "( comment %256[^) ] ) %n" ,
				       buffer , &n ) == 1
				     && (n != 0) )
				{
					read_offset += n;

					if ( uniform_number < 1
					     || uniform_number > MAX_PLAYER )
					{
						std::cerr
						  << "uniform-number must be "
						     "specified before comment"
						  << endl;

						return( false );
					}

					this -> o_comment
						 [uniform_number - 1] = buffer;
					continue;
				}
			    }

			    // close paren
			    {
				    int	n = 0;
				    if ( std::sscanf
					 ( buf.c_str() + read_offset ,
					   " ) %n" , &n ) == 0
					 && (n != 0) )
				    {
					    read_offset += n;
					    break;
				    }
			    }

			    return( false );
			}

			continue;
		}
	    }


	    // unknown player
	    {
		int	n_read = 0;
		if ( std::sscanf( buf.c_str() + read_offset ,
				  " ( unknown-player %n" , &n_read ) == 0
		     && (n_read != 0) )
		{
			read_offset += n_read;

			for(;;)
			{
			    // coordinate
			    {
				int	n = 0;
				double	player_x = 0.0;
				double	player_y = 0.0;
				if ( std::sscanf( buf.c_str() + read_offset ,
						  "( coordinate %lf %lf ) %n" ,
						  &player_x , &player_y ,
						  &n ) == 2
				     && (n != 0) )
				{
					read_offset += n;

					Field_Recog_Abstract::Player_Info
						pl;

					pl.coordinate
					  .set( D2_Region::universal_region() ,
						D2_Vector( player_x ,
							   player_y ) );

					f -> unknown_player.push_back( pl );
					continue;
				}
			    }

			    // close paren
			    {
				    int	n = 0;
				    if ( std::sscanf
					 ( buf.c_str() + read_offset ,
					   " ) %n" , &n ) == 0
					 && (n != 0) )
				    {
					    read_offset += n;
					    break;
				    }
			    }

			    return( false );
			}

			continue;
		}
	    }


	    // close paren
	    {
		int	n_read = 0;
		if ( std::sscanf( buf.c_str() + read_offset ,
				  " ) %n" ,
				  &n_read ) == 0
		     && (n_read != 0) )
		{
			read_offset += n_read;
			break;
		}
	    }

	    return( false );
	}


	// if message is still remained,
	//   treat this message as a bad format one.
	if ( *(buf.c_str() + read_offset) != '\0' )
	{
		return( false );
	}

	field = f;

	return( true );
}
