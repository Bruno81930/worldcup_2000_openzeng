#include  "field_recog.h"
#include  "sight_info_analyzer.h"
#include  <cstddef>
#include  <algorithm>
#include  <cassert>

using namespace std;

Field_Recog::Field_Recog( const SServer_Param  &  param ,
			  const Game_Info &  g_info ,
			  bool  goalie_flag )
	: param( param ) , goalie_flag( goalie_flag ) ,
	  current_state( new Field_Recog_State( param ) ) ,
	  next_state( static_cast<Field_Recog_State *>(0) )
{
	current_state -> game_state.game_info = g_info;
	current_state -> game_state.goalie_flag = goalie_flag;

	// initialize body info
	current_state -> body.view_width.set( View_Width::Normal );
	current_state -> body.view_quality.set( View_Quality::High );
	current_state -> body.stamina.set( param.STAMINA_MAX() ,
					   param.STAMINA_MAX() ,
					   param.STAMINA_MAX() );
	current_state -> body.effort.set( 1.0 , 1.0 , 1.0 );
	current_state -> body.speed.set( 0.0 , 0.0 , 0.0 );
	current_state -> body.neck_angle.set( Radian(0.0) ,
					      Radian(0.0) ,
					      Radian(0.0) );

	// XXX
	current_state -> body.my_body_angle.set( Radian(0.0) ,
						 Radian(0.0) ,
						 Radian(0.0) );

	D2_Vector	init_pos = param.initial_position
						( g_info.our_side ,
						  g_info.my_player_number );
	current_state -> body.my_coordinate.set( init_pos , init_pos );

	current_state -> body.my_velocity.set( D2_Vector( 0.0, 0.0 ) ,
					       D2_Vector( 0.0, 0.0 ) );

	current_state -> ball.coordinate.set( D2_Vector( 0.0, 0.0 ) ,
					      D2_Vector( 0.0, 0.0 ) );
	current_state -> ball.velocity.set( D2_Vector( 0.0, 0.0 ) ,
					    D2_Vector( 0.0, 0.0 ) );

	next_state = new Field_Recog_State( *current_state );
}

Field_Recog::~Field_Recog()
{
}


//
// protocol between Soccer_Scheduler and Field_Recog
//
void   Field_Recog::register_info( const Information_from_Server &  info ,
				   const Time_Stamp &  time_stamp )
{
	switch( info.type() )
	{
	case Information_from_Server::Type_Sight:
		next_state -> buffer.sight_info = info.get_sight_info();
		next_state -> buffer.sight_info_time = info.time();
		next_state -> buffer.sight_info_time_stamp = time_stamp;
		if ( next_state -> buffer.info_time < info.time() )
		{
			next_state -> buffer.info_time = info.time();
		}
		break;

	case Information_from_Server::Type_Body:
		next_state -> buffer.body_info = info.get_body_info();
		next_state -> buffer.body_info_time = info.time();
		next_state -> buffer.body_info_time_stamp = time_stamp;
		if ( next_state -> buffer.info_time < info.time() )
		{
			next_state -> buffer.info_time = info.time();
		}
		break;

	case Information_from_Server::Type_Whistle:
		this -> register_whistle_info( next_state ,
					       info.get_whistle_info() ,
					       info.time() );

		if ( next_state -> buffer.info_time < info.time() )
		{
			next_state -> buffer.info_time = info.time();
		}
		break;

	case Information_from_Server::Type_Audio:
		// XXX
		if ( next_state -> buffer.info_time < info.time() )
		{
			next_state -> buffer.info_time = info.time();
		}
		break;

	case Information_from_Server::Type_Debug:
		next_state -> buffer.debug_info = info.get_debug_info();
		next_state -> buffer.debug_info_time = info.time();
		next_state -> buffer.debug_info_time_stamp = time_stamp;
		if ( next_state -> buffer.info_time < info.time() )
		{
			next_state -> buffer.info_time = info.time();
		}
		break;

	case Information_from_Server::Type_Unknown:
	default:
		// ignore this infomation
		break;
	}
}


void   Field_Recog::turn_neck_sent( const Angle &  moment ,
				    const Time_Stamp &  time_stamp )
{
	Angle	m = moment;

	if ( moment < param.MIN_NECK_MOMENT() )
	{
		m = param.MIN_NECK_MOMENT();
	}
	else if ( moment > param.MAX_NECK_MOMENT() )
	{
		m = param.MAX_NECK_MOMENT();
	}

	next_state -> buffer.turn_neck_moment     = m;
	next_state -> buffer.turn_neck_time_stamp = time_stamp;
}


void   Field_Recog::base_command_sent( const Soccer_Command &  command ,
				       const Time_Stamp &  time_stamp )
{
	static_cast<void>(time_stamp);	// needless
	next_state -> buffer.command = command;
}

void   Field_Recog::update()
{
	next_state -> update_state( current_state ,
				    param ,
				    next_state -> buffer.command );

	current_state = next_state;

	next_state = new Field_Recog_State( *current_state );
}


//
// protocol between User and Field_Recog
//
const SServer_Param &  Field_Recog::sserver_param() const
{
	return( param );
}

ref_count_ptr<const Field_Recog_Abstract::Field_Recog_Snapshot>
						Field_Recog::snapshot() const
{
	return( current_state );
}

Soccer_Composite_Command  Field_Recog::previous_command() const
{
	Soccer_Composite_Command	com( current_state -> buffer.command );

	if ( current_state -> buffer.turn_neck_sent )
	{
		com.add_turn_neck( current_state -> buffer.turn_neck_moment );
	}

	return( com );
}

const Field_Recog_Abstract::Ball_Info &  Field_Recog::ball_info() const
{
	return( current_state -> ball );
}

const vector<Field_Recog_Abstract::Player_Info> &  Field_Recog::teammate_info()
	const
{
	return( current_state -> teammate );
}

const vector<Field_Recog_Abstract::Player_Info> &  Field_Recog::opponent_info()
	const
{
	return( current_state -> opponent );
}

const vector<Field_Recog_Abstract::Player_Info> &
	Field_Recog::unknown_player_info() const
{
	return( current_state -> unknown_player );
}

const Field_Recog_Abstract::Body_Info &  Field_Recog::body_info() const
{
	return( current_state -> body );
}

const Field_Recog_Abstract::Sight_Info &  Field_Recog::sight_info() const
{
	return( current_state -> sight );
}

const Field_Recog_Abstract::Game_State_Info &  Field_Recog::game_state_info()
	const
{
	return( current_state -> game_state );
}

const Field_Recog_Abstract::Debug_Info &  Field_Recog::debug_info() const
{
	return( current_state -> debug );
}


// protected
void   Field_Recog::register_whistle_info(
		const ref_count_ptr<Field_Recog_State> &  state ,
		const ref_count_ptr< const Whistle_Info_from_Server > &  w ,
		int  info_time )
{
	if ( w -> type == Judgement_Type::Time_Up
	  || w -> type == Judgement_Type::Time_Up_Without_A_Team
	  || (w -> type == Judgement_Type::One_of_Play_Modes
	      && w -> play_mode == Play_Mode::Time_Over) )
	{
		state -> game_state.game_over_flag = true;
	}

	if ( w -> type == Judgement_Type::One_of_Play_Modes )
	{
		state -> game_state.game_info.play_mode = w -> play_mode;
		state -> game_state.play_mode_start_time = info_time;

		switch( w -> play_mode )
		{
		case Play_Mode::Before_Kick_Off:
		case Play_Mode::Time_Over:

		case Play_Mode::Opponent_Kick_Off:
		case Play_Mode::Opponent_Kick_In:
		case Play_Mode::Opponent_Free_Kick:
		case Play_Mode::Opponent_Corner_Kick:
		case Play_Mode::Opponent_Goal_Kick:
		case Play_Mode::Opponent_Goal:
		case Play_Mode::Opponent_Catch:

		case Play_Mode::Our_Kick_Off:
		case Play_Mode::Our_Kick_In:
		case Play_Mode::Our_Free_Kick:
		case Play_Mode::Our_Corner_Kick:
		case Play_Mode::Our_Goal_Kick:
		case Play_Mode::Our_Goal:
		case Play_Mode::Our_Catch:
			// reset ball velocity
			state -> buffer.ball_fixed = true;
			break;

		case Play_Mode::Play_On:
			// no operation
			break;
		}
	}
	else
	{
		state -> game_state.last_judgement = *w;
		state -> game_state.last_judgement_time = info_time;

		if ( w -> type == Judgement_Type::Goal )
		{
			if ( w -> side == S_Side::Our_Side )
			{
				state -> game_state.game_info.our_score
								= w -> score;
			}
			else
			{
				state -> game_state.game_info.opponent_score
								= w -> score;
			}

			state -> game_state.game_info.play_mode
					= Play_Mode::Before_Kick_Off;
			state -> game_state.play_mode_start_time = info_time;
		}
	}
}




//
// Field_Recog_State
//
const double	Field_Recog::Field_Recog_State::EPS = 1.0e-6;

Field_Recog::Field_Recog_State::Field_Recog_State( const SServer_Param &  p )
	: Field_Recog_Snapshot( p )
{
}

Field_Recog::Field_Recog_State::Field_Recog_State(
					  const Field_Recog_State &  old )
	: Field_Recog_Snapshot( old ) , buffer( /* new buffer */ )
{
}

Field_Recog::Field_Recog_State::~Field_Recog_State()
{
}

void   Field_Recog::Field_Recog_State::update_state(
	      const ref_count_ptr<const Field_Recog_State> &  old_state ,
	      const SServer_Param &  param ,
	      const Soccer_Composite_Command &  prev_com )
{
	//*******************************************************************//
	//  set current time
	//*******************************************************************//
	if ( buffer.info_time == old_state -> game_state.current_time.step )
	{
		game_state.current_time.sub_step ++;
	}
	else
	{
		game_state.current_time = buffer.info_time;
		game_state.current_time.sub_step = 0;
	}




	//*******************************************************************//
	//  last command accepted check
	//*******************************************************************//
	bool	last_command_accepted;

	// XXX
	(void)prev_com;
	last_command_accepted = true;




	//*******************************************************************//
	//  check have current * info
	//*******************************************************************//
	bool	have_current_body_info  = false;
	bool	have_current_sight_info = false;
	bool	have_current_debug_info = false;

	// XXX
	if ( buffer.body_info_time == game_state.current_time.step
	  && buffer.body_info )
	{
		have_current_body_info = true;
	}

	if ( buffer.sight_info_time == game_state.current_time.step
	  && buffer.sight_info )
	{
		have_current_sight_info = true;
	}

	if ( buffer.debug_info_time == game_state.current_time.step
	  && buffer.debug_info )
	{
		have_current_debug_info = true;
	}


	//*******************************************************************//
	//  set debug info
	//*******************************************************************//
	if ( have_current_debug_info )
	{
		debug.latest_debug = buffer.debug_info;
	}


	//*******************************************************************//
	//  set sight info
	//*******************************************************************//
	bool	sight_info_with_current_neck_angle;
	// XXX
	sight_info_with_current_neck_angle = true;

	ref_count_ptr<Sight_Info_Analyzer>	sight_analyzer(0);

	if ( have_current_sight_info )
	{
		sight_analyzer = new Sight_Info_Analyzer
					  ( buffer.sight_info ,
					    param ,
					    body.neck_angle.range() );
	}


	//*******************************************************************//
	//  ball fixed check
	//*******************************************************************//
	this -> update_ball_fixed( game_state.game_info.play_mode );


	//*******************************************************************//
	//  set goalie flag
	//*******************************************************************//
	this -> game_state.goalie_flag = old_state -> game_state.goalie_flag;




	//*******************************************************************//
	//  set body info
	//*******************************************************************//

	// XXX
	// body.body_info.view_width   = ...;
	// body.body_info.view_quality = ...;

	//
	// set stamina and effort
	//
	this -> update_stamina_effort( old_state ,
				       param ,
				       prev_com ,
				       last_command_accepted ,
				       have_current_body_info );

	//
	// set speed
	//
	this -> update_speed( old_state ,
			      param ,
			      prev_com ,
			      last_command_accepted ,
			      have_current_body_info );


	//
	// set neck_angle
	//
	this -> update_neck_angle( old_state , param ,
				   have_current_body_info );


	//
	// set body_angle
	//
	this -> update_body_angle( sight_analyzer , old_state , param ,
				   prev_com , last_command_accepted );


	//
	// set my velocity
	//
	this -> update_my_velocity( old_state , param );


	//
	// set my coordinate
	//
	this -> update_my_coordinate( sight_analyzer , old_state ,
				      prev_com , last_command_accepted );


	//
	// set ball coordinate and velocity
	//
	this -> update_ball_coordinate_and_velocity( old_state ,
						     param , sight_analyzer ,
						     buffer.ball_fixed ,
						     prev_com );


	//
	// set player coordinate
	//
	this -> update_player_coordinate( old_state , sight_analyzer );


	//*******************************************************************//
	//  check calculated result
	//*******************************************************************//
	if ( have_current_debug_info && have_current_body_info )
	{
		if ( ! body.my_body_angle.range().in_range
		         ( buffer.debug_info -> true_my_body_angle ,
			   Degree( EPS ) ) )
		{
			cerr << "!!! body_angle not in range" << endl;
		}

#if 0
		cout << "body_angle(min,max,point,true) = "
		     << body.my_body_angle.range.min().degree() << "\t"
		     << body.my_body_angle.range.max().degree() << "\t"
		     << body.my_body_angle.point.degree() << "\t"
		     << "(" << buffer.debug_info -> true_my_body_angle.degree()
		     << ")"
		     << endl;
#endif
#if 0
		cout << "body_angle(error,point,true) = "
		     << (body.my_body_angle.point
			 - buffer.debug_info -> true_my_body_angle).degree()
		     << "\t"
		     << body.my_body_angle.point.degree()
		     << "\t"
		     << buffer.debug_info -> true_my_body_angle.degree()
		     << endl;
#endif

#if 0
		cout << "stamina = "
		     << body.body_info.stamina.range.min() << "\t"
		     << body.body_info.stamina.range.max() << "\t"
		     << body.body_info.stamina.point << "\t"
		     << "(" << buffer.debug_info -> true_my_stamina << ")"
		     << endl;

		cout << endl;
#endif

#if 0
		cout << "neck_angle(min,max,point,true) = "
		     << body.body_info.neck_angle.range.min().degree() << "\t"
		     << body.body_info.neck_angle.range.max().degree() << "\t"
		     << body.body_info.neck_angle.point.degree() << "\t"
		     << "(" << buffer.debug_info
				-> true_my_neck_angle.degree() << ")"
		     << endl;

		cout << endl;
#endif

#if 0
		try
		{
			cout << "my_coordinate error = "
			     << (body.my_coordinate.point()
				 - buffer.debug_info -> true_my_coordinate).r()
			     << "\t["
			     << body.my_coordinate.point() << "]"
			     << "\t["
			     << buffer.debug_info -> true_my_coordinate << "]"
			     << endl;

			if ( (body.my_coordinate.point()
			      - buffer.debug_info -> true_my_coordinate).r()
			     >= 10.0 )
			{
				cout << "###" << endl;
			}

		} catch(...) {}
#endif
	}
}


void   Field_Recog::Field_Recog_State::update_ball_fixed(
						 const Play_Mode &  mode )
{
	switch( mode )
	{
	case Play_Mode::Before_Kick_Off:

	case Play_Mode::Opponent_Kick_Off:
	case Play_Mode::Opponent_Kick_In:
	case Play_Mode::Opponent_Free_Kick:
	case Play_Mode::Opponent_Corner_Kick:
	case Play_Mode::Opponent_Goal_Kick:
	case Play_Mode::Opponent_Goal:
	case Play_Mode::Opponent_Catch:

	case Play_Mode::Our_Kick_Off:
	case Play_Mode::Our_Kick_In:
	case Play_Mode::Our_Free_Kick:
	case Play_Mode::Our_Corner_Kick:
	case Play_Mode::Our_Goal_Kick:
	case Play_Mode::Our_Goal:
	case Play_Mode::Our_Catch:
		this -> buffer.ball_fixed = true;
		break;

	case Play_Mode::Play_On:
		this -> buffer.ball_fixed = false;
		break;
	}
}

void   Field_Recog::Field_Recog_State::update_stamina_effort(
	      const ref_count_ptr<const Field_Recog_State> &  old_state ,
	      const SServer_Param &  param ,
	      const Soccer_Composite_Command &  prev_com ,
	      bool  last_command_accepted ,
	      bool  have_current_body_info )
{
	if ( ! have_current_body_info )
	{
		return;
	}


	//
	// set effort
	//
	Double_Range	ef = param.server_effort_info_to_real_range
			       ( buffer.body_info -> effort );
	body.effort.set( ef , buffer.body_info -> effort );


	//
	// set stamina
	//
	Double_Range	st = old_state -> body.stamina.range();

	if ( last_command_accepted
	  && prev_com.base_type() == Soccer_Command::Dash_Command )
	{
		st -= param.dash_power_to_stamina_inc
			      ( prev_com.base_command().dash_power() );

		st.set( std::max( st.min() , 0.0 ) ,
			std::max( st.max() , 0.0 ) );
	}

	// XXX: when no effort,
	//        stamina does not increment STAMINA_INC_MAX()
	st += param.STAMINA_INC_MAX();

	st.set( std::min( st.min() , param.STAMINA_MAX() ) ,
		std::min( st.max() , param.STAMINA_MAX() ) );

	// XXX: check if culculated stamina is range from body info.
	body.stamina.set( st , buffer.body_info -> stamina );
	Double_Range	strict_stamina_range
			  = param.server_stamina_info_to_real_range(
				     buffer.body_info -> stamina );

	if ( strict_stamina_range.in_range( st.median() , EPS ) )
	{
		body.stamina.set( st , st.median() );
	}
	else
	{
#if 0
		cerr << "!!! stamina not in range" << endl;
#endif
		body.stamina.set( strict_stamina_range ,
				  strict_stamina_range.median() );
	}
}

void   Field_Recog::Field_Recog_State::update_speed(
	      const ref_count_ptr<const Field_Recog_State> &  old_state ,
	      const SServer_Param &  param ,
	      const Soccer_Composite_Command &  prev_com ,
	      bool  last_command_accepted ,
	      bool  have_current_body_info )
{
	if ( have_current_body_info )
	{
		Double_Range	sp = param.server_speed_info_to_real_range(
						   buffer.body_info -> speed );
		body.speed.set( sp , buffer.body_info -> speed );
	}
	else
	{
		// XXX
		(void)old_state;
		(void)prev_com;
		(void)last_command_accepted;

		Double_Range	sp( - param.PLAYER_SPEED_MAX() ,
				    + param.PLAYER_SPEED_MAX() );

		body.speed.set( sp , 0.0 );
	}
}

void   Field_Recog::Field_Recog_State::update_neck_angle(
	      const ref_count_ptr<const Field_Recog_State> &  old_state ,
	      const SServer_Param &  param ,
	      bool  have_current_body_info )
{
	const Angle_Range	valid_range( param.MIN_NECK_ANGLE() ,
					     param.MAX_NECK_ANGLE() );

	//
	// set neck_angle from
	//    old neck_angle & turn_neck_angle_moment
	//
	Angle_Range	neck_angle_range
			    = old_state -> body.neck_angle.range()
				    + buffer.turn_neck_moment;

	neck_angle_range = valid_range.clip( neck_angle_range );


	//
	// check if calculated neck_angle is in range from current body_info
	//
	if ( have_current_body_info )
	{
		Angle_Range	strict_neck_angle_range
				 = param.server_neck_angle_info_to_real_range
					  ( buffer.body_info -> neck_angle );

		if ( ! strict_neck_angle_range.in_range(
				neck_angle_range.median() , Degree(EPS) ) )
		{
			cerr << "!!! neck_angle not in range" << endl;

			// set neck_angle info from new body info
			neck_angle_range = strict_neck_angle_range;
		}
	}

	// set calculated neck_angle
	body.neck_angle.set( neck_angle_range , neck_angle_range.median() );
}

void   Field_Recog::Field_Recog_State::update_body_angle
		( const ref_count_ptr<Sight_Info_Analyzer> &  sight_analyzer ,
		  const ref_count_ptr<const Field_Recog_State> &  old_state ,
		  const SServer_Param &  param ,
		  const Soccer_Composite_Command &  prev_com ,
		  bool  last_command_accepted )
{
	// XXX
	if ( sight_analyzer )
	{
		sight_analyzer -> get_body_angle_range
					( &(body.my_body_angle) );
	}
	else
	{
		Soccer_Command	com = prev_com.base_command();

		if ( com == Soccer_Command::Turn_Command
		     && last_command_accepted )
		{
			Angle	angle_min;
			Angle	angle_max;
			Angle	angle_pt;

			angle_min = param.turn_moment_to_angle
				     ( com.turn_moment() ,
				       old_state -> body.speed.range().min() );

			angle_min = param.turn_moment_to_angle
				     ( com.turn_moment() ,
				       old_state -> body.speed.range().min() );

			angle_pt = param.turn_moment_to_angle
				   ( com.turn_moment() ,
				     old_state -> body.speed.point() );

			if ( angle_min > angle_max )
			{
				std::swap( angle_min , angle_max );
			}

			Angle	angle_min_error = angle_min - angle_pt;
			Angle	angle_max_error = angle_max - angle_pt;

			Angle_Info	old = old_state -> body.my_body_angle;

			body.my_body_angle.set( old.range().min()
						  + angle_min_error ,
						old.range().max()
						  + angle_max_error ,
						angle_pt );
		}
		else
		{
			body.my_body_angle = old_state -> body.my_body_angle;
		}
	}
}

void   Field_Recog::Field_Recog_State::update_my_coordinate
		( const ref_count_ptr<Sight_Info_Analyzer> &  sight_analyzer ,
		  const ref_count_ptr<const Field_Recog_State> &  old_state ,
		  const Soccer_Composite_Command &  prev_com ,
		  bool  last_command_accepted )
{
	if ( prev_com.base_command() == Soccer_Command::Move_Command
	     && last_command_accepted )
	{
		D2_Vector	p( prev_com.base_command().move_x() ,
				   prev_com.base_command().move_y() );

		body.my_coordinate.set( p , p );
		return;
	}

	// XXX
	if ( sight_analyzer )
	{
		sight_analyzer -> get_my_coordinate( &(body.my_coordinate) );
	}
	else
	{
		// XXX
		body.my_coordinate = old_state -> body.my_coordinate;
	}

}

void   Field_Recog::Field_Recog_State::update_my_velocity
		( const ref_count_ptr<const Field_Recog_State> &  old_state ,
		  const SServer_Param &  param )
{
	(void)old_state;
	(void)param;

	// XXX
	body.my_velocity.set( D2_Region::universal_region() ,
			      D2_Vector( D2_Vector::Pole ,
					 body.speed.point() ,
					 body.my_body_angle.point() ) );
}

#if 0
void   Field_Recog::Field_Recog_State::update_ball_coordinate_and_velocity
		( const ref_count_ptr<const Field_Recog_State> &  old_state ,
		  const SServer_Param &  param ,
		  const ref_count_ptr<Sight_Info_Analyzer> &  sight_analyzer ,
		  bool  ball_fixed ,
		  const Soccer_Composite_Command &  prev_com )
{
	bool	have_ball_sight_info = false;

	if ( sight_analyzer )
	{
		sight_analyzer -> get_ball_info( &ball );

		if ( ball.coordinate.valid() )
		{
			have_ball_sight_info = true;

			ball.last_coordinate_info_time
				= game_state.current_time;
			ball.coordinate_accuracy = 0;
		}

		if ( ball.velocity.valid() )
		{
			ball.last_velocity_info_time
				= game_state.current_time;
			ball.velocity_accuracy = 0;
		}
	}
	else
	{
		ball.coordinate.reset();
		ball.velocity.reset();

		ball.coordinate_accuracy = Ball_Info::INVALID_ACCURACY;
		ball.velocity_accuracy   = Ball_Info::INVALID_ACCURACY;
	}

	if ( have_ball_sight_info )
	{
		this -> buffer.ball_seen_count
			= old_state -> buffer.ball_seen_count + 1;
	}
	else
	{
		this -> buffer.ball_seen_count = 0;
	}


	if ( ball_fixed )
	{
		ball.velocity.set( D2_Vector::origin() ,
				   D2_Vector::origin() );

		ball.velocity_accuracy = 0;
	}


	bool	use_calculated_ball_coordinate = false;
	bool	use_calculated_ball_velocity   = false;

	//
	// set original coordinate, velocity
	//
	D2_Vector	ball_coordinate_org;

	if ( ball.coordinate.valid() )
	{
		ball_coordinate_org = ball.coordinate.point();
	}
	else
	{
		use_calculated_ball_coordinate = true;
	}

	// if ball is in short sensor, not trust.
	if ( prev_com.base_type() == Soccer_Command::Kick_Command
	  && old_state -> ball.coordinate.valid()
	  && ball.coordinate.valid() )
	{
		use_calculated_ball_coordinate = true;
	}


	//
	// calculate ball velocity
	//
	D2_Vector	old_ball_velocity;

	if ( old_state -> ball.velocity.valid() )
	{
		old_ball_velocity = old_state -> ball.velocity.point();
	}
	else
	{
		old_ball_velocity = D2_Vector( 0.0 , 0.0 );
	}

	// XXX: must check kickable or not.
	if ( prev_com.base_command().type() == Soccer_Command::Kick_Command )
	{
		D2_Vector	old_ball_relative
		= (old_state -> ball.coordinate.point()
		   - old_state -> body.my_coordinate.point())
		  .rotate( - old_state -> body.my_body_angle.point() );

		double	accel = param.kick_power_to_accel
				  ( prev_com.base_command().kick_power() ,
				    old_ball_relative.r() ,
				    old_ball_relative.theta().normalize() );

		D2_Vector	kick_vec( D2_Vector::Pole ,
					  accel ,
					  old_state
					    -> body.my_body_angle.point()
					  + prev_com.base_command()
						       .kick_direction() );

		old_ball_velocity += kick_vec;
	}

	D2_Vector	calculated_ball_velocity
			  = old_ball_velocity * sserver_param.BALL_DECAY();

	if ( use_calculated_ball_velocity )
	{
		if ( old_state -> ball.velocity_accuracy
		     != Ball_Info::INVALID_ACCURACY )
		{
			ball.velocity_accuracy
				= old_state -> ball.velocity_accuracy - 1;
		}

		ball.velocity.set( D2_Region::universal_region() /* XXX */ ,
				   old_ball_velocity
				     * sserver_param.BALL_DECAY() );
	}


	//
	// coordinate update from old state
	//
	bool		have_culculated_ball_coordinate = false;
	D2_Vector	culculated_ball_coordinate;

	if ( use_calculated_ball_coordinate )
	{
		culculated_ball_coordinate
			= old_state -> ball.coordinate.point()
			  + old_ball_velocity;

		have_culculated_ball_coordinate = true;

		if ( old_state -> ball.coordinate_accuracy
		     != Ball_Info::INVALID_ACCURACY )
		{
			ball.coordinate_accuracy
				= old_state -> ball.coordinate_accuracy - 1;
		}

		ball.coordinate.set( D2_Region::universal_region() /* XXX */ ,
				     old_state -> ball.coordinate.point()
				     + old_ball_velocity );
	}


	if ( this -> buffer.ball_seen_count >= 2
	  && old_state -> ball.velocity.valid()
	  && have_culculated_ball_coordinate )
	{
		ball.coordinate.set( ball.coordinate.region() ,
				     ball_coordinate_org
				      / this -> buffer.ball_seen_count
				     + culculated_ball_coordinate
				      / (this -> buffer.ball_seen_count - 1) );
	}


	// if calculated ball coordinate is too far from original,
	// reset it
	if ( use_calculated_ball_coordinate && have_ball_sight_info )
	{
		if ( (ball.coordinate.point() - body.my_coordinate.point()).r()
		     <= param.SHORT_SENSOR_LENGTH()
		  && (ball.coordinate.point() - ball_coordinate_org).r()
		     >= 0.15 )
		{
			ball.coordinate.set( ball.coordinate.region() ,
					     ball_coordinate_org );
		}

		ball.coordinate_accuracy = 0;
	}


	// if calculated ball coordinate is in short senser
	//    and ball is not found in short senser,
	// decrease ball accuracy
	if ( ! have_ball_sight_info
	     && (ball.coordinate.point() - body.my_coordinate.point()).r()
		<= param.SHORT_SENSOR_LENGTH() - 0.1 )
	{
		cerr << "ball coordinate canceled!!" << endl;

		ball.coordinate_accuracy = Ball_Info::INVALID_ACCURACY;
	}
}
#else
void   Field_Recog::Field_Recog_State::update_ball_coordinate_and_velocity
		( const ref_count_ptr<const Field_Recog_State> &  old_state ,
		  const SServer_Param &  param ,
		  const ref_count_ptr<Sight_Info_Analyzer> &  sight_analyzer ,
		  bool  ball_fixed ,
		  const Soccer_Composite_Command &  prev_com )
{
	bool	ball_not_found = true;

	if ( sight_analyzer )
	{
		sight_analyzer -> get_ball_info( &ball );

		if ( ball.coordinate.valid() )
		{
			ball_not_found = false;

			ball.last_coordinate_info_time
				= game_state.current_time;
			ball.coordinate_accuracy = 0;
		}

		if ( ball.velocity.valid() )
		{
			ball.last_velocity_info_time
				= game_state.current_time;
			ball.velocity_accuracy = 0;
		}
	}
	else
	{
		ball.coordinate.reset();
		ball.velocity.reset();

		ball.coordinate_accuracy = Ball_Info::INVALID_ACCURACY;
		ball.velocity_accuracy   = Ball_Info::INVALID_ACCURACY;
	}

	if ( ball_fixed )
	{
		ball.velocity.set( D2_Vector::origin() ,
				   D2_Vector::origin() );

		ball.velocity_accuracy = 0;
	}

	// if ball is in short sensor, not trust.
	D2_Vector	ball_coordinate_backup;
	bool		use_calculated_ball_coordinate = false;

	if ( prev_com.base_type() == Soccer_Command::Kick_Command
	  && old_state -> ball.coordinate.valid()
	  && ball.coordinate.valid() )
	{
		ball_coordinate_backup = ball.coordinate.point();
		use_calculated_ball_coordinate = true;
	}

	if ( ball.velocity.valid() && ! use_calculated_ball_coordinate )
	{
		return;
	}


	//
	// update ball velocity
	//
	D2_Vector	old_ball_velocity;

	if ( old_state -> ball.velocity.valid() )
	{
		old_ball_velocity = old_state -> ball.velocity.point();
	}
	else
	{
		old_ball_velocity = D2_Vector( 0.0 , 0.0 );
	}

	// XXX: must check kickable or not.
	if ( prev_com.base_command().type() == Soccer_Command::Kick_Command )
	{
		D2_Vector	old_ball_relative
		= (old_state -> ball.coordinate.point()
		   - old_state -> body.my_coordinate.point())
		  .rotate( - old_state -> body.my_body_angle.point() );

		double	accel = param.kick_power_to_accel
				  ( prev_com.base_command().kick_power() ,
				    old_ball_relative.r() ,
				    old_ball_relative.theta().normalize() );

		D2_Vector	kick_vec( D2_Vector::Pole ,
					  accel ,
					  old_state
					    -> body.my_body_angle.point()
					  + prev_com.base_command()
						       .kick_direction() );

		old_ball_velocity += kick_vec;
	}

	if ( ! ball_fixed )
	{
		if ( old_state -> ball.velocity_accuracy
		     != Ball_Info::INVALID_ACCURACY )
		{
			ball.velocity_accuracy
				= old_state -> ball.velocity_accuracy - 1;
		}

		ball.velocity.set( D2_Region::universal_region() /* XXX */ ,
				   old_ball_velocity
				     * sserver_param.BALL_DECAY() );
	}


	//
	// coordinate update from old state
	//
	if ( (! ball.coordinate.valid() || use_calculated_ball_coordinate)
	  && old_state -> ball.coordinate.valid() )
	{
		ball.coordinate.set( D2_Region::universal_region() /* XXX */ ,
				     old_state -> ball.coordinate.point()
				     + old_ball_velocity );

		if ( old_state -> ball.coordinate_accuracy
		     != Ball_Info::INVALID_ACCURACY )
		{
			ball.coordinate_accuracy
				= old_state -> ball.coordinate_accuracy - 1;
		}
	}

	if ( use_calculated_ball_coordinate )
	{
		if ( (ball.coordinate.point() - ball_coordinate_backup).r()
		     >= 0.15 )
		{
			ball.coordinate.set( ball.coordinate.region() ,
					     ball_coordinate_backup );
		}

		ball.coordinate_accuracy = 0;
	}


	// if calculated ball coordinate is in short senser
	//    and ball is not found in short senser,
	// decrease ball accuracy
	if ( ball_not_found
	     && (ball.coordinate.point() - body.my_coordinate.point()).r()
		<= param.SHORT_SENSOR_LENGTH() - 0.01 )
	{
		cerr << "ball coordinate canceled!!" << endl;

		ball.coordinate_accuracy = Ball_Info::INVALID_ACCURACY;
	}
}
#endif

void   Field_Recog::Field_Recog_State::update_player_coordinate
		( const ref_count_ptr<const Field_Recog_State> &  old_state ,
		  const ref_count_ptr<Sight_Info_Analyzer> &  sight_analyzer )
{
	// XXX
	if ( sight_analyzer )
	{
		sight_analyzer -> get_player_info( &teammate , &opponent ,
						   &unknown_player );
	}
	else
	{
		for ( size_t  i = 0  ;  i < teammate.size()  ;  i ++ )
		{
			teammate[i].coordinate.reset();
			teammate[i].velocity.reset();
			teammate[i].body_angle.reset();
			teammate[i].face_angle.reset();
			teammate[i].coordinate_accuracy
				= Player_Info::INVALID_ACCURACY;
			teammate[i].coordinate_accuracy
				= Player_Info::INVALID_ACCURACY;
		}

		for ( size_t  i = 0  ;  i < opponent.size()  ;  i ++ )
		{
			opponent[i].coordinate.reset();
			opponent[i].velocity.reset();
			opponent[i].body_angle.reset();
			opponent[i].face_angle.reset();
			opponent[i].coordinate_accuracy
				= Player_Info::INVALID_ACCURACY;
			opponent[i].coordinate_accuracy
				= Player_Info::INVALID_ACCURACY;
		}
	}


	// XXX
	for ( size_t  i = 0  ;  i < teammate.size()  ;  i ++ )
	{
		if ( teammate[i].coordinate.valid() )
		{
			teammate[i].coordinate_accuracy = 0;
		}
		else
		{
			teammate[i].coordinate
				= old_state -> teammate[i].coordinate;

			if ( old_state -> teammate[i].coordinate_accuracy
			     == Player_Info::INVALID_ACCURACY )
			{
				teammate[i].coordinate_accuracy
					= Player_Info::INVALID_ACCURACY;
			}
			else
			{
				teammate[i].coordinate_accuracy
				 = old_state -> teammate[i].coordinate_accuracy
					- 1;
			}
		}
	}

	for ( size_t  i = 0  ;  i < opponent.size()  ;  i ++ )
	{
		if ( opponent[i].coordinate.valid() )
		{
			opponent[i].coordinate_accuracy = 0;
		}
		else
		{
			opponent[i].coordinate
				= old_state -> opponent[i].coordinate;

			if ( old_state -> opponent[i].coordinate_accuracy
			     == Player_Info::INVALID_ACCURACY )
			{
				opponent[i].coordinate_accuracy
					= Player_Info::INVALID_ACCURACY;
			}
			else
			{
				opponent[i].coordinate_accuracy
				 = old_state -> opponent[i].coordinate_accuracy
					- 1;
			}
		}
	}

	int	my_player_number = game_state.game_info.my_player_number;

	assert( 1 <= my_player_number
		&& static_cast<size_t>(my_player_number) <= teammate.size() );

	teammate[ my_player_number - 1 ].coordinate = body.my_coordinate;
	teammate[ my_player_number - 1 ].velocity   = body.my_velocity;
	teammate[ my_player_number - 1 ].body_angle = body.my_body_angle;
	teammate[ my_player_number - 1 ].face_angle = body.neck_angle;

	teammate[ my_player_number - 1 ].coordinate_accuracy
	  = (body.my_coordinate.valid() ? 0 : Player_Info::INVALID_ACCURACY);
	teammate[ my_player_number - 1 ].velocity_accuracy
	  = (body.my_velocity.valid() ? 0 : Player_Info::INVALID_ACCURACY);
}
