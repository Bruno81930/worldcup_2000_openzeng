#include  "field_recog_interface.h"
#include  <cassert>
#include  <set>

using namespace std;

//
// Field_Recog_Interface
//
Field_Recog_Interface::Field_Recog_Interface
				( const Field_Recog_Abstract *  field )
	: field( field )
{
}

Field_Recog_Interface::Field_Recog_Interface
		( const ref_count_ptr<const Field_Recog_Abstract
					    ::Field_Recog_Snapshot> &  snap )
	: field( static_cast<const Field_Recog_Abstract *>(0) ) ,
	  snap( snap )
{
}

Field_Recog_Interface::Field_Recog_Interface()
	: field( static_cast<Field_Recog_Abstract *>(0) )
{
}


Field_Recog_Interface::~Field_Recog_Interface()
{
}

const Field_Recog_Interface *  Field_Recog_Interface::operator -> () const
{
	return( this );
}


const Field_Recog_Abstract::Field_Recog_Snapshot &
					Field_Recog_Interface::snapshot() const
{
	if ( field )
	{
		return( *(this -> field -> snapshot()) );
	}
	else
	{
		return( *(this -> snap) );
	}
}

const SServer_Param &  Field_Recog_Interface::sserver_param() const
{
	return( this -> snapshot().sserver_param );
}

bool   Field_Recog_Interface::game_over() const
{
	return( this -> snapshot().game_state.game_over_flag );
}

SServer_Time  Field_Recog_Interface::current_time() const
{
	return( this -> snapshot().game_state.current_time );
}

const Play_Mode_Reference  Field_Recog_Interface::play_mode() const
{
	return( Play_Mode_Reference( *this ) );
}

const Ball_Reference  Field_Recog_Interface::ball() const
{
	return( Ball_Reference( *this ) );
}

const Player_Reference  Field_Recog_Interface::self() const
{
	return( Player_Reference
		( *this ,
		  S_Side::Our_Side ,
		  this -> snapshot().game_state.game_info.my_player_number ) );
}

const Player_Reference  Field_Recog_Interface::teammate( int  player_number )
	const
{
	return( Player_Reference( *this ,
				  S_Side::Our_Side , player_number ) );
}

const Player_Reference  Field_Recog_Interface::opponent( int  player_number )
	const
{
	return( Player_Reference( *this ,
				  S_Side::Opponent_Side , player_number ) );
}

const Player_Reference  Field_Recog_Interface::player( const S_Side &  side ,
						       int  player_number )
	const
{
	return( Player_Reference( *this , side , player_number ) );
}

size_t  Field_Recog_Interface::n_unknown_player() const
{
	return( this -> snapshot().unknown_player.size() );
}

const Player_Reference  Field_Recog_Interface::unknown_player( int  indx )
	const
{
	return( Player_Reference( *this , S_Side::Unknown , indx ) );
}

const Team_Reference  Field_Recog_Interface::our_team() const
{
	return( Team_Reference( *this , S_Side::Our_Side ) );
}

const Team_Reference  Field_Recog_Interface::opponent_team() const
{
	return( Team_Reference( *this , S_Side::Opponent_Side ) );
}

const Team_Reference  Field_Recog_Interface::team( const S_Side &  side ) const
{
	return( Team_Reference( *this , side ) );
}


//
// Soccer_Object_Reference
//
Soccer_Object_Reference::Soccer_Object_Reference
			( const Field_Recog_Interface &  f )
	: field( f )
{
}

Soccer_Object_Reference::~Soccer_Object_Reference()
{
}

const Field_Recog_Abstract::Field_Recog_Snapshot &
	Soccer_Object_Reference::snapshot() const
{
	return( this -> field -> snapshot() );
}

Soccer_Object_Reference::D2_Vector_with_Accuracy
	Soccer_Object_Reference::coordinate() const
{
	return( D2_Vector_with_Accuracy( D2_Vector::origin() , 0 ) );
}

Soccer_Object_Reference::D2_Region_with_Accuracy
	Soccer_Object_Reference::coordinate_region() const
{
	return( D2_Region_with_Accuracy( D2_Region::empty_region() , 0 ) );
}

Soccer_Object_Reference::D2_Vector_with_Accuracy
	Soccer_Object_Reference::velocity() const
{
	return( D2_Vector_with_Accuracy( D2_Vector::origin() , 0 ) );
}

Soccer_Object_Reference::D2_Region_with_Accuracy
	Soccer_Object_Reference::velocity_region() const
{
	return( D2_Region_with_Accuracy( D2_Region::empty_region() , 0 ) );
}

double  Soccer_Object_Reference::x() const
{
	return( this -> coordinate().x() );
}

double  Soccer_Object_Reference::y() const
{
	return( this -> coordinate().y() );
}


//
// Ball_Reference
//
Ball_Reference::Ball_Reference( const Field_Recog_Interface &  f )
	: Soccer_Object_Reference( f )
{
}

Ball_Reference::~Ball_Reference()
{
}


Soccer_Object_Reference::D2_Vector_with_Accuracy
	Ball_Reference::coordinate() const
{
	if ( snapshot().ball.coordinate.valid() )
	{
		return( Soccer_Object_Reference::D2_Vector_with_Accuracy
			( snapshot().ball.coordinate.point() ,
			  snapshot().ball.coordinate_accuracy ) );
	}
	else
	{
		return( Soccer_Object_Reference::D2_Vector_with_Accuracy
			( snapshot().ball.coordinate.point() ,
			  Soccer_Object_Reference::D2_Region_with_Accuracy
			    ::INVALID_ACCURACY ) );
	}
}

Soccer_Object_Reference::D2_Region_with_Accuracy
	Ball_Reference::coordinate_region() const
{
	if ( snapshot().ball.coordinate.valid() )
	{
		return( Soccer_Object_Reference::D2_Region_with_Accuracy
			( snapshot().ball.coordinate.region() ,
			  snapshot().ball.coordinate_accuracy ) );
	}
	else
	{
		return( Soccer_Object_Reference::D2_Region_with_Accuracy
			( snapshot().ball.coordinate.region() ,
			  Soccer_Object_Reference::D2_Region_with_Accuracy
			    ::INVALID_ACCURACY ) );
	}
}

Soccer_Object_Reference::D2_Vector_with_Accuracy
	Ball_Reference::velocity() const
{
	if ( snapshot().ball.velocity.valid() )
	{
		return( Soccer_Object_Reference::D2_Vector_with_Accuracy
			( snapshot().ball.velocity.point() ,
			  snapshot().ball.velocity_accuracy ) );
	}
	else
	{
		return( Soccer_Object_Reference::D2_Vector_with_Accuracy
			( snapshot().ball.velocity.point() ,
			  Soccer_Object_Reference::D2_Vector_with_Accuracy
			    ::INVALID_ACCURACY ) );
	}
}

Soccer_Object_Reference::D2_Region_with_Accuracy
	Ball_Reference::velocity_region() const
{
	if ( snapshot().ball.velocity.valid() )
	{
		return( Soccer_Object_Reference::D2_Region_with_Accuracy
			( snapshot().ball.velocity.region() ,
			  snapshot().ball.velocity_accuracy ) );
	}
	else
	{
		return( Soccer_Object_Reference::D2_Region_with_Accuracy
			( snapshot().ball.velocity.region() ,
			  Soccer_Object_Reference::D2_Region_with_Accuracy
			    ::INVALID_ACCURACY ) );
	}
}


//
// Player_Reference
//
const Field_Recog_Abstract::Player_Info  Player_Reference::unknown_player;

Player_Reference::Player_Reference( const Field_Recog_Interface &  f ,
				    const S_Side &  side ,  int  num )
	: Soccer_Object_Reference( f )
{
	if ( side != S_Side::Unknown )
	{
		this -> known = false;
		this -> ident.side = side;
		this -> ident.player_number = num;
		this -> unknown_index = 0;
	}
	else
	{
		this -> known = true;
		this -> ident.side = side;
		this -> ident.player_number = -1;
		this -> unknown_index = num;
	}
}

Player_Reference::~Player_Reference()
{
}


S_Side  Player_Reference::side() const
{
	return( ident.side );
}

S_Side_LR  Player_Reference::side_lr() const
{
	S_Side_LR	our_side = snapshot().game_state.game_info.our_side;

	if ( this -> side() == S_Side::Unknown
	  || our_side == S_Side_LR::Unknown )
	{
		return( S_Side_LR::Unknown );
	}

	if ( this -> side() == S_Side::Our_Side )
	{
		return( our_side );
	}
	else
	{
		if ( our_side == S_Side_LR::Left_Side )
		{
			return( S_Side_LR::Right_Side );
		}
		else
		{
			return( S_Side_LR::Left_Side );
		}
	}
}

Team_Reference  Player_Reference::team() const
{
	return( Team_Reference( this -> Soccer_Object_Reference::field ,
				this -> side() ) );
}

int    Player_Reference::player_number() const
{
	return( ident.player_number );
}

bool   Player_Reference::self_player() const
{
	return( this -> side() == S_Side::Our_Side
	     && this -> player_number() != -1
	     && this -> player_number()
		 == this -> snapshot().game_state.game_info.my_player_number );
}

// internal
const Field_Recog_Abstract::Player_Info &  Player_Reference::player_info()
	const
{
	switch( this -> side() )
	{
	case S_Side::Our_Side:
		assert( 1 <= this -> player_number()
			&& this -> player_number() <= MAX_PLAYER );

		return( snapshot().teammate[ this -> player_number() - 1 ] );
		break;

	case S_Side::Opponent_Side:
		assert( 1 <= this -> player_number()
			&& this -> player_number() <= MAX_PLAYER );

		return( snapshot().opponent[ this -> player_number() - 1 ] );

	default:
	case S_Side::Unknown:
		assert( 0 <= this -> unknown_index
			&& this -> unknown_index
			   < static_cast<int>
			     ( snapshot().unknown_player.size() ) );
		return( snapshot().unknown_player[ this -> unknown_index ] );
		break;
	}
}

Soccer_Object_Reference::D2_Vector_with_Accuracy
	Player_Reference::coordinate() const
{
	if ( this -> player_info().coordinate.valid() )
	{
		return( Soccer_Object_Reference::D2_Vector_with_Accuracy
			( this -> player_info().coordinate.point() ,
			  this -> player_info().coordinate_accuracy ) );
	}
	else
	{
		return( Soccer_Object_Reference::D2_Vector_with_Accuracy
			( this -> player_info().coordinate.point() ,
			  Soccer_Object_Reference::D2_Vector_with_Accuracy
			    ::INVALID_ACCURACY ) );
	}
}

Soccer_Object_Reference::D2_Region_with_Accuracy
	Player_Reference::coordinate_region() const
{
	if ( this -> player_info().coordinate.valid() )
	{
		return( Soccer_Object_Reference::D2_Region_with_Accuracy
			( this -> player_info().coordinate.region() ,
			  this -> player_info().coordinate_accuracy ) );
	}
	else
	{
		return( Soccer_Object_Reference::D2_Region_with_Accuracy
			( this -> player_info().coordinate.region() ,
			  Soccer_Object_Reference::D2_Region_with_Accuracy
			    ::INVALID_ACCURACY ) );
	}
}

Soccer_Object_Reference::D2_Vector_with_Accuracy
	Player_Reference::velocity() const
{
	if ( this -> player_info().velocity.valid() )
	{
		return( Soccer_Object_Reference::D2_Vector_with_Accuracy
			( this -> player_info().velocity.point() ,
			  this -> player_info().velocity_accuracy ) );
	}
	else
	{
		return( Soccer_Object_Reference::D2_Vector_with_Accuracy
			( this -> player_info().velocity.point() ,
			  Soccer_Object_Reference::D2_Vector_with_Accuracy
			    ::INVALID_ACCURACY ) );
	}
}

Soccer_Object_Reference::D2_Region_with_Accuracy
	Player_Reference::velocity_region() const
{
	if ( this -> player_info().velocity.valid() )
	{
		return( Soccer_Object_Reference::D2_Region_with_Accuracy
			( this -> player_info().velocity.region() ,
			  this -> player_info().velocity_accuracy ) );
	}
	else
	{
		return( Soccer_Object_Reference::D2_Region_with_Accuracy
			( this -> player_info().velocity.region() ,
			  Soccer_Object_Reference::D2_Region_with_Accuracy
			    ::INVALID_ACCURACY ) );
	}
}

Soccer_Object_Reference::Angle_with_Validity
	Player_Reference::body_angle() const
{
	if ( this -> player_info().body_angle.valid() )
	{
		return( Soccer_Object_Reference::Angle_with_Validity
			( this -> player_info().body_angle.point() , true ) );
	}
	else
	{
		return( Soccer_Object_Reference::Angle_with_Validity
			( this -> player_info().body_angle.point() , false ) );
	}
}

Soccer_Object_Reference::Angle_Range_with_Validity
	Player_Reference::body_angle_range() const
{
	if ( this -> player_info().body_angle.valid() )
	{
		return( Soccer_Object_Reference::Angle_Range_with_Validity
			( this -> player_info().body_angle.range() , true ) );
	}
	else
	{
		return( Soccer_Object_Reference::Angle_Range_with_Validity
			( this -> player_info().body_angle.range() , false ) );
	}
}

Soccer_Object_Reference::Angle_with_Validity
	Player_Reference::face_angle() const
{
	if ( this -> player_info().face_angle.valid() )
	{
		return( Soccer_Object_Reference::Angle_with_Validity
			( this -> player_info().face_angle.point() , true ) );
	}
	else
	{
		return( Soccer_Object_Reference::Angle_with_Validity
			( this -> player_info().face_angle.point() , false ) );
	}
}

Soccer_Object_Reference::Angle_Range_with_Validity
	Player_Reference::face_angle_range() const
{
	if ( this -> player_info().face_angle.valid() )
	{
		return( Soccer_Object_Reference::Angle_Range_with_Validity
			( this -> player_info().face_angle.range() , true ) );
	}
	else
	{
		return( Soccer_Object_Reference::Angle_Range_with_Validity
			( this -> player_info().face_angle.range() , false ) );
	}
}

double  Player_Reference::stamina() const
{
	if ( this -> self_player() )
	{
		return( this -> snapshot().body.stamina.point() );
	}
	else
	{
		return( field.sserver_param().STAMINA_MAX() );
	}
}

Double_Info  Player_Reference::stamina_range() const
{
	if ( this -> self_player() )
	{
		return( this -> snapshot().body.stamina );
	}
	else
	{
		return( Double_Info( 0.0 ,
				     field.sserver_param().STAMINA_MAX() ,
				     field.sserver_param().STAMINA_MAX() ) );
	}
}

Soccer_Object_Reference::Bool_with_Validity  Player_Reference::goalie() const
{
	if ( this -> self_player() )
	{
		return( Bool_with_Validity
			( this -> snapshot().game_state.goalie_flag , true ) );
	}
	else
	{
		return( Bool_with_Validity( false , false ) );
	}
}


//
// Team_Reference
//
Team_Reference::Team_Reference( const Field_Recog_Interface &  f ,
				const S_Side &  s )
	: field( f ) , side_ident( s )
{
}

Team_Reference::~Team_Reference()
{
}

S_Side  Team_Reference::side() const
{
	return( side_ident );
}

S_Side_LR  Team_Reference::side_lr() const
{
	S_Side_LR	our_side
			  = field.snapshot().game_state.game_info.our_side;

	if ( this -> side() == S_Side::Unknown
	  || our_side == S_Side_LR::Unknown )
	{
		return( S_Side_LR::Unknown );
	}

	if ( this -> side() == S_Side::Our_Side )
	{
		return( our_side );
	}
	else
	{
		if ( our_side == S_Side_LR::Left_Side )
		{
			return( S_Side_LR::Right_Side );
		}
		else
		{
			return( S_Side_LR::Left_Side );
		}
	}
}

int   Team_Reference::score() const
{
	switch( this -> side_ident )
	{
	case S_Side::Our_Side:
		return( field.snapshot().game_state.game_info.our_score );
		break;

	case S_Side::Opponent_Side:
		return( field.snapshot().game_state.game_info.opponent_score );
		break;

	case S_Side::Unknown:
	default:
		return( -1 );
		break;
	}
}

Team_Reference  Team_Reference::teammate_team() const
{
	return( *this );
}

Team_Reference  Team_Reference::opponent_team() const
{
	if ( this -> side() == S_Side::Our_Side )
	{
		return( field.opponent_team() );
	}
	else if ( this -> side() == S_Side::Opponent_Side )
	{
		return( field.our_team() );
	}
	else
	{
		return( field.team( S_Side::Unknown ) );
	}
}

double  Team_Reference::offside_line() const
{
	if ( this -> side() == S_Side::Our_Side )
	{
		const vector<Field_Recog_Abstract::Player_Info> &
			players = field.snapshot().teammate;

		std::multiset<double>	x_set;

		for ( size_t  i = 0  ;  i < players.size()  ;  i ++ )
		{
			if ( players[i].coordinate.valid() )
			{
				x_set.insert( players[i]
					       .coordinate.point().x() );
			}
		}

		double	line_x = 0.0;

		if ( x_set.size() >= 2 )
		{
			std::multiset<double>::iterator	it;
			it = x_set.begin();
			it ++;

			if ( (*it) < line_x )
			{
				line_x = (*it);
			}
		}

		if ( field.snapshot().ball.coordinate.valid()
		     && field.snapshot().ball.coordinate.point().x() < line_x )
		{
			line_x = field.snapshot().ball.coordinate.point().x();
		}

		return( line_x );
	}
	else if ( this -> side() == S_Side::Opponent_Side )
	{
		const vector<Field_Recog_Abstract::Player_Info> &
			players = field.snapshot().teammate;

		std::multiset<double>	x_set;

		for ( size_t  i = 0  ;  i < players.size()  ;  i ++ )
		{
			if ( players[i].coordinate.valid() )
			{
				x_set.insert( players[i]
					       .coordinate.point().x() );
			}
		}

		double	line_x = 0.0;

		if ( x_set.size() >= 2 )
		{
			std::multiset<double>::iterator	it;
			it = x_set.end();
			it --;
			it --;

			if ( (*it) > line_x )
			{
				line_x = (*it);
			}
		}

		if ( field.snapshot().ball.coordinate.valid()
		     && field.snapshot().ball.coordinate.point().x() > line_x )
		{
			line_x = field.snapshot().ball.coordinate.point().x();
		}

		return( line_x );
	}
	else
	{
		return( 0.0 );
	}
}

double  Team_Reference::defence_line() const
{
	return( this -> offside_line() );
}

double  Team_Reference::offence_line() const
{
	return( this -> opponent_team().offside_line() );
}


//
// Play_Mode_Reference
//
Play_Mode_Reference::Play_Mode_Reference( const Field_Recog_Interface &  f )
	: field( f )
{
}

Play_Mode_Reference::~Play_Mode_Reference()
{
}

Play_Mode  Play_Mode_Reference::mode() const
{
	return( field.snapshot().game_state.game_info.play_mode );
}

int    Play_Mode_Reference::start_time() const
{
	return( field.snapshot().game_state.play_mode_start_time );
}

Whistle_Info_from_Server  Play_Mode_Reference::start_reason() const
{
	return( field.snapshot().game_state.play_mode_start_reason() );
}

bool   Play_Mode_Reference::kickable_mode() const
{
	return(    this -> mode() != Play_Mode::Before_Kick_Off
		&& this -> mode() != Play_Mode::Our_Goal
		&& this -> mode() != Play_Mode::Opponent_Goal
		&& ! ((   this -> mode() == Play_Mode::Our_Free_Kick
		       || this -> mode() == Play_Mode::Opponent_Free_Kick)
		      && this -> start_reason().type
			  == Judgement_Type::Offside )
		&& this -> mode() != Play_Mode::Unknown );
}

bool   Play_Mode_Reference::catchable_mode() const
{
	return( this -> mode() == Play_Mode::Play_On );
}

bool   Play_Mode_Reference::movable_mode() const
{
	return(    this -> mode() == Play_Mode::Before_Kick_Off
		|| this -> mode() == Play_Mode::Our_Goal
		|| this -> mode() == Play_Mode::Opponent_Goal );
}

Play_Mode_Reference::operator Play_Mode() const
{
	return( this -> mode() );
}

bool   Play_Mode_Reference::operator== ( Play_Mode::Mode  m ) const
{
	return( (this -> mode() == m) );
}

bool   Play_Mode_Reference::operator!= ( Play_Mode::Mode  m ) const
{
	return( (this -> mode() != m) );
}


Soccer_Composite_Command  Field_Recog_Interface::previous_command() const
{
	if ( field )
	{
		return( field -> previous_command() );
	}
	else
	{
		return( Soccer_Command::No_Command() );
	}
}


// XXX
#include  <list>

long   Field_Recog_Interface::strict_ball_lose_step( long  max_step ) const
{
	// XXX
	if ( ! this -> ball().coordinate().accuracy_check( 0 )
	  || ! this -> ball().velocity().accuracy_check( 0 )
	  || ! this -> self().body_angle().accuracy_check( 0 ) )
	{
		return( 0 );
	}


	list<Player_Reference>	check_list;

	for ( int  i = 1  ;  i <= MAX_PLAYER  ;  i ++ )
	{
		if ( i != this -> self().player_number() )
		{
			check_list.push_back( this -> teammate(i) );
		}
	}

	for ( int  i = 1  ;  i <= MAX_PLAYER  ;  i ++ )
	{
		check_list.push_back( this -> opponent(i) );
	}

	for ( size_t  i = 0  ;  i < this -> n_unknown_player()  ;  i ++ )
	{
		check_list.push_back( this -> unknown_player(i) );
	}

	for ( long  n = 0  ;  n <= max_step  ;  n ++ )
	{
		double	kickable_max_dist
				= sserver_param().PLAYER_SPEED_MAX()
				    * static_cast<double>(n);

		list<Player_Reference>::iterator  it = check_list.begin();

		while ( it != check_list.end() )
		{
			D2_Vector	ball_coord
					  = sserver_param()
					      .ball_basic_point_n_step_later
						( this -> ball().coordinate() ,
						  this -> ball().velocity() ,
						  n );
			try
			{
				double	d;
				d = ((it -> coordinate()) - ball_coord).r();

				if ( d - (sserver_param().kickable_distance())
				     <= kickable_max_dist + 0.1 )
				{
					return( n );
				}
				else
				{
					double	k
						= sserver_param()
						  .PLAYER_SPEED_MAX()
						  * static_cast<double>(
							max_step - n );

					double	b
						= sserver_param()
						  .BALL_SPEED_MAX()
						  * static_cast<double>(
							max_step - n );

					if ( d >= k + b + 5.0 )
					{
						throw exception();
					}
				}

				it ++;
			}
			catch(...)
			{
				list<Player_Reference>::iterator  er;
				er = it;
				it ++;

				check_list.erase(er);
			}
		}
	}

	return( max_step + 1 );
}
