#ifndef	   FIELD_RECOG_INTERFACE_H_INCLUDED
#define	   FIELD_RECOG_INTERFACE_H_INCLUDED

// Author:		H. Shimora
// Last-Modified:	May 21 2000
// Created:		May 21 2000
// Version:		0.00

///-----------------------------------------------
/// Change Log:
///-----------------------------------------------
// version 0.00  May 21 2000    base version.
//
//


#include  "field_recog_abstract.h"
#include  "field_momentary_info.h"
#include  "s_basic.h"
#include  <climits>

class  Field_Recog_Interface;
class  Soccer_Object_Reference;
class  Ball_Reference;
class  Player_Reference;
class  Team_Reference;


//
// Object
//
class  Soccer_Object_Reference
{
protected:
	class  D2_Vector_with_Accuracy : public D2_Vector
	{
	public:
		enum{ INVALID_ACCURACY = LONG_MIN };

	private:
		long	acc;

	public:
		D2_Vector_with_Accuracy( const D2_Vector &  vec ,  long  acc )
			: D2_Vector( vec ) ,  acc( acc ) {}

		long	accuracy_level() const
		{
			return( acc );
		}

		bool	accuracy_check( int  level = 0 ) const
		{
			return( acc >= level );
		}

		// obsoleted
		bool	have_info() const
		{
			return( acc != INVALID_ACCURACY );
		}
	};

	class  D2_Region_with_Accuracy : public D2_Region
	{
	public:
		enum{ INVALID_ACCURACY = LONG_MIN };

	private:
		long	acc;

	public:
		D2_Region_with_Accuracy( const D2_Region &  reg ,  long  acc )
			: D2_Region( reg ) , acc( acc ) {}

		long	accuracy_level() const
		{
			return( acc );
		}

		bool	accuracy_check( int  level = 0 ) const
		{
			return( acc >= level );
		}

		// obsoleted
		bool	have_info() const
		{
			return( acc != INVALID_ACCURACY );
		}
	};

	class  Angle_with_Validity : public Angle
	{
	public:
		enum{ INVALID_ACCURACY = LONG_MIN };

	private:
		bool	validity;

	public:
		Angle_with_Validity( const Angle &  ang ,  bool  validity )
			: Angle( ang ) , validity( validity ) {}

		long	accuracy_level() const
		{
			return( validity ? 0 : INVALID_ACCURACY );
		}

		bool	accuracy_check( int = 0 ) const
		{
			return( validity );
		}

		// obsoleted
		bool	have_info() const
		{
			return( validity );
		}
	};

	class  Angle_Range_with_Validity : public Angle_Range
	{
	public:
		enum{ INVALID_ACCURACY = LONG_MIN };

	private:
		bool	validity;

	public:
		Angle_Range_with_Validity( const Angle_Range &  ang_range ,
					   bool  validity )
			: Angle_Range( ang_range ) , validity( validity ) {}

		long	accuracy_level() const
		{
			return( validity ? 0 : INVALID_ACCURACY );
		}

		bool	accuracy_check( int = 0 ) const
		{
			return( validity );
		}

		// obsoleted
		bool	have_info() const
		{
			return( validity );
		}
	};

	class  Bool_with_Validity
	{
	public:
		enum{ INVALID_ACCURACY = LONG_MIN };

	private:
		bool	value;
		bool	validity;

	public:
		Bool_with_Validity( bool  value , bool  validity )
			: value( value ) , validity( validity ) {}

		operator bool() const
		{
			return( value );
		}

		long	accuracy_level() const
		{
			return( validity ? 0 : INVALID_ACCURACY );
		}

		bool	accuracy_check( int = 0 ) const
		{
			return( validity );
		}
	};

protected:
	const Field_Recog_Interface &	field;

protected:
	const Field_Recog_Abstract::Field_Recog_Snapshot&	snapshot()
									const;

public:
		 Soccer_Object_Reference( const Field_Recog_Interface &  f );
	virtual	~Soccer_Object_Reference();

	virtual	D2_Vector_with_Accuracy		coordinate() const;
	virtual	D2_Region_with_Accuracy		coordinate_region() const;
	virtual	D2_Vector_with_Accuracy		velocity() const;
	virtual	D2_Region_with_Accuracy		velocity_region() const;

	virtual	double	x() const;	// short cut for coordinate().x()
	virtual	double	y() const;	// short cut for coordinate().y()
};


//
// Ball
//
class  Ball_Reference : public Soccer_Object_Reference
{
public:
		 Ball_Reference( const Field_Recog_Interface &  f );
	virtual	~Ball_Reference();

	virtual	D2_Vector_with_Accuracy		coordinate() const;
	virtual	D2_Region_with_Accuracy		coordinate_region() const;
	virtual	D2_Vector_with_Accuracy		velocity() const;
	virtual	D2_Region_with_Accuracy		velocity_region() const;
};


//
// Player
//
class  Team_Reference;

class  Player_Reference : public Soccer_Object_Reference
{
protected:
	bool				known;
	SObject_Player_Identifier	ident;
	int				unknown_index;

protected:
	static	const Field_Recog_Abstract::Player_Info	unknown_player;
	const Field_Recog_Abstract::Player_Info &	player_info() const;

public:
		 Player_Reference( const Field_Recog_Interface &  f ,
				   const S_Side &  s ,  int  num );
	virtual	~Player_Reference();

	virtual	S_Side			side() const;
	virtual	S_Side_LR		side_lr() const;
	virtual	Team_Reference		team() const;
	virtual	int			player_number() const;
	virtual	bool			self_player() const;
	virtual	Bool_with_Validity	goalie() const;

	virtual	D2_Vector_with_Accuracy		coordinate() const;
	virtual	D2_Region_with_Accuracy		coordinate_region() const;
	virtual	D2_Vector_with_Accuracy		velocity() const;
	virtual	D2_Region_with_Accuracy		velocity_region() const;
	virtual	Angle_with_Validity		body_angle() const;
	virtual	Angle_Range_with_Validity	body_angle_range() const;
	virtual	Angle_with_Validity		face_angle() const;
	virtual	Angle_Range_with_Validity	face_angle_range() const;

	virtual	double				stamina() const;
	virtual	Double_Info			stamina_range() const;
};


//
// Team
//
class  Team_Reference
{
protected:
	const Field_Recog_Interface &  field;
	S_Side	side_ident;

public:
		 Team_Reference( const Field_Recog_Interface &  f ,
				 const S_Side &  s );
	virtual	~Team_Reference();

	virtual	S_Side		side() const;
	virtual	S_Side_LR	side_lr() const;
	virtual	int		score() const;

	virtual	Team_Reference	teammate_team() const;
	virtual	Team_Reference	opponent_team() const;

	virtual	double		offside_line() const;
	virtual	double		defence_line() const; // same as offside_line
	virtual	double		offence_line() const;
};


//
// Play_Mode
//
class  Play_Mode_Reference
{
protected:
	const Field_Recog_Interface &  field;

public:
		 Play_Mode_Reference( const Field_Recog_Interface &  f );
	virtual	~Play_Mode_Reference();

	virtual	Play_Mode			mode() const;
	virtual	int				start_time() const;
	virtual Whistle_Info_from_Server	start_reason() const;

	virtual	bool	kickable_mode() const;
	virtual	bool	catchable_mode() const;
	virtual	bool	movable_mode() const;

	virtual	operator Play_Mode() const;
	virtual	bool	operator== ( Play_Mode::Mode  m ) const;
	virtual	bool	operator!= ( Play_Mode::Mode  m ) const;
};


//
// Field_Recog_Interface
//
class  Field_Recog_Interface
{
protected:
	const Field_Recog_Abstract *	field;
	ref_count_ptr<const Field_Recog_Abstract::Field_Recog_Snapshot>	snap;

public:
	const Field_Recog_Abstract::Field_Recog_Snapshot &	snapshot()
									const;
public:
		 Field_Recog_Interface( const Field_Recog_Abstract *  field );
		 Field_Recog_Interface
		 ( const ref_count_ptr<const Field_Recog_Abstract
					   ::Field_Recog_Snapshot> &  snap );
		 Field_Recog_Interface();
	virtual	~Field_Recog_Interface();

	virtual	const Field_Recog_Interface *	operator -> () const;

	virtual	const SServer_Param &		sserver_param() const;

	virtual	bool				game_over() const;

	virtual	SServer_Time			current_time() const;
	virtual	const Play_Mode_Reference	play_mode() const;


	virtual	const Ball_Reference	ball() const;

	virtual	const Player_Reference	self() const;
	virtual	const Player_Reference	teammate( int  player_number ) const;
	virtual	const Player_Reference	opponent( int  player_number ) const;
	virtual	const Player_Reference	player( const S_Side &  side ,
						int  player_number ) const;

	virtual	size_t			n_unknown_player() const;
	virtual	const Player_Reference	unknown_player( int  indx ) const;

	virtual	const Team_Reference	our_team() const;
	virtual	const Team_Reference	opponent_team() const;
	virtual	const Team_Reference	team( const S_Side &  side ) const;

	virtual	Soccer_Composite_Command	previous_command() const;

	// XXX
	virtual	long	strict_ball_lose_step( long  max_step = 10 ) const;
};


#endif	/* FIELD_RECOG_INTERFACE_H_INCLUDED */
