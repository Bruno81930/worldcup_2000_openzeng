#include  "soccer_manager.h"
#include  "sserver_player_connection.h"
#include  "debug_client_connection.h"
#include  "sserver_param.h"
#include  "field_recog.h"
#include  "field_recog_interface.h"
#include  "soccer_option_analyser.h"
#include  "angle.h"
#include  "debugstream.h"
#include  <cfloat>
#include  <cstdlib>

using namespace std;

int    main( int  argc ,  char *  argv[] )
{
	ios::sync_with_stdio();
	Debug_Stream::dbg.inhibit();

	cout.precision( DBL_DIG );
	cerr.precision( DBL_DIG );

	Soccer_Option_Analyser	opt( "test" /* default team name */ ,
				     false  /* default is field player */ );

	if ( ! opt.analyse( argc , argv ) )
	{
		opt.usage();
		return( 1 );
	}
	else if ( opt.help() )
	{
		opt.usage();
		return( 0 );
	}

	SServer_Param	param;

	SServer_Player_Connection	server( param ,
						opt.hostname() ,
						opt.port_number() );

	Soccer_Manager	manager( param , server );

	Game_Info	g_info;
	if ( opt.reconnect() == false )
	{
		if ( manager.init_connection(
					opt.teamname() ,
					opt.goalie() ,
					&g_info ,
					opt.server_major_version() ,
					opt.server_minor_version() ) == (-1) )
		{
			cerr << "init command failed." << endl;
			return( 1 );
		}
	}
	else
	{
		if ( manager.reconnect_connection(
					opt.teamname() ,
					opt.reconnect_player_number() ,
					&g_info , opt.goalie() ) == (-1) )
		{
			cerr << "reconnect command failed." << endl;
			return( 1 );
		}
	}

	Field_Recog		field( param , g_info , opt.goalie() );
	Field_Recog_Interface	field_recog_interface( &field );
	manager.register_field_recog( &field );

	Debug_Client_Connection	debug( opt.debug_hostname() ,
				       opt.debug_port_number() );
	manager.register_debug_connection( &debug );

	manager.send_move( - 25.0 , 10.0 , true );
	manager.send_change_view( View_Width::Narrow , View_Quality::High ,
				  true );

	srandom(1);

	for(;;)
	{
		if ( manager.game_over() )
		{
			cout << "Game is Over" << endl;
			manager.send_bye();
			break;
		}
		else if ( manager.server_no_response() )
		{
			cout << "Server No Response" << endl;
			manager.send_bye();
			break;
		}

		manager.next_step();

		Soccer_Command	com;

		if ( (random() >> 8 ) % 2  ==  0 )
		{
			com.turn( Degree( random() % 3600000 - 1800000 )
				  / 10000.0 );
		}
		else
		{
			com.dash( (random() % 2000000 - 1000000) / 10000.0 );
		}

		manager.send_command( com );

		Soccer_Command	turn_neck;
		turn_neck.turn_neck( Degree( random() % 3600000 - 1800000 )
				     / 10000.0 );

		manager.send_command( turn_neck );
	}

	return( 0 );
}
