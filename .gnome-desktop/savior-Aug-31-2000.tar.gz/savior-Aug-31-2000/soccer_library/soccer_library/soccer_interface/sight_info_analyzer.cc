#include  "sight_info_analyzer.h"
#include  "d2_universal_region.h"
#include  "d2_composite_straight_line_divided_region_interface.h"
#include  "fixed_sobject_location.h"
#include  "quantize.h"
#include  "field_recog_abstract.h"
#include  <vector>
#include  <utility>
#include  <algorithm>

using namespace std;

//
// external interface
//
Sight_Info_Analyzer::Sight_Info_Analyzer(
	     const ref_count_ptr<const Sight_Info_from_Server> &  sight ,
	     const SServer_Param &  param ,
	     const Angle_Range &  neck_angle )
	: sight( sight ) ,
	  param( param ) ,
	  neck_angle( neck_angle ) ,
	  view_angle_cached( false ) ,
	  view_angle() ,
	  body_angle_cached( false ) ,
	  body_angle() ,
	  my_coordinate_cached( false ) ,
	  my_coordinate() ,
	  ball_info_cached( false ) ,
	  ball_info() ,
	  player_info_cached( false ) ,
	  teammate_info( MAX_PLAYER ) ,
	  opponent_info( MAX_PLAYER ) ,
	  unknown_player_info() ,
	  relative_field_maker_info_cached( false ) ,
	  relative_field_maker_info() ,
	  unknown_marker_info()
{
}

Sight_Info_Analyzer::~Sight_Info_Analyzer()
{
}


bool   Sight_Info_Analyzer::get_body_angle_range( Angle_Info *  result )
{
	if ( ! (this -> require_body_angle()) )
	{
		result -> set( Radian(0.0) , Radian(0.0) , Radian(0.0) );
		return( false );
	}
	else
	{
		result -> set( this -> body_angle );
		return( true );
	}
}


bool   Sight_Info_Analyzer::get_my_coordinate( Region_Info *  result )
{
	if ( ! (this -> require_my_coordinate()) )
	{
		result -> set( D2_Empty_Region() , D2_Vector(0.0 , 0.0) );
		return( false );
	}
	else
	{
		result -> set( this -> my_coordinate );
		return( true );
	}
}


void   Sight_Info_Analyzer::get_ball_info
				( Field_Recog_Abstract::Ball_Info *  result )
{
	if ( ! (this -> require_ball_info()) )
	{
		result -> coordinate.reset();
		result -> velocity.reset();
		result -> in_sight = false;
	}
	else
	{
		*result = ball_info;
	}
}

bool   Sight_Info_Analyzer::get_player_info(
		std::vector<Field_Recog_Abstract::Player_Info> *  teammate ,
		std::vector<Field_Recog_Abstract::Player_Info> *  opponent ,
		std::vector<Field_Recog_Abstract::Player_Info> *  unknown )
{
	if ( ! (this -> require_player_info()) )
	{
		return( false );
	}
	else
	{
		*teammate = teammate_info;
		*opponent = opponent_info;
		*unknown  = unknown_player_info;

		return( true );
	}
}




//
// internal method
//

//
// view angle
//
bool   Sight_Info_Analyzer::require_view_angle()
{
	if ( this -> view_angle_cached )
	{
		return( true );
	}

	this -> body_angle_cached = true;
	return( this -> calc_view_angle_from_line( &(this -> view_angle) ) );
}

bool   Sight_Info_Analyzer::calc_view_angle_from_line( Angle_Info *  result )
{
	// return my angle [- PI , PI)

	if ( sight -> line.size() == 0 )
	{
		result -> reset();

		return( false );
	}

	const Angle	line_theta = sight -> line[0].relative.direction;

	Angle	angle;
	Angle	err_min;
	Angle	err_max;

	if ( line_theta < Degree( 0.0 ) )
	{
		angle = Degree( - 90.0 ) - line_theta;
	}
	else
	{
		angle = Degree( + 90.0 ) - line_theta;
	}

	if ( line_theta < Degree( - 0.5 ) )
	{
		err_min = Degree(   0.0 );
		err_max = Degree( + 1.0 );
	}
	else if ( line_theta > Degree( + 0.5 ) )
	{
		err_min = Degree( - 1.0 );
		err_max = Degree(   0.0 );
	}
	else
	{
		err_min = Degree( - 1.0 );
		err_max = Degree( + 1.0 );
	}

	switch( sight -> line[0].entity.which_line )
	{
	case SObject_Line_Identifier::Opponent_Goal_Line:
		break;

	case SObject_Line_Identifier::Left_Wing_Line:
		angle += Degree( 90.0 );
		break;

	case SObject_Line_Identifier::Our_Goal_Line:
		angle += Degree( 180.0 );
		break;

	case SObject_Line_Identifier::Right_Wing_Line:
		angle += Degree( 270.0 );
		break;
	}

	if ( sight -> line.size() >= 2 )
	{
		angle += Degree( 180.0 );
	}

	angle = angle.normalize();

	result -> set( angle + err_min , angle + err_max ,
		       angle + (err_max + err_min) / 2.0 );

	return( true );
}


//
// body angle
//
bool   Sight_Info_Analyzer::require_body_angle()
{
	if ( this -> body_angle_cached )
	{
		return( true );
	}

	this -> body_angle_cached = true;
	return( this -> calc_body_angle( &(this -> body_angle) ) );
}

bool   Sight_Info_Analyzer::calc_body_angle( Angle_Info *  result )
{
	// return my absolute body angle [- PI , PI)

	if ( ! (require_view_angle()) )
	{
		result -> reset();
		return( false );
	}

	Angle	neck_angle_error
		= ((neck_angle.max() - neck_angle.min()) / 2.0).abs();

	Angle	view_angle_error = ((view_angle.range().max()
				     - view_angle.range().min()) / 2.0).abs();

	Angle	err = view_angle_error + neck_angle_error;
	Angle	med = (view_angle.range().median()
		       - neck_angle.median()).normalize();

	result -> set( med - err , med + err , med );

	return( true );
}


//
// my_coordinate
//
bool   Sight_Info_Analyzer::require_my_coordinate()
{
	if ( this -> my_coordinate_cached )
	{
		return( true );
	}

	this -> my_coordinate_cached = true;
	return( this -> calc_my_coordinate_by_composite
					( &(this -> my_coordinate) ) );
}


bool   Sight_Info_Analyzer::calc_my_coordinate_by_composite
						( Region_Info *  result )
{
#if 0
	D2_Region	region;
	if ( ! calc_my_coordinate_by_region_cut( &region ) )
	{
		return( false );
	}
#endif

	D2_Vector	point_by_sum;
	if ( ! calc_my_coordinate_by_sum( &point_by_sum ) )
	{
		return( false );
	}


	D2_Vector	point = point_by_sum;

	if ( unknown_marker_info.size() >= 1 )
	{
		static	Fixed_SObject_Location_Translator	loc;

		D2_Vector	closest_object_point;
		loc.get_closest_object_location(
			    &closest_object_point ,
			    point ,
			    unknown_marker_info[0].it -> entity.marker_flag );

		Relative_Field_Maker_Info	closest_marker;
		closest_marker = unknown_marker_info[0];
		closest_marker.absolute_point = closest_object_point;

		point = object_coordinate_info_to_my_coordinate
					( closest_marker , view_angle );
	}

#if 0
	result -> set( region , point );
#else
	result -> set( D2_Universal_Region() , point );
#endif

	return( true );
}

bool   Sight_Info_Analyzer::calc_my_coordinate_by_sum( D2_Vector *  res_vec )
{
	this -> require_relative_field_maker_info();

	require_relative_field_maker_info();

	if ( relative_field_maker_info.size() == 0
	  || ! require_view_angle() )
	{
		res_vec -> set( D2_Vector::XY , 0.0 , 0.0 );

		return( false );
	}

	// these value is generated by GA
	const	double	one_flag_threshold = 30.3;
	const	double	n_flag_decay       = 0.781245;
	const	double	dist_decay         = 0.0114752;

	if ( relative_field_maker_info[0].relative_point.r()
	     < one_flag_threshold )
	{
		(*res_vec) = object_coordinate_info_to_my_coordinate
				 ( relative_field_maker_info[0] ,
				   view_angle );

		return( true );
	}

	D2_Vector	vec( D2_Vector::XY , 0.0 , 0.0 );
	double		n = 0.0;
	double		c = 1.0;

	for ( size_t  i = 0  ;  i < relative_field_maker_info.size()  ;  i ++ )
	{
		D2_Vector	v = object_coordinate_info_to_my_coordinate
				    ( relative_field_maker_info[i] ,
				      view_angle );

		double	e = exp( - dist_decay
				   * relative_field_maker_info[i]
							 .relative_point.r() );
		vec += e * c * v;

		n += e * c;

		c *= n_flag_decay;
	}

	(*res_vec) = vec / n;

	return( true );
}

bool   Sight_Info_Analyzer::calc_my_coordinate_by_region_cut(
						     D2_Region *  res_reg )
{
	const	Angle	EPS = Degree( 1.0e-6 );

	this -> require_relative_field_maker_info();

	const vector<Sight_Info_Analyzer::Relative_Field_Maker_Info> &
		objects = relative_field_maker_info;

	if ( objects.size() == 0  ||  ! require_view_angle() )
	{
		*res_reg = D2_Empty_Region();

		return( false );
	}

	D2_Composite_Straight_Line_Divided_Region_Interface	region;

	for ( size_t  i = 0  ;  i < objects.size()  ;  i ++ )
	{
		const D2_Vector	&	coord = objects[i].absolute_point;
		const D2_Vector	&	vec   = objects[i].relative_point;


		Angle_Range	point_angle( Radian(0.0) , Radian(0.0) );

		this -> server_angle_to_angle_range( &point_angle ,
						     vec.theta() );

		Angle_Range	point_abs_angle = point_angle
						  + view_angle.range();

		region.add( coord ,
			    point_abs_angle.max() + EPS ,
			    coord + D2_Vector( D2_Vector::Pole , 1.0 ,
					       point_abs_angle.median()
						 + Degree( 90.0 ) ) );

		region.add( coord ,
			    point_abs_angle.min() - EPS ,
			    coord + D2_Vector( D2_Vector::Pole , 1.0 ,
					       point_abs_angle.median()
						 - Degree( 90.0 ) ) );

		double	r_min;
		double	r_max;

		far_object_unquantized_distance( param ,
						 vec.r() , false ,
						 &r_min , &r_max );

		// XXX
		r_min -= 0.01;
		r_max += 0.01;

		D2_Vector	max_point_vector( D2_Vector::Pole ,
						  r_max ,
						  point_abs_angle.median()
						    + Degree( 180.0 ) );

		D2_Vector	max_point = coord + max_point_vector;

		region.add( max_point ,
			    point_abs_angle.median() + Degree( 90.0 ) ,
			    coord );


		D2_Vector	min_point_vector_1( D2_Vector::Pole ,
						    r_min ,
						    point_abs_angle.median()
						     + Degree( 180.0 )
						     + Degree( 2.0 + 0.01 ) );

		D2_Vector	min_point_vector_2( D2_Vector::Pole ,
						    r_min ,
						    point_abs_angle.median()
						      + Degree( 180.0 )
						      - Degree( 2.0 + 0.01 ) );

		D2_Vector	min_point_1 = coord + min_point_vector_1;
		D2_Vector	min_point_2 = coord + min_point_vector_2;

		region.add( min_point_1 , min_point_2 , max_point );
	}

	if ( ! (region.closed()) )
	{
		*res_reg = D2_Empty_Region();

		return( false );
	}

	*res_reg = region.get_region();

	return( true );
}


//
// relative field marker info
//
void   Sight_Info_Analyzer::require_relative_field_maker_info()
{
	if ( relative_field_maker_info_cached )
	{
		return;
	}

	this -> relative_field_maker_info_cached = true;

	//
	// sort markers by distance
	//
	vector< pair<int, double> >	marker_indx;
	vector< pair<int, double> >	unknown_marker_indx;

	for ( size_t  i = 0  ;  i < sight -> field_marker.size()  ;  i ++ )
	{
		const Field_Marker_Info_from_Server &	marker
			= sight -> field_marker[i];

		if ( marker.relative.have_distance
		  && marker.relative.have_direction )
		{
			if ( marker.entity.location_known )
			{
				marker_indx.push_back
				 ( pair<int,double>
				   ( i , marker.relative.distance ) );
			}
			else
			{
				unknown_marker_indx.push_back
				 ( pair<int,double>
				   ( i , marker.relative.distance ) );
			}
		}
	}

	class  Compare_by_Distance
	{
	public:
		static	bool	compare( const pair<int, double> &  a ,
					 const pair<int, double> &  b )
		{
			return( a.second < b.second );
		}
	};

	std::sort( marker_indx.begin() , marker_indx.end() ,
		   Compare_by_Distance::compare );

	std::sort( unknown_marker_indx.begin() , unknown_marker_indx.end() ,
		   Compare_by_Distance::compare );


	//
	// input info to relative_field_maker_info
	//
	for ( size_t  i = 0  ;  i < marker_indx.size()  ;  i ++ )
	{
		const Field_Marker_Info_from_Server &	marker
			= sight -> field_marker[marker_indx[i].first];

		Relative_Field_Maker_Info	info;

		info.absolute_point = marker.entity.location;
		info.it = sight -> field_marker.begin()
					+ marker_indx[i].first;

		if ( relative_sight_to_relative_point( &info.relative_point ,
						       marker.relative ) )
		{
			relative_field_maker_info.push_back( info );
		}
	}

	//
	// input info to unknown_marker_info
	//
	for ( size_t  i = 0  ;  i < unknown_marker_indx.size()  ;  i ++ )
	{
		const Field_Marker_Info_from_Server &	marker
			= sight -> field_marker[unknown_marker_indx[i].first];

		Relative_Field_Maker_Info	info;

		info.absolute_point.set( 0.0 , 0.0 );
		info.it = sight -> field_marker.begin()
					+ unknown_marker_indx[i].first;

		if ( relative_sight_to_relative_point( &info.relative_point ,
						       marker.relative ) )
		{
			unknown_marker_info.push_back( info );
		}
	}
}


// protected:
bool   Sight_Info_Analyzer::relative_sight_to_relative_point
		    ( D2_Vector *  point ,
		      const SObject_Locational_Info_from_Server &  relative )
{
	if ( relative.have_direction && relative.have_distance )
	{
		Angle_Range	direction_range( Radian(0.0) , Radian(0.0) );
		server_angle_to_angle_range( &direction_range ,
					     relative.direction );

		point -> set( D2_Vector::Pole ,
			      relative.distance , direction_range.median() );

		return( true );
	}
	else
	{
		return( false );
	}
}

// protected:
bool   Sight_Info_Analyzer::relative_sight_to_relative_velocity
		    ( D2_Vector *  vel ,
		      const SObject_Locational_Info_from_Server &  relative )
{
	D2_Vector	relative_point;

	if ( ! (relative.have_d_direction && relative.have_d_distance)
	 ||  ! relative_sight_to_relative_point( &relative_point , relative ) )
	{
		return( false );
	}
	else
	{
		Angle_Range	d_direction_range( Radian(0.0) , Radian(0.0) );
		server_angle_to_angle_range( &d_direction_range ,
					     relative.d_direction );

		D2_Vector	to;
		to.set( D2_Vector::Pole ,
			relative_point.r() + relative.d_distance ,
			relative_point.theta() + d_direction_range.median() );

		(*vel) = to - relative_point;

		return( true );
	}
}

// protected:
bool   Sight_Info_Analyzer::relative_sight_to_absolute_point_and_velocity
		    ( Region_Info *  coord ,  Region_Info *  vel ,
		      const SObject_Locational_Info_from_Server &  relative ,
		      const Region_Info &  my_coord ,
		      const Angle_Info &  view_ang )
{
	D2_Vector	relative_point;
	if ( relative_sight_to_relative_point( &relative_point , relative ) )
	{
		coord -> set( D2_Region( new D2_Universal_Region() /*XXX*/ ) ,
			      my_coord.point()
				+ relative_point.rotate( view_ang.point() ) );
	}
	else
	{
		coord -> reset();
		vel   -> reset();

		return( false );
	}

	D2_Vector	relative_vector;
	if ( relative_sight_to_relative_velocity( &relative_vector ,
						  relative ) )
	{
		vel -> set( D2_Region( new D2_Universal_Region() /*XXX*/ ) ,
			    relative_vector.rotate( view_ang.point() ) );
	}
	else
	{
		vel -> reset();
	}

	return( true );
}

// protected:
void   Sight_Info_Analyzer::relative_sight_to_player_info
		    ( Region_Info *  coord ,  Region_Info *  vel ,
		      Angle_Info *  body_angle ,  Angle_Info *  face_angle ,
		      const SObject_Locational_Info_from_Server &  relative ,
		      const Region_Info &  my_coord ,
		      const Angle_Info &  view_ang )
{
	relative_sight_to_absolute_point_and_velocity
	      ( coord , vel , relative , my_coord , view_ang );

	if ( relative.have_body_direction )
	{
		Angle_Range	body_direction_range( Radian(0.0) ,
						      Radian(0.0) );
		server_angle_to_angle_range( &body_direction_range ,
					     relative.body_direction );

		Angle	min_err =   (body_direction_range.min()
				     - body_direction_range.median())
				  + (view_ang.range().min()
				     - view_ang.point());

		Angle	max_err =   (body_direction_range.max()
				     - body_direction_range.median())
				  + (view_ang.range().max()
				     - view_ang.point());

		Angle	point = (body_direction_range.median()
				 + view_ang.point()).normalize();

		body_angle -> set( point - min_err , point + max_err , point );
	}
	else
	{
		body_angle -> reset();
	}

	if ( relative.have_face_direction )
	{
		Angle_Range	face_direction_range( Radian(0.0) ,
						      Radian(0.0) );
		server_angle_to_angle_range( &face_direction_range ,
					     relative.body_direction );

		Angle	min_err =   (face_direction_range.min()
				     - face_direction_range.median())
				  + (view_ang.range().min()
				     - view_ang.point());

		Angle	max_err =   (face_direction_range.max()
				     - face_direction_range.median())
				  + (view_ang.range().max()
				     - view_ang.point());

		Angle	point = (face_direction_range.median()
				 + view_ang.point()).normalize();

		face_angle -> set( point - min_err , point + max_err , point );
	}
	else
	{
		face_angle -> reset();
	}
}


// protected:
void   Sight_Info_Analyzer::server_angle_to_angle_range
			( Angle_Range *  range ,  const Angle &  angle )
{
	Angle	err_min;
	Angle	err_max;

	if ( angle < Degree( - 0.5 ) )
	{
		err_min = Degree(   0.0 );
		err_max = Degree( + 1.0 );
	}
	else if ( angle > Degree( + 0.5 ) )
	{
		err_min = Degree( - 1.0 );
		err_max = Degree(   0.0 );
	}
	else
	{
		err_min = Degree( - 1.0 );
		err_max = Degree( + 1.0 );
	}

	Angle	point = angle.normalize();

	range -> set( point + err_min , point + err_max );
}


// protected:
D2_Vector  Sight_Info_Analyzer::object_coordinate_info_to_my_coordinate
				( const Relative_Field_Maker_Info &  info ,
				  const Angle_Info &  view_ang )
{
	// XXX
	D2_Vector	coord = info.absolute_point;
	D2_Vector	dist  = info.relative_point;

	Angle	dist_angle = dist.theta().normalize();

	if ( dist_angle > Degree( 0.5 ) )
	{
		dist_angle += Degree( 0.5 );
	}
	else if ( dist_angle < - Degree( 0.5 ) )
	{
		dist_angle -= Degree( 0.5 );
	}

#if 1
	D2_Vector	v( D2_Vector::Pole ,
			   dist.r() ,
			   dist_angle + view_ang.point() + Radian(M_PI) );

#else
	double	r_min;
	double	r_max;
	far_object_unquantized_distance( param ,
					 dist.r() , false ,
					 &r_min , &r_max );

	double	r = (r_min + r_max) / 2.0;

	D2_Vector	v( D2_Vector::Pole ,
			   r , dist_angle + view_ang.point + M_PI );
#endif

	return( coord + v );
}


//
// ball info
//
bool   Sight_Info_Analyzer::require_ball_info()
{
	if ( this -> ball_info_cached )
	{
		return( true );
	}

	this -> ball_info_cached = true;

	return( calc_ball_info( &(this -> ball_info) ) );
}

bool   Sight_Info_Analyzer::calc_ball_info
				( Field_Recog_Abstract::Ball_Info *  result )
{
	if ( sight -> ball.size() == 0
	  || (! this -> require_view_angle())
	  || (! this -> require_my_coordinate()) )
	{
		result -> coordinate.reset();
		result -> velocity.reset();
		result -> in_sight = false;

		return( false );
	}

	result -> in_sight = sight -> ball[0].relative.in_sight;

	return( relative_sight_to_absolute_point_and_velocity
		( &(result -> coordinate) ,
		  &(result -> velocity) ,
		  sight -> ball[0].relative ,
		  my_coordinate , view_angle ) );
}


//
// player info
//
bool   Sight_Info_Analyzer::require_player_info()
{
	if ( this -> player_info_cached )
	{
		return( true );
	}

	this -> player_info_cached = true;

	return( calc_player_info( &(this -> teammate_info) ,
				  &(this -> opponent_info) ,
				  &(this -> unknown_player_info) ) );
}

bool   Sight_Info_Analyzer::calc_player_info(
		  std::vector<Field_Recog_Abstract::Player_Info> *  teammate ,
		  std::vector<Field_Recog_Abstract::Player_Info> *  opponent ,
		  std::vector<Field_Recog_Abstract::Player_Info> *  unknown )
{
	for ( size_t  i = 0  ;  i < teammate -> size()  ;  i ++ )
	{
		(*teammate)[i].coordinate.reset();
		(*teammate)[i].velocity.reset();
		(*teammate)[i].body_angle.reset();
		(*teammate)[i].face_angle.reset();
		(*teammate)[i].coordinate_accuracy
			= Field_Recog_Abstract::Player_Info::INVALID_ACCURACY;
		(*teammate)[i].velocity_accuracy
			= Field_Recog_Abstract::Player_Info::INVALID_ACCURACY;
	}

	for ( size_t  i = 0  ;  i < opponent -> size()  ;  i ++ )
	{
		(*opponent)[i].coordinate.reset();
		(*opponent)[i].velocity.reset();
		(*opponent)[i].body_angle.reset();
		(*opponent)[i].face_angle.reset();
		(*opponent)[i].coordinate_accuracy
			= Field_Recog_Abstract::Player_Info::INVALID_ACCURACY;
		(*opponent)[i].velocity_accuracy
			= Field_Recog_Abstract::Player_Info::INVALID_ACCURACY;
	}

	if ( (! this -> require_view_angle())
	  || (! this -> require_my_coordinate()) )
	{
		return( false );
	}

	for ( size_t  i = 0  ;  i < sight -> player.size()  ;  i ++ )
	{
		const Player_Info_from_Server &	pl = sight -> player[i];

		Region_Info	coord;
		Region_Info	vel;
		Angle_Info	b_angle;
		Angle_Info	f_angle;

		relative_sight_to_player_info
		    ( &coord , &vel , &b_angle , &f_angle ,
		      pl.relative , my_coordinate , view_angle );

		if ( pl.entity.side == S_Side::Unknown
		  || ! pl.entity.player_number_valid() )
		{
			Field_Recog_Abstract::Player_Info	u_player;
			u_player.coordinate = coord;
			u_player.velocity   = vel;
			u_player.body_angle = b_angle;
			u_player.face_angle = f_angle;
			u_player.coordinate_accuracy = 0;
			u_player.velocity_accuracy
			 = Field_Recog_Abstract::Player_Info::INVALID_ACCURACY;

			(*unknown).push_back( u_player );
		}
		else if ( pl.entity.side == S_Side::Our_Side )
		{
			(*teammate)[ pl.entity.player_number - 1 ].coordinate
				= coord;
			(*teammate)[ pl.entity.player_number - 1 ].velocity
				= vel;
			(*teammate)[ pl.entity.player_number - 1 ].body_angle
				= b_angle;
			(*teammate)[ pl.entity.player_number - 1 ].face_angle
				= f_angle;

			if ( coord.valid() )
			{
				(*teammate)[ pl.entity.player_number - 1 ]
					.coordinate_accuracy = 0;
			}

			if ( vel.valid() )
			{
				(*teammate)[ pl.entity.player_number - 1 ]
					.velocity_accuracy   = 0;
			}
		}
		else // if ( pl.entity.side == S_Side::Opponent_Side )
		{
			(*opponent)[ pl.entity.player_number - 1 ].coordinate
				= coord;
			(*opponent)[ pl.entity.player_number - 1 ].velocity
				= vel;
			(*opponent)[ pl.entity.player_number - 1 ].body_angle
				= b_angle;
			(*opponent)[ pl.entity.player_number - 1 ].face_angle
				= f_angle;

			if ( coord.valid() )
			{
				(*opponent)[ pl.entity.player_number - 1 ]
					.coordinate_accuracy = 0;
			}

			if ( vel.valid() )
			{
				(*opponent)[ pl.entity.player_number - 1 ]
					.velocity_accuracy   = 0;
			}
		}
	}

	return( true );
}
