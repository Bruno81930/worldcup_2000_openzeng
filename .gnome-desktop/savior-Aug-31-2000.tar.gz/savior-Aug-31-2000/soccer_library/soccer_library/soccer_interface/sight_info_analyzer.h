#ifndef	   SIGHT_INFO_ANALYZER_H_INCLUDED
#define	   SIGHT_INFO_ANALYZER_H_INCLUDED

// Author:		H. Shimora
// Last-Modified:	May  5 2000
// Created:		May  5 2000
// Version:		0.00

///-----------------------------------------------
/// Change Log:
///-----------------------------------------------
// version 0.00  May  5 2000    base version.
//
//

#include  "information_from_server.h"
#include  "sserver_param.h"
#include  "field_recog_abstract.h"
#include  "ref_count_ptr.h"
#include  "angle.h"
#include  "range.h"
#include  <vector>

class  Sight_Info_Analyzer
{
protected:
	//
	// source
	//
	const ref_count_ptr<const Sight_Info_from_Server>	sight;
	const SServer_Param &	param;
	const Angle_Range &	neck_angle;

protected:
	//
	// cache
	//

	// view angle
	bool		view_angle_cached;
	Angle_Info	view_angle;

	// body angle
	bool		body_angle_cached;
	Angle_Info	body_angle;

	// my_coordinate
	bool		my_coordinate_cached;
	Region_Info	my_coordinate;

	// ball
	bool				ball_info_cached;
	Field_Recog_Abstract::Ball_Info	ball_info;

	// player
	bool						player_info_cached;
	std::vector<Field_Recog_Abstract::Player_Info>	teammate_info;
	std::vector<Field_Recog_Abstract::Player_Info>	opponent_info;
	std::vector<Field_Recog_Abstract::Player_Info>	unknown_player_info;

protected:
	//
	// calculation methods
	//
	void	require_relative_field_maker_info();

	bool	require_view_angle();
	bool	require_body_angle();
	bool	require_my_coordinate();
	bool	require_ball_info();
	bool	require_player_info();


	// view angle calculation
	bool	calc_view_angle_from_line( Angle_Info *  result );

	// body angle calculation
	bool	calc_body_angle( Angle_Info *  result );

	// my_coordinate calculation
	bool	calc_my_coordinate_by_composite( Region_Info *  result );
	bool	calc_my_coordinate_by_sum( D2_Vector *  res_vec );
	bool	calc_my_coordinate_by_region_cut( D2_Region *  res_reg );

	// ball info calculation
	bool	calc_ball_info( Field_Recog_Abstract::Ball_Info *  result );

	// player info calculation
	bool	calc_player_info(
		  std::vector<Field_Recog_Abstract::Player_Info> *  teammate ,
		  std::vector<Field_Recog_Abstract::Player_Info> *  opponent ,
		  std::vector<Field_Recog_Abstract::Player_Info> *  unknown );

	struct  Relative_Field_Maker_Info
	{
		std::vector<const Field_Marker_Info_from_Server>::iterator  it;

		// XXX
		D2_Vector	relative_point;
		D2_Vector	absolute_point;
	};
	bool	relative_field_maker_info_cached;
	std::vector<Relative_Field_Maker_Info>	relative_field_maker_info;
	std::vector<Relative_Field_Maker_Info>	unknown_marker_info;

protected:
	//
	// internal methods
	//
	static	bool	relative_sight_to_relative_point
			    ( D2_Vector * ,
			      const SObject_Locational_Info_from_Server & );

	static	bool	relative_sight_to_relative_velocity
			    ( D2_Vector *  point ,
			      const SObject_Locational_Info_from_Server & );

	static	bool	relative_sight_to_absolute_point_and_velocity
			    ( Region_Info *  coord ,  Region_Info *  vec ,
			      const SObject_Locational_Info_from_Server & ,
			      const Region_Info &  my_coord ,
			      const Angle_Info &  view_ang );

	static	void	relative_sight_to_player_info
			    ( Region_Info *  coord ,  Region_Info *  vel ,
			      Angle_Info *  body_angle ,
			      Angle_Info *  face_angle ,
			      const SObject_Locational_Info_from_Server & ,
			      const Region_Info &  my_coord ,
			      const Angle_Info &  view_ang );

	static	D2_Vector	object_coordinate_info_to_my_coordinate
				  ( const Relative_Field_Maker_Info &  info ,
				    const Angle_Info &  view_angle );

	static	void	server_angle_to_angle_range
			    ( Angle_Range *  range ,  const Angle &  angle );

public:
	//
	// external interface
	//
	 Sight_Info_Analyzer(
	     const ref_count_ptr<const Sight_Info_from_Server> &  sight ,
	     const SServer_Param &  param ,
	     const Angle_Range &  neck_angle );

	~Sight_Info_Analyzer();

	bool	get_body_angle_range( Angle_Info *  result );

	bool	get_my_coordinate( Region_Info *  result );

	void	get_ball_info( Field_Recog_Abstract::Ball_Info *  result );

	bool	get_player_info(
		  std::vector<Field_Recog_Abstract::Player_Info> *  teammate ,
		  std::vector<Field_Recog_Abstract::Player_Info> *  opponent ,
		  std::vector<Field_Recog_Abstract::Player_Info> *  unknown );
};


#endif	/* SIGHT_INFO_ANALYZER_H_INCLUDED */
