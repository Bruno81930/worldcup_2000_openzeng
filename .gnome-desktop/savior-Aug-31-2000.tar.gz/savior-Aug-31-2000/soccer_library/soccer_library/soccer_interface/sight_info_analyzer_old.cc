#include  "sight_info_analyzer.h"
#include  "s_basic.h"
#include  "fixed_sobject_location.h"
#include  "debugstream.h"
#include  <cmath>
#include  <algorithm>
#include  <stdexcept>
#include  <cassert>

using namespace std;

Sight_Info_Analyzer::Sight_Info_Analyzer(
				 const Sight_Info_from_Server &  sight ,
				 const SServer_Param &  param ,
				 const Angle &  relative_face_angle )
	: param( param ) ,
	  static_obj() , line() ,
	  unknown_marker_vector() ,
	  unknown_player_vector() ,
	  sorted_by_short_distance( false ) , obj_sorted_by_short_distance() ,
	  have_my_coordinate( false ) ,
	  my_coordinate( D2_Vector::XY , 0.0 , 0.0 ) ,
	  have_my_body_angle( false ) , my_body_angle( Angle::Radian , 0.0 ) ,
	  my_relative_face_angle( relative_face_angle ) ,
	  my_absolute_face_angle( my_body_angle + relative_face_angle ) ,
	  have_ball_player_coordinate( false ) , ball_info() ,
	  teammate_info( MAX_PLAYER ) , opponent_info( MAX_PLAYER )
{
	set_flag_goal_info( sight );
	set_line_info( sight );
	set_ball_info( sight );
	set_player_info( sight );
}

void   Sight_Info_Analyzer::set_flag_goal_info(
				 const Sight_Info_from_Server &  sight )
{
	// flag and goal
	for( size_t  i = 0  ;  i < sight.field_marker.size()  ;  i ++ )
	{
		Relative_Field_Maker_Info	marker_info;

		if ( relative_sight_to_relative_point
				     ( &marker_info.relative_point ,
				       sight -> field_marker[i].relative ) )
		{
			if ( sight -> field_marker[i].relative.in_sight )
			{
				Object_Coordinate_Info	info;
				marker_info.absolute_point
				  = sight -> field_marker[i].entity.location;

				static_obj.push_back( info );
			}
			else
			{
				unknown_marker_vector.push_back(
				  pair<D2_Vector,bool>(
				    relative_point ,
				    sight.field_marker[i].entity.flag ) );
			}
		}
		else
		{
			// XXX
		}
	}
}

void   Sight_Info_Analyzer::set_line_info(
				 const Sight_Info_from_Server &  sight )
{
	// line
	line = sight.line;
}

void   Sight_Info_Analyzer::set_ball_info(
				 const Sight_Info_from_Server &  sight )
{
	// ball
	ball_info.absolute = D2_Vector( D2_Vector::XY , 0.0 , 0.0 );
	ball_info.relative = D2_Vector( D2_Vector::XY , 0.0 , 0.0 );
	ball_info.recognized = false;
	ball_info.have_vector = false;
	ball_info.relative_vector = D2_Vector( D2_Vector::XY , 0.0 , 0.0 );

	if ( sight.ball.size() == 1 )
	{
		D2_Vector	relative_point;

		if ( relative_sight_to_relative_point
					     ( &relative_point ,
					       sight.ball[0].relative ) )
		{
			ball_info.recognized = true;
			ball_info.relative = relative_point;

			D2_Vector	relative_vector;

			if ( relative_sight_to_relative_vector
					     ( &relative_vector ,
					       sight.ball[0].relative ) )
			{
				ball_info.have_vector = true;
				ball_info.relative_vector = relative_vector;
			}
		}
	}
}

void   Sight_Info_Analyzer::set_player_info(
				 const Sight_Info_from_Server &  sight )
{
#if 0
	// initialize
	for ( size_t  i = 0  ;  i < teammate_info.size()  ;  i ++ )
	{
		teammate_info[i].recognized = false;

		teammate_info[i].absolute = D2_Vector( D2_Vector::XY ,
						       0.0 , 0.0 );
		teammate_info[i].relative = D2_Vector( D2_Vector::XY ,
						       0.0 , 0.0 );
		teammate_info[i].have_vector = false;

		teammate_info[i].relative_vector
			= D2_Vector( D2_Vector::XY , 0.0 , 0.0 );
	}

	for ( size_t  i = 0  ;  i < opponent_info.size()  ;  i ++ )
	{
		opponent_info[i].recognized = false;

		opponent_info[i].absolute = D2_Vector( D2_Vector::XY ,
							0.0 , 0.0 );
		opponent_info[i].relative = D2_Vector( D2_Vector::XY ,
							0.0 , 0.0 );
		opponent_info[i].have_vector = false;

		opponent_info[i].relative_vector
			= D2_Vector( D2_Vector::XY , 0.0 , 0.0 );
	}
#endif

	// overwrite
	for ( size_t  i = 0  ;  i < sight.player.size()  ;  i ++ )
	{
		const Player_Info_from_Server &  pl = sight.player[i];

		if ( pl.entity.player_number <= 0 )
		{
			continue;
		}

		if ( pl.entity.side == S_Side::Our_Side )
		{
			assert( 1 <= pl.entity.player_number
				&& pl.entity.player_number <= MAX_PLAYER );

			// XXX
			(void)relative_sight_to_relative_point(
				&(teammate_info[pl.entity.player_number - 1]
				  .relative) ,
				pl.relative );
			teammate_info[pl.entity.player_number - 1].recognized
				= true;

			if ( pl.relative.has_d_distance
			 &&  pl.relative.has_d_direction )
			{
				D2_Vector	to;

				to.set( D2_Vector::Pole ,
					teammate_info[
					  pl.entity.player_number - 1]
					    .relative.r()
					  + pl.relative.d_distance ,
					pl.relative.direction
					+ pl.relative.d_direction );

				teammate_info[pl.entity.player_number - 1]
					.relative_vector
				  = to - teammate_info[
					 pl.entity.player_number - 1].relative;

				teammate_info[pl.entity.player_number - 1]
					.have_vector = true;
			}

			if ( pl.relative.has_body_direction )
			{
				teammate_info[pl.entity.player_number - 1]
					.have_body_direction = true;
				teammate_info[pl.entity.player_number - 1]
					.relative_body_direction
				  = pl.relative.body_direction;
			}

			if ( pl.relative.has_face_direction )
			{
				teammate_info[pl.entity.player_number - 1]
					.have_face_direction = true;
				teammate_info[pl.entity.player_number - 1]
					.relative_face_direction
				  = pl.relative.face_direction;
			}
		}
		else if ( pl.entity.side == S_Side::Opponent_Side )
		{
			// XXX
			(void)relative_sight_to_relative_point(
				&(opponent_info[pl.entity.player_number - 1]
				  .relative) ,
				pl.relative );

			opponent_info[pl.entity.player_number - 1].recognized
				= true;

			if ( pl.relative.has_d_distance
			 &&  pl.relative.has_d_direction )
			{
				D2_Vector	to;

				to.set( D2_Vector::Pole ,
					opponent_info[
					  pl.entity.player_number - 1]
					    .relative.r()
					  + pl.relative.d_distance ,
					pl.relative.direction
					+ pl.relative.d_direction );

				opponent_info[pl.entity.player_number - 1]
					.relative_vector
				  = to - opponent_info[
					 pl.entity.player_number - 1].relative;

				opponent_info[pl.entity.player_number - 1]
					.have_vector = true;
			}

			if ( pl.relative.has_body_direction )
			{
				opponent_info[pl.entity.player_number - 1]
					.have_body_direction = true;
				opponent_info[pl.entity.player_number - 1]
					.relative_body_direction
				  = pl.relative.body_direction;
			}

			if ( pl.relative.has_face_direction )
			{
				opponent_info[pl.entity.player_number - 1]
					.have_face_direction = true;
				opponent_info[pl.entity.player_number - 1]
					.relative_face_direction
				  = pl.relative.face_direction;
			}
		}
		else // if ( pl.entity.side == S_Side::Unknown )
		{
			D2_Vector	v;

			if ( relative_sight_to_relative_point( &v ,
							       pl.relative ) )
			{
				unknown_player_vector.push_back( v );
			}
		}
	}
}


Sight_Info_Analyzer::~Sight_Info_Analyzer()
{
}


#include  "d2_point.h"
Field_State  Sight_Info_Analyzer::get_field_state( int  my_player_number )
	// throw( exception )
{
	try
	{
		if ( ! (1 <= my_player_number
			&& my_player_number
			     <= static_cast<int>(teammate_info.size()) ) )
		{
			throw exception();
		}

		require_ball_player_coordinate();

		Field_State	s( my_player_number ,
				   teammate_info.size() ,
				   opponent_info.size() );

		// XXX: set my_vector
		if ( have_my_coordinate && have_my_body_angle )
		{
			s.set_my_info( ref_count_ptr<const D2_Region_Entity>(
					   new D2_Point( my_coordinate ) ) ,
				       my_body_angle ,
				       my_relative_face_angle );
		}
		else if ( have_my_coordinate )
		{
			s.set_my_info( ref_count_ptr<const D2_Region_Entity>(
				 new D2_Point( my_coordinate ) ) );
		}
		else
		{
			throw exception();
		}

		if ( ball_info.recognized )
		{
			if ( ball_info.have_vector )
			{
				s.set_ball_info(
				  ref_count_ptr<const D2_Region_Entity>(
				   new D2_Point( ball_info.absolute ) ) ,
				  ref_count_ptr<const D2_Region_Entity>(
				   new D2_Point( ball_info.absolute_vector )));
			}
			else
			{
				s.set_ball_info(
				    ref_count_ptr<const D2_Region_Entity>(
				      new D2_Point( ball_info.absolute ) ) );
			}
		}

		for ( size_t  i = 0  ;  i < teammate_info.size()  ;  i ++ )
		{
			if ( teammate_info[i].recognized )
			{
				if ( teammate_info[i].have_vector )
				{
					s.set_teammate_info(
					    i + 1 ,
					    teammate_info[i].absolute );
				}
				else
				{
					s.set_teammate_info(
					    i + 1 ,
					    teammate_info[i].absolute ,
					    teammate_info[i].absolute_vector );
				}
			}
		}

		for ( size_t  i = 0  ;  i < opponent_info.size()  ;  i ++ )
		{
			if ( opponent_info[i].recognized )
			{
				if ( opponent_info[i].have_vector )
				{
					s.set_opponent_info(
					    i + 1 ,
					    opponent_info[i].absolute );
				}
				else
				{
					s.set_opponent_info(
					    i + 1 ,
					    opponent_info[i].absolute ,
					    opponent_info[i].absolute_vector );
				}
			}
		}

		for ( size_t  i = 0  ;  i < unknown_player_vector.size()  ;
		      i ++ )
		{
			s.add_unknown_player( unknown_player_vector[i] );
		}

		return( s );
	}
	catch( ... )
	{
		throw exception();
	}
}


size_t  Sight_Info_Analyzer::n_objects() throw()
{
	return( static_obj.size() );
}


size_t  Sight_Info_Analyzer::n_lines() throw()
{
	return( line.size() );
}


void  Sight_Info_Analyzer::require_obj_sorted_by_short_distance()
{
	if ( ! sorted_by_short_distance )
	{
		class  Compare_by_Short_Distance
		{
		public:
		static	bool	compare( const Object_Coordinate_Info &  a ,
					 const Object_Coordinate_Info &  b )
			{
				return( a.relative.r() < b.relative.r() );
			}
		};

		obj_sorted_by_short_distance = static_obj;
		sort( obj_sorted_by_short_distance.begin() ,
		      obj_sorted_by_short_distance.end() ,
		      Compare_by_Short_Distance::compare );

		sorted_by_short_distance = true;
	}
}

void   Sight_Info_Analyzer::require_my_coordinate()
	// throw( exception )
{
	try
	{
		get_my_coordinate( &my_coordinate , &my_absolute_face_angle );

		my_body_angle
			= my_absolute_face_angle - my_relative_face_angle;

		have_my_body_angle = true;
		have_my_coordinate = true;
	}
	catch( ... )
	{
		throw exception();
	}
}


void   Sight_Info_Analyzer::require_ball_player_coordinate()
	// throw( exception )
{
	try
	{
		require_my_coordinate();
	}
	catch( ... )
	{
		throw exception();
	}

	if ( ball_info.recognized )
	{
		D2_Vector	b = ball_info.relative;
		ball_info.absolute
			= my_coordinate + b.rotate( my_absolute_face_angle );

		if ( ball_info.have_vector )
		{
			ball_info.absolute_vector
			    = ball_info.relative_vector
					  .rotate( my_absolute_face_angle );
		}
	}

	for ( size_t  i = 0  ;  i < teammate_info.size()  ;  i ++ )
	{
		if ( teammate_info[i].recognized )
		{
			D2_Vector	p = teammate_info[i].relative;

			teammate_info[i].absolute
			  = my_coordinate + p.rotate( my_absolute_face_angle );

			if ( teammate_info[i].have_vector )
			{
				teammate_info[i].absolute_vector
				  = teammate_info[i].relative_vector
					  .rotate( my_absolute_face_angle );
			}

			if ( teammate_info[i].have_body_direction )
			{
				teammate_info[i].absolute_body_direction
				  = teammate_info[i].relative_body_direction
				      + my_absolute_face_angle;
			}

			if ( teammate_info[i].have_face_direction )
			{
				teammate_info[i].absolute_face_direction
				  = teammate_info[i].relative_face_direction
				      + my_absolute_face_angle;
			}
		}
	}

	for ( size_t  i = 0  ;  i < opponent_info.size()  ;  i ++ )
	{
		if ( opponent_info[i].recognized )
		{
			D2_Vector	p = opponent_info[i].relative;

			opponent_info[i].absolute
			  = my_coordinate + p.rotate( my_absolute_face_angle );

			if ( opponent_info[i].have_vector )
			{
				opponent_info[i].absolute_vector
				  = opponent_info[i].relative_vector
					  .rotate( my_absolute_face_angle );
			}

			if ( opponent_info[i].have_body_direction )
			{
				opponent_info[i].absolute_body_direction
				  = opponent_info[i].relative_body_direction
				      + my_absolute_face_angle;
			}

			if ( opponent_info[i].have_face_direction )
			{
				opponent_info[i].absolute_face_direction
				  = opponent_info[i].relative_face_direction
				      + my_absolute_face_angle;
			}
		}
	}

	have_ball_player_coordinate = true;
}




#include  "quantize.h"
#if 1
# include  "field_recog.h"
#endif

void   Sight_Info_Analyzer::get_my_coordinate_by_region_cut(
	  D2_Composite_Straight_Line_Divided_Region_Interface *  res_reg ,
	  Angle *  res_ang )
	// throw(std::exception)
{
	const	Angle	EPS = Degree( 1.0e-6 );

	*res_ang = Radian(0.0);

	Angle	min_view_line_angle_error;
	Angle	max_view_line_angle_error;

	Angle	view_line_angle
		  = get_my_angle_from_line( &min_view_line_angle_error ,
					    &max_view_line_angle_error );

	dbg << "### view_line_angle = "
	    << view_line_angle.degree() << endl;

	*res_ang = view_line_angle;

	require_obj_sorted_by_short_distance();

	vector<Object_Coordinate_Info> &	objects
				= obj_sorted_by_short_distance;

	if ( objects.size() == 0 )
	{
		throw exception();
	}

	D2_Composite_Straight_Line_Divided_Region_Interface	region;

	for ( size_t  i = 0  ;  i < objects.size()  ;  i ++ )
	{
		D2_Vector	coord = objects[i].absolute;
		D2_Vector	vec   = objects[i].relative;

		dbg << "### coord = [" << coord << "]" << endl;
		dbg << "### vec.r = " << vec.r()
		    << ", vec.theta() = " << vec.theta().degree() << endl;

		Angle	point_abs_angle
			= vec.theta() + view_line_angle;

		Angle	min_point_angle_error;
		Angle	max_point_angle_error;

		if ( vec.theta() > Degree( 0.5 ) )
		{
			min_point_angle_error = Degree(   0.0 );
			max_point_angle_error = Degree( + 1.0 );
		}
		else if ( vec.theta() < Degree( - 0.5 ) )
		{
			min_point_angle_error = Degree( - 1.0 );
			max_point_angle_error = Degree(   0.0 );
		}
		else
		{
			min_point_angle_error = Degree( - 1.0 );
			max_point_angle_error = Degree( + 1.0 );
		}

		region.add( coord ,
			    point_abs_angle
			      + max_view_line_angle_error
			      + max_point_angle_error
			      + EPS ,
			    coord + D2_Vector( D2_Vector::Pole , 1.0 ,
					       point_abs_angle
						 + Degree( 90.0 ) ) );

#if 0
		try
		{
			D2_Vector	true_my_coordinate
			 = Field_Recog::server_debug_info().true_my_coordinate;

			dbg << "angle error = "
			    << rad_to_deg((coord - true_my_coordinate).theta()
					   - point_abs_angle) << endl;

			if ( region.in_region( true_my_coordinate ) )
			{
				dbg << "in_region 1 OK" << endl;
			}
			else
			{
				cerr << "NOT in_region 1 !!!" << endl;
			}

		} catch(...){}
#endif

		region.add( coord ,
			    point_abs_angle
			      + min_view_line_angle_error
			      + min_point_angle_error
			      - EPS ,
			    coord + D2_Vector( D2_Vector::Pole , 1.0 ,
					       point_abs_angle
						 - Degree( 90.0 ) ) );


#if 0
		try
		{
			D2_Vector	true_my_coordinate
			 = Field_Recog::server_debug_info().true_my_coordinate;

			if ( region.in_region( true_my_coordinate ) )
			{
				dbg << "in_region 2 OK" << endl;
			}
			else
			{
				cerr << "NOT in_region 2 !!!" << endl;
			}

		} catch(...){}
#endif


		double	r_min;
		double	r_max;

		far_object_unquantized_distance( param ,
						 vec.r() , false ,
						 &r_min , &r_max );

		dbg << "r_min = " << r_min << endl;
		dbg << "r_max = " << r_max << endl;

		r_min -= 0.01;
		r_max += 0.01;

		D2_Vector	max_point_vector( D2_Vector::Pole ,
						  r_max ,
						  point_abs_angle
						    + Degree( 180.0 ) );

		D2_Vector	max_point = coord + max_point_vector;

		region.add( max_point , point_abs_angle + Degree( 90.0 ) ,
			    coord );

#if 0
		try
		{
			D2_Vector	true_my_coordinate
			 = Field_Recog::server_debug_info().true_my_coordinate;

			dbg << "true_my_coordinate = ["
			    << true_my_coordinate << "]" << endl;

			dbg << "(true_my_coordinate - coord).r() = "
			    << (true_my_coordinate - coord).r() << endl;

			if ( region.in_region( true_my_coordinate ) )
			{
				dbg << "in_region 3 OK" << endl;
			}
			else
			{
				cerr << "NOT in_region 3 !!!" << endl;
			}

		} catch(...){}
#endif

		D2_Vector	min_point_vector_1( D2_Vector::Pole ,
						    r_min ,
						    point_abs_angle
						     + Degree( 180.0 )
						     + Degree( 2.0 + 0.01 ) );

		D2_Vector	min_point_vector_2( D2_Vector::Pole ,
						    r_min ,
						    point_abs_angle
						      + Degree( 180.0 )
						      - Degree( 2.0 + 0.01 ) );

		D2_Vector	min_point_1 = coord + min_point_vector_1;
		D2_Vector	min_point_2 = coord + min_point_vector_2;

		region.add( min_point_1 , min_point_2 , max_point );

#if 0
		try
		{
			D2_Vector	true_my_coordinate
			 = Field_Recog::server_debug_info().true_my_coordinate;

			if ( region.in_region( true_my_coordinate ) )
			{
				dbg << "in_region 4 OK" << endl;
			}
			else
			{
				cerr << "NOT in_region 4 !!!" << endl;
			}

		} catch(...){}

		{
			vector<D2_Vector>	point_list
						    = region.point_list();

			dbg << "point_list = " << endl;
			for ( size_t  i = 0  ;  i < point_list.size()  ;
			      i ++ )
			{
				dbg << "[" << point_list[i] << "]" << endl;
			}
		}
#endif
	}

#if 0
	try
	{
		if ( Field_Recog::server_debug_info().have_true_my_coordinate )
		{
			D2_Vector	true_my_coordinate
			 = Field_Recog::server_debug_info().true_my_coordinate;

			if ( ! region.in_region( true_my_coordinate ) )
			{
				cerr << "!!! ";
			}
		}

	} catch(...){}
#endif

	if ( ! (region.closed()) )
	{
		throw exception();
	}

	*res_reg = region;
}


void   Sight_Info_Analyzer::get_my_coordinate_by_sum( D2_Vector *  res_vec ,
						      Angle *  res_ang )
	// throw( exception )
{
	*res_ang = Radian(0.0);
	(*res_vec).set( D2_Vector::XY , 0.0 , 0.0 );

	Angle	angle_max_error;
	Angle	angle_min_error;

	Angle	angle = get_my_angle_from_line( &angle_min_error ,
						&angle_max_error );
	angle += (angle_min_error + angle_max_error) / 2.0;

	*res_ang = angle;

#if 0
	pair<Object_Coordinate_Info,Object_Coordinate_Info>	two_objs
		= get_differ_angle_two_objs();

	(*res_vec) = get_my_coordinate_by_angle_and_two_point(
				angle , two_objs.first , two_objs.second );
#endif
#if 0
	require_obj_sorted_by_short_distance();

	D2_Vector	vec( D2_Vector::XY , 0.0 , 0.0 );
	size_t		n = 0;

	for ( size_t  i = 0  ;
	      i < obj_sorted_by_short_distance.size()  ;  i ++ )
	{
		for ( size_t  j = i + 1  ;
		      j < obj_sorted_by_short_distance.size()  ;  j ++ )
		{
			if( fabs(
			   obj_sorted_by_short_distance[i].relative.theta()
			   - obj_sorted_by_short_distance[j].relative.theta() )
			    < deg_to_rad(15.0) )
			{
				continue;
			}

			vec += get_my_coordinate_by_angle_and_two_point(
				     angle ,
				     obj_sorted_by_short_distance[i] ,
				     obj_sorted_by_short_distance[j] );
			n ++;
		}
	}

	if ( n == 0 )
	{
		throw exception();
	}

	(*res_vec) = vec / n;
#endif

#if 1
	require_obj_sorted_by_short_distance();

	if ( obj_sorted_by_short_distance.size() == 0 )
	{
		throw exception();
	}

	// these value is generated by GA
	const	double	one_flag_threshold = 30.3;
	const	double	n_flag_decay = 0.781245;
	const	double	dist_decay = 0.0114752;

	if ( obj_sorted_by_short_distance[0].relative.r()
	     < one_flag_threshold )
	{
		(*res_vec) = object_coordinate_info_to_my_coordinate
				 ( obj_sorted_by_short_distance[0] , angle );
		return;
	}


	D2_Vector	vec( D2_Vector::XY , 0.0 , 0.0 );
	double		n = 0.0;
	double		c = 1.0;

	for ( size_t  i = 0  ;
	      i < obj_sorted_by_short_distance.size()  ;  i ++ )
	{
		D2_Vector	v = object_coordinate_info_to_my_coordinate
				    (obj_sorted_by_short_distance[i] , angle);

		double	e = exp( - dist_decay
				   * obj_sorted_by_short_distance[i]
							 .relative.r() );
		vec += e * c * v;

		n += e * c;

		c *= n_flag_decay;
	}

	(*res_vec) = vec / n;
#endif
}





#if 1
# include  <fstream>
#endif
#if 1
# include  "field_recog.h"
#endif
void   Sight_Info_Analyzer::get_my_coordinate( D2_Vector *  res_vec ,
					       Angle *  res_ang )
	// throw( exception )
{
#if 1
	get_my_coordinate_by_sum( res_vec , res_ang );
#endif

#if 0
	try
	{
		D2_Composite_Straight_Line_Divided_Region_Interface	region;
		get_my_coordinate_by_region_cut( &region , res_ang );

#if 0
		(*res_vec) = region.barycenter();
#else
		if ( ! (region.in_region( *res_vec )) )
		{
			(*res_vec) = region.barycenter();

			dbg << "out of region" << endl;
		}
#endif

	} catch(...){}
#endif


#if 1
	if ( unknown_marker_vector.size() >= 1 )
	{
# if 1
		double	old_error = 0.0;
		try
		{
			if ( Field_Recog::server_debug_info().have_info )
			{
				D2_Vector	true_my_coordinate
					= Field_Recog::server_debug_info()
						.true_my_coordinate;

				old_error
				    = ((*res_vec) - true_my_coordinate).r();

				dbg << "my_coordinate error = "
				    << old_error << endl;
			}

		} catch(...){}
# endif

		// XXX: this is incorrect,
		//        if true_coordinate is out of the field

		dbg << "update by (Flag) or (Goal)" << endl;
		dbg << "old coordinate = [" << *res_vec << "]" << endl;

		static	Fixed_SObject_Location_Translator	loc;
		D2_Vector	closest_object;
		loc.get_closest_object_location(
					&closest_object ,
					*res_vec ,
					unknown_marker_vector[0].second );

		Object_Coordinate_Info	obj;
		obj.relative = unknown_marker_vector[0].first;
		obj.absolute = closest_object;

		(*res_vec) = object_coordinate_info_to_my_coordinate
							 ( obj , *res_ang );

		dbg << "new coordinate = [" << *res_vec << "]" << endl;

# if 1
		double	new_error = 0.0;
		try
		{
			if ( Field_Recog::server_debug_info().have_info )
			{
				D2_Vector	true_my_coordinate
					= Field_Recog::server_debug_info()
						.true_my_coordinate;

				new_error
				    = ((*res_vec) - true_my_coordinate).r();

				dbg << "my_coordinate error = "
				    << new_error << endl;
			}

			dbg << "old_error - new_error = "
			    << old_error - new_error << endl;

		} catch(...){}
# endif
	}
#endif


#if 0
	static	fstream	log( "coordinate-log" , ios::app );

	if ( log )
	{
		const Debug_Info_from_Server &	debug
			= Field_Recog::server_debug_info();

		log << ((*res_vec) - debug.true_my_coordinate).r() << "#";

		double	angle_min_error;
		double	angle_max_error;
		double	angle = get_my_angle_from_line( &angle_min_error ,
							&angle_max_error );
		angle += (angle_min_error + angle_max_error) / 2.0;

		log << Field_Recog::server_debug_info_time() << " "
		    << debug.true_my_coordinate.x() << " "
		    << debug.true_my_coordinate.y() << " "
		    << debug.true_my_body_angle << " "
		    << angle << "\t";

		for ( size_t  i = 0  ;
		      i < obj_sorted_by_short_distance.size()  ;  i ++ )
		{
			log << " "
			    << obj_sorted_by_short_distance[i].relative.x()
			    << " "
			    << obj_sorted_by_short_distance[i].relative.y()
			    << " "
			    << obj_sorted_by_short_distance[i].absolute.x()
			    << " "
			    << obj_sorted_by_short_distance[i].absolute.y();
		}

		log << endl;
	}
#endif
}




Angle  Sight_Info_Analyzer::get_my_angle_from_line( Angle *  error_min ,
						    Angle *  error_max )
	// throw( exception )
{
	// return my angle [- PI , PI)

	if ( line.size() == 0 )
	{
		throw exception();
	}

	Angle	line_theta = line[0].relative.direction;

	Angle	angle;
	Angle	err_min;
	Angle	err_max;

	if ( line_theta < Radian(0.0) )
	{
		angle = Radian(- M_PI / 2.0) - line_theta;
	}
	else
	{
		angle = Radian(  M_PI / 2.0) - line_theta;
	}

	if ( line_theta < Degree( - 0.5 ) )
	{
		err_min = Degree( 0.0 );
		err_max = Degree( + 1.0 );
	}
	else if ( line_theta > Degree( + 0.5 ) )
	{
		err_min = Degree( - 1.0 );
		err_max = Degree( 0.0 );
	}
	else
	{
		err_min = Degree( - 1.0 );
		err_max = Degree( + 1.0 );
	}

	if ( error_min )
	{
		*error_min = err_min;
	}

	if ( error_max )
	{
		*error_max = err_max;
	}


	switch( line[0].entity.which_line )
	{
	case SObject_Line_Identifier::Opponent_Goal_Line:
		break;

	case SObject_Line_Identifier::Left_Wing_Line:
		angle += Radian(M_PI / 2.0);
		break;

	case SObject_Line_Identifier::Our_Goal_Line:
		angle += Radian(M_PI);
		break;

	case SObject_Line_Identifier::Right_Wing_Line:
		angle += Radian(3.0 / 2.0 * M_PI);
		break;
	}

	if ( line.size() >= 2 )
	{
		angle += Radian(M_PI);
	}

#if 0
	angle += (err_min + err_max) / 2.0;
#endif

	while ( angle < Radian(- M_PI) )
	{
		angle += Radian(2.0 * M_PI);
	}

	while ( angle >= Radian(M_PI) )
	{
		angle -= Radian(2.0 * M_PI);
	}

	return( angle );
}


D2_Vector  Sight_Info_Analyzer::get_my_coordinate_by_angle_and_two_point(
			   const Angle &  angle ,
			   const Object_Coordinate_Info &  obj_1 ,
			   const Object_Coordinate_Info &  obj_2 )
{
	D2_Vector	u1 = obj_1.relative;
	D2_Vector	u2 = obj_2.relative;

	D2_Vector	p1 = obj_1.absolute;
	D2_Vector	p2 = obj_2.absolute;
	D2_Vector	p  = p1 - p2;

	u1 = u1.rotate( angle );
	u2 = u2.rotate( angle );

	u1 = u1.normalize();
	u2 = u2.normalize();

	double	n = (u2.x() * p.y()  -  u2.y() * p.x())
		    / (u2.y() * u1.x()  -  u2.x() * u1.y() );

	return( (p1  +  n * u1) );
}


pair<Sight_Info_Analyzer::Object_Coordinate_Info ,
     Sight_Info_Analyzer::Object_Coordinate_Info>
	Sight_Info_Analyzer::get_differ_angle_two_objs()
{
	const	Angle	eps = Degree( 15.0 );

	require_obj_sorted_by_short_distance();

	for( size_t  i = 0  ;  i < static_obj.size()  ;  i ++ )
	{
		for( size_t  j = i + 1  ;  j < static_obj.size()  ;  j ++ )
		{
			if ( (static_obj[i].relative.theta()
			      - static_obj[j].relative.theta() ).abs()
			     > eps )
			{
				pair<Sight_Info_Analyzer::
					Object_Coordinate_Info ,
				     Sight_Info_Analyzer::
					Object_Coordinate_Info>  ret;
				ret.first  = static_obj[i];
				ret.second = static_obj[j];
				return( ret );
			}
		}
	}

	throw exception();
}


void   Sight_Info_Analyzer::get_ball_coordinate( D2_Vector *  vec )
	// throw( exception )
{
	if ( ! ball_info.recognized )
	{
		throw exception();
	}

	try
	{
		require_ball_player_coordinate();
	}
	catch( ... )
	{
		throw exception();
	}

	*vec =  ball_info.absolute;
}


void   Sight_Info_Analyzer::get_player_coordinate( S_Side  side ,
						  int  player_number ,
						  D2_Vector *  vec )
	// throw( exception )
{
	switch( side )
	{
	case S_Side::Our_Side:
		{
			assert( 1 <= player_number
				  && player_number
				   <= static_cast<int>(teammate_info.size()) );

			if ( ! teammate_info[player_number - 1].recognized )
			{
				throw exception();
			}

			*vec = teammate_info[player_number - 1].absolute;
		}
		break;

	case S_Side::Opponent_Side:
		{
			assert( 1 <= player_number
				  && player_number
				   <= static_cast<int>(opponent_info.size()) );

			if ( ! opponent_info[player_number - 1].recognized )
			{
				throw exception();
			}

			*vec = opponent_info[player_number - 1].absolute;
		}
		break;

	case S_Side::Unknown:
		{
			throw exception();
		}
	}
}


// protected:
bool   Sight_Info_Analyzer::relative_sight_to_relative_point
		    ( D2_Vector *  point ,
		      const SObject_Locational_Info_from_Server &  relative )
{
	if ( relative.has_direction && relative.has_distance )
	{
		point -> set( D2_Vector::Pole ,
			      relative.distance , relative.direction );

		return( true );
	}
	else
	{
		return( false );
	}
}


// protected:
bool   Sight_Info_Analyzer::relative_sight_to_relative_vector
		    ( D2_Vector *  vec ,
		      const SObject_Locational_Info_from_Server &  relative )
{
	D2_Vector	relative_point;

	if ( ! (relative.has_d_direction && relative.has_d_distance)
	 ||  ! relative_sight_to_relative_point( &relative_point , relative ) )
	{
		return( false );
	}
	else
	{
		D2_Vector	to;
		to.set( D2_Vector::Pole ,
			relative_point.r() + relative.d_distance ,
			relative_point.theta() + relative.d_direction );

		(*vec) = to - relative_point;

		return( true );
	}
}

D2_Vector  Sight_Info_Analyzer::object_coordinate_info_to_my_coordinate
				( const Object_Coordinate_Info &  obj ,
				  const Angle &  my_angle ) throw()
{
	D2_Vector	coord = obj.absolute;
	D2_Vector	dist  = obj.relative;

	Angle	dist_angle = dist.theta().normalize();

	if ( dist_angle > Degree( 0.5 ) )
	{
		dist_angle += Degree( 0.5 );
	}
	else if ( dist_angle < - Degree( 0.5 ) )
	{
		dist_angle -= Degree( 0.5 );
	}

# if 1
	D2_Vector	v( D2_Vector::Pole ,
			   dist.r() , dist_angle + my_angle + Radian(M_PI) );
# else
	double	r_min;
	double	r_max;
	far_object_unquantized_distance( param ,
					 dist.r() , false ,
					 &r_min , &r_max );

	double	r = (r_min + r_max) / 2.0;

	D2_Vector	v( D2_Vector::Pole ,
			   r , dist_angle + angle + M_PI );
# endif
	return( coord + v );
}
