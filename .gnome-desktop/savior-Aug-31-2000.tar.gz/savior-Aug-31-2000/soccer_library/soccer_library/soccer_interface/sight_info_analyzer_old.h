#ifndef	   SIGHT_INFO_ANALYZER_H_INCLUDED
#define	   SIGHT_INFO_ANALYZER_H_INCLUDED

#include  "information_from_server.h"
#include  "field_state.h"
#include  "sserver_param.h"
#include  "d2_vector.h"
#include  "d2_composite_straight_line_divided_region_interface.h"
#include  <vector>
#include  <utility>
#include  <stdexcept>
#include  <cstddef>

class  Sight_Info_Analyzer
{
public:
	struct  Object_Coordinate_Info
	{
		D2_Vector	absolute;
		D2_Vector	relative;
	};

	struct  Ball_Player_Coordinate_Info
	{
		bool		recognized;
		D2_Vector	relative;
		D2_Vector	absolute;

		bool		have_vector;
		D2_Vector	relative_vector;
		D2_Vector	absolute_vector;

		bool		have_body_direction;
		Angle		relative_body_direction;
		Angle		absolute_body_direction;

		bool		have_face_direction;
		Angle		relative_face_direction;
		Angle		absolute_face_direction;

		Ball_Player_Coordinate_Info()
			: recognized( false ) ,
			  have_vector( false ) ,
			  have_body_direction( false ) ,
			  have_face_direction( false )
			{
			}
	};

protected:
	const SServer_Param &			param;

	std::vector<Object_Coordinate_Info>	static_obj;
	std::vector<Line_Info_from_Server>	line;
	std::vector<std::pair<D2_Vector,bool> >	unknown_marker_vector;
	std::vector<D2_Vector>			unknown_player_vector;

	bool					sorted_by_short_distance;
	std::vector<Object_Coordinate_Info>	obj_sorted_by_short_distance;
	void				require_obj_sorted_by_short_distance();

	bool					have_my_coordinate;
	D2_Vector				my_coordinate;

	bool					have_my_body_angle;
	Angle					my_body_angle;
	const Angle				my_relative_face_angle;
	Angle					my_absolute_face_angle;

	void					require_my_coordinate()
						    /*throw(std::exception)*/;

	bool					have_ball_player_coordinate;
	Ball_Player_Coordinate_Info		ball_info;
	std::vector<Ball_Player_Coordinate_Info>	teammate_info;
	std::vector<Ball_Player_Coordinate_Info>	opponent_info;
	void					require_ball_player_coordinate
						  () /*throw(std::exception)*/;
	void	set_flag_goal_info( const Sight_Info_from_Server &  sight );
	void	set_line_info( const Sight_Info_from_Server &  sight );
	void	set_ball_info( const Sight_Info_from_Server &  sight );
	void	set_player_info( const Sight_Info_from_Server &  sight );

	bool	relative_sight_to_relative_point
		    ( D2_Vector *  point ,
		      const SObject_Locational_Info_from_Server &  relative );

	bool	relative_sight_to_relative_vector
		    ( D2_Vector *  vec ,
		      const SObject_Locational_Info_from_Server &  relative );

public:
	 Sight_Info_Analyzer( const Sight_Info_from_Server &  sight ,
			      const SServer_Param &  param ,
			      const Angle &  relative_face_angle
							 = Radian(0.0) );
	~Sight_Info_Analyzer();

	Field_State	get_field_state( int  my_player_number )
					/*throw(std::exception)*/;

	size_t		n_objects() throw();
	size_t		n_lines() throw();

	void		get_my_coordinate( D2_Vector *  vec ,
					   Angle *  ang )
						/*throw(std::exception)*/;

	void		get_my_coordinate_by_sum( D2_Vector *  res_vec ,
						  Angle *  res_ang )
						/* throw(std::exception) */;

	void		get_my_coordinate_by_region_cut(
			  D2_Composite_Straight_Line_Divided_Region_Interface *
			    reg ,
			  Angle *  ang )
				/*throw(std::exception)*/;

	void		get_ball_coordinate( D2_Vector *  vec )
						/*throw(std::exception)*/;

	void		get_player_coordinate( S_Side  side ,
					       int player_number ,
					       D2_Vector *  vec )
						/*throw(std::exception)*/;

	Angle		get_my_angle_from_line( Angle *  error_min = 0 ,
						Angle *  error_max = 0 )
						/*throw(std::exception)*/;

	D2_Vector	get_my_coordinate_by_angle_and_two_point(
			      const Angle &  angle ,
			      const Object_Coordinate_Info &  obj_1 ,
			      const Object_Coordinate_Info &  obj_2 );

	std::pair<Sight_Info_Analyzer::Object_Coordinate_Info ,
		  Sight_Info_Analyzer::Object_Coordinate_Info>
				get_differ_angle_two_objs();

	D2_Vector	object_coordinate_info_to_my_coordinate
				( const Object_Coordinate_Info &  obj ,
				  const Angle &  my_angle ) throw();
};


#endif	/* SIGHT_INFO_ANALYZER_H_INCLUDED */
