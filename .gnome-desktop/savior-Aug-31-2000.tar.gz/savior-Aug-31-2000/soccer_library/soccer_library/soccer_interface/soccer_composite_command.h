#ifndef	   SOCCER_COMPOSITE_COMMAND_H_INCLUDED
#define	   SOCCER_COMPOSITE_COMMAND_H_INCLUDED

#include  "soccer_command.h"
#include  "ref_count_ptr.h"
#include  <string>

class  Soccer_Composite_Command
{
protected:
	Soccer_Command			base;

	ref_count_ptr<Soccer_Command>	turn_neck_command;
	ref_count_ptr<Soccer_Command>	change_view_command;
	ref_count_ptr<Soccer_Command>	say_command;
	ref_count_ptr<Soccer_Command>	sense_body_command;

public:
	 Soccer_Composite_Command();
	 Soccer_Composite_Command( const Soccer_Command & );
	~Soccer_Composite_Command();

	Soccer_Composite_Command	operator +
					( const Soccer_Composite_Command & )
									const;
	Soccer_Composite_Command &	operator +=
					( const Soccer_Composite_Command & );

	Soccer_Composite_Command &	operator +=
					( const Soccer_Command &  c );


	Soccer_Command::Command_Type		base_type() const;

	const Soccer_Command &			base_command() const;
	Soccer_Command &			base_command();

	const ref_count_ptr<Soccer_Command>	say() const;
	const ref_count_ptr<Soccer_Command>	change_view() const;
	const ref_count_ptr<Soccer_Command>	turn_neck() const;
	const ref_count_ptr<Soccer_Command>	sense_body() const;

	Soccer_Composite_Command &	add_say
					( const std::string &  message );

	Soccer_Composite_Command &	add_change_view
					( View_Width  width ,
					  View_Quality  quality );

	Soccer_Composite_Command &	add_turn_neck
					( const Angle &  direction );

	Soccer_Composite_Command &	add_sense_body();
};


#endif	/* SOCCER_COMPOSITE_COMMAND_H_INCLUDED */
