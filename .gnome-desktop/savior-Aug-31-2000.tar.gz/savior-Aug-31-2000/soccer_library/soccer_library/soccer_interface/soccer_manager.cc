#include  "soccer_manager.h"
#include  "debugstream.h"
#include  <unistd.h>
#include  <string>
#include  <cstddef>

using namespace std;

Soccer_Manager::Soccer_Manager( const SServer_Param & p ,
				SServer_Player_Connection &  s )
	: param( p ) , server_connection( s ) , debug_server( false ) ,
	  game_over_flag( false ) ,
	  field_recog_list() ,
	  main_field_recog( static_cast<Field_Recog_Abstract *>(NULL) ) ,
	  debug_connection( static_cast<Debug_Client_Connection *>(NULL) ) ,
	  debug_view( new Client_Debug_View( p ) )
{
}

Soccer_Manager::~Soccer_Manager()
{
}

void   Soccer_Manager::register_field_recog( Field_Recog_Abstract *  fr ,
					     bool  main_field_recog_flag )
{
	field_recog_list.push_back( fr );

	if ( main_field_recog_flag )
	{
		main_field_recog = fr;
	}
}

void   Soccer_Manager::register_debug_connection
					( Debug_Client_Connection * d )
{
	debug_connection = d;
}

bool   Soccer_Manager::game_over() const throw()
{
	return( game_over_flag );
}

bool   Soccer_Manager::server_no_response() const throw()
{
	return( ! server_connection.responsive() );
}

void   Soccer_Manager::next_step()
{
	Debug_Stream::dbg << endl;
	Debug_Stream::dbg << endl;

	//
	// send debug info to debug monitor
	//
	if ( debug_connection )
	{
		string	encoded_string;

		if ( debug_view -> encode( &encoded_string ) )
		{
			debug_connection -> send( encoded_string );
		}

#if 0
		cout << "encoded_string = [" << encoded_string << "]" << endl;
#endif
	}


	// XXX

	int	latest_body_info_time = -1;
	int	latest_sight_info_time = -1;
	int	latest_debug_info_time = -1;
	bool	this_step_sight_info = false;

	Information_from_Server	info;

	while( server_connection.responsive() )
	{
		if ( server_connection.recv_info( &info , true ) )
		{
			Time_Stamp	stamp;
			stamp.set_current_time();

			this -> register_info( info , stamp );

			if ( info.type()
			     == Information_from_Server::Type_Body )
			{
				latest_body_info_time = info.time();
			}
			else if ( info.type()
				  == Information_from_Server::Type_Sight )
			{
				latest_sight_info_time = info.time();
				if ( latest_body_info_time != -1 )
				{
					this_step_sight_info = true;
				}
			}
			else if ( info.type()
				  == Information_from_Server::Type_Debug )
			{
				latest_debug_info_time = info.time();
			}
		}

		if ( latest_body_info_time != -1
		  && latest_sight_info_time != -1
		  && latest_sight_info_time == latest_body_info_time
		  && this_step_sight_info
		  && ( (! this -> debug_server)
		      || latest_debug_info_time == latest_body_info_time) )
		{
			break;
		}
	}

	for ( size_t  i = 0  ;  i < field_recog_list.size()  ;  i ++ )
	{
		field_recog_list[i] -> update();
	}

	//
	// make debug view
	//
	debug_view = new Client_Debug_View( param );

	if ( main_field_recog )
	{
		debug_view -> set_field_snapshot( main_field_recog
						       -> snapshot() );
	}
}


// protected:
void   Soccer_Manager::register_info( const Information_from_Server &  info ,
				      const Time_Stamp &  stamp )
{
	Debug_Stream::dbg << "recv[" << info.raw_message() << "]" << endl;

	if ( (! debug_server)
	  && info.type() == Information_from_Server::Type_Debug )
	{
		debug_server = true;
	}

	for ( size_t  i = 0  ;  i < field_recog_list.size()  ;  i ++ )
	{
		field_recog_list[i] -> register_info( info , stamp );
	}
}


int    Soccer_Manager::init_connection( const string &  team_name ,
					bool  goalie ,
					Game_Info *  g_info ,
					int  major_version ,
					int  minor_version ,
					int  n_trial )
	throw()
{
	for ( int  n = 1  ;  n <= n_trial  ;  n ++ )
	{
		int	ret;
		ret = this -> send_init( team_name , goalie , g_info ,
					 major_version , minor_version );

		if ( ret != -1 )
		{
			return( ret );
		}

		if ( n != n_trial )
		{
			sleep( 1 );
		}
	}

	return( -1 );
}


int    Soccer_Manager::reconnect_connection( const std::string &  team_name ,
					     int  player_number ,
					     Game_Info *  g_info ,
					     long  interval_usec )
	throw()
{
	return( this -> send_reconnect( team_name , player_number ,
					g_info , interval_usec ) );
}


//
// Server Raw Command
//

int    Soccer_Manager::send_init( const string &  team_name ,  bool  goalie ,
				    Game_Info *  g_info ,
				    int  major_version ,  int  minor_version )
	throw()
{
	Game_Info	game_info;

	int	ret = server_connection.send_init( team_name ,
						   goalie ,
						   &game_info ,
						   major_version ,
						   minor_version );

	if ( g_info )
	{
		*g_info = game_info;
	}


	if ( ret == -1  ||  game_info.my_player_number <= 0 )
	{
		cerr << "not registered." << endl;
		return( -1 );
	}

	return( ret );
}

int    Soccer_Manager::send_reconnect( const string &  team_name ,
					 int  player_number ,
					 Game_Info *  g_info ,
					 long  interval_usec ) throw()
{
	Game_Info	game_info;

	int	ret = server_connection.send_reconnect( team_name ,
							player_number ,
							&game_info ,
							interval_usec );

	if ( g_info )
	{
		*g_info = game_info;
	}

	if ( ret == -1  ||  game_info.my_player_number <= 0 )
	{
		cerr << "not registered." << endl;
		return( -1 );
	}

	return( ret );
}

int    Soccer_Manager::send_bye( long  interval_usec ) throw()
{
	return( server_connection.send_bye( interval_usec ) );
}

int    Soccer_Manager::send_move( double  x ,  double  y ,
				  long  interval_usec ) throw()
{
	return( server_connection.send_move( x , y , interval_usec ) );
}

int    Soccer_Manager::send_dash( double  power ,
				  long  interval_usec ) throw()
{
	return( server_connection.send_dash( power , interval_usec ) );
}

int    Soccer_Manager::send_kick( double  power ,  const Angle &  direction ,
				  long  interval_usec ) throw()
{
	return( server_connection.send_kick( power , direction ,
					     interval_usec ) );
}

int    Soccer_Manager::send_turn( const Angle &  moment ,
				  long  interval_usec ) throw()
{
	return( server_connection.send_turn( moment , interval_usec ) );
}

int    Soccer_Manager::send_say( const string &  message ,
				 long  interval_usec ) throw()
{
	return( server_connection.send_say( message , interval_usec ) );
}

int    Soccer_Manager::send_catch( const Angle &  direction ,
				   long  interval_usec ) throw()
{
	return( server_connection.send_catch( direction , interval_usec ) );
}

int    Soccer_Manager::send_change_view( View_Width  width ,
					 View_Quality  quality ,
					 long  interval_usec ) throw()
{
	return( server_connection.send_change_view( width , quality ,
						    interval_usec ) );
}

int    Soccer_Manager::send_sense_body( long  interval_usec ) throw()
{
	return( server_connection.send_sense_body( interval_usec ) );
}

int    Soccer_Manager::send_turn_neck( const Angle &  moment ,
				       long  interval_usec ) throw()
{
	int	ret = server_connection.send_turn_neck( moment ,
							interval_usec );
	Time_Stamp	stamp;
	stamp.set_current_time();

	for ( size_t  i = 0  ;  i < field_recog_list.size()  ;  i ++ )
	{
		field_recog_list[i] -> turn_neck_sent( moment , stamp );
	}

	return( ret );
}

int    Soccer_Manager::send_command( const Soccer_Command &  command ,
				     long  interval_usec ) throw()
{
	int	ret = server_connection.send_command( command ,
						      interval_usec );

	Time_Stamp	stamp;
	stamp.set_current_time();

	switch( command.type() )
	{
	case Soccer_Command::Move_Command:
	case Soccer_Command::Dash_Command:
	case Soccer_Command::Kick_Command:
	case Soccer_Command::Turn_Command:
	case Soccer_Command::Catch_Ball_Command:
	case Soccer_Command::Wait_Command:
	case Soccer_Command::No_Command_Command:
	case Soccer_Command::Illegal_Command:
		for ( size_t  i = 0  ;  i < field_recog_list.size()  ;  i ++ )
		{
			field_recog_list[i]
			    -> base_command_sent( command , stamp );
		}
		break;

	case Soccer_Command::Turn_Neck_Command:
		for ( size_t  i = 0  ;  i < field_recog_list.size()  ;  i ++ )
		{
			field_recog_list[i]
			    -> turn_neck_sent( command.turn_neck_direction() ,
					       stamp );
		}
		break;

	default:
		break;
	}


	return( ret );
}


int    Soccer_Manager::send_composite_command
		( const Soccer_Composite_Command &  composite_command ,
		  long  interval_usec ) throw()
{
	int	ret = -1;

	//
	// Send Main Command
	//
	switch( composite_command.base_type() )
	{
	case Soccer_Command::Move_Command:
	case Soccer_Command::Dash_Command:
	case Soccer_Command::Kick_Command:
	case Soccer_Command::Turn_Command:
	case Soccer_Command::Catch_Ball_Command:
	case Soccer_Command::Wait_Command:
	case Soccer_Command::No_Command_Command:
	case Soccer_Command::Illegal_Command:
	      {
		ret = server_connection.send_command(
			   composite_command.base_command() , interval_usec );

		Time_Stamp	stamp;
		stamp.set_current_time();

		for ( size_t  i = 0  ;  i < field_recog_list.size()  ;  i ++ )
		{
			field_recog_list[i]
			    -> base_command_sent(
				    composite_command.base_command() , stamp );
		}
	      }
		break;

	default:
		ret = -1;
		break;
	}


	//
	// Clear Stream
	//
	Information_from_Server		info;
	while( server_connection.recv_info( &info ) )
	{
		if ( ! server_connection.responsive() )
		{
			break;
		}

		Time_Stamp	stamp;
		stamp.set_current_time();

		this -> register_info( info , stamp );
	}


	//
	// Return If Illegal Command
	//
	if ( composite_command.base_type() == Soccer_Command::Illegal_Command )
	{
		return( ret );
	}


	//
	// Send Sub Commands
	//

	// turn_neck
	if ( composite_command.turn_neck() )
	{
		Time_Stamp	stamp;
		stamp.set_current_time();

		if ( server_connection.send_command(
				    *(composite_command.turn_neck()) ,
				    interval_usec ) == -1 )
		{
			ret = -1;
		}

		for ( size_t  i = 0  ;  i < field_recog_list.size()  ;  i ++ )
		{
			field_recog_list[i]
			  -> turn_neck_sent( composite_command.turn_neck()
						  -> turn_neck_direction() ,
					     stamp );
		}
	}

	// change_view
	if ( composite_command.change_view() )
	{
		if ( server_connection.send_command(
				    *(composite_command.change_view()) ,
				    interval_usec ) == -1 )
		{
			ret = -1;
		}
	}

	// sense_body
	if ( composite_command.sense_body() )
	{
		if ( server_connection.send_command(
				    *(composite_command.sense_body()) ,
				    interval_usec ) == -1 )
		{
			ret = -1;
		}
	}

	// say
	if ( composite_command.say() )
	{
		if ( server_connection.send_command(
				    *(composite_command.say()) ,
				    interval_usec ) == -1 )
		{
			ret = -1;
		}
	}

	return( ret );
}

int    Soccer_Manager::send_raw_message( const std::string &  str ,
					 long  interval_usec ) throw()
{
	return( server_connection.send( str , interval_usec ) );
}




int    Soccer_Manager::send_reconnect( const string &  team_name ,
				       int  player_number ,
				       bool  default_wait ) throw()
{
	return( server_connection.send_reconnect( team_name , player_number ,
						  NULL , default_wait ) );
}

int    Soccer_Manager::send_bye( bool  default_wait ) throw()
{
	return( server_connection.send_bye( default_wait ) );
}


int    Soccer_Manager::send_move( double  x ,  double  y ,
				  bool  default_wait ) throw()
{
	return( server_connection.send_move( x , y , default_wait ) );
}

int    Soccer_Manager::send_dash( double  power ,
				  bool  default_wait ) throw()
{
	return( server_connection.send_dash( power , default_wait ) );
}

int    Soccer_Manager::send_kick( double  power ,  const Angle &  direction ,
				  bool  default_wait ) throw()
{
	return( server_connection.send_kick( power , direction ,
					     default_wait ) );
}

int    Soccer_Manager::send_turn( const Angle &  moment ,
				  bool  default_wait ) throw()
{
	return( server_connection.send_turn( moment , default_wait ) );
}

int    Soccer_Manager::send_say( const string &  message ,
				 bool  default_wait ) throw()
{
	return( server_connection.send_say( message , default_wait ) );
}

int    Soccer_Manager::send_catch( const Angle &  direction ,
				   bool  default_wait ) throw()
{
	return( server_connection.send_catch( direction , default_wait ) );
}

int    Soccer_Manager::send_change_view( View_Width  width ,
					   View_Quality  quality ,
					   bool  default_wait ) throw()
{
	return( server_connection.send_change_view( width , quality ,
						    default_wait ) );
}

int    Soccer_Manager::send_sense_body( bool  default_wait ) throw()
{
	return( server_connection.send_sense_body( default_wait ) );
}

int    Soccer_Manager::send_turn_neck( const Angle &  direction ,
				       bool  default_wait ) throw()
{
	return( server_connection.send_turn_neck( direction , default_wait ) );
}

int    Soccer_Manager::send_command( const Soccer_Command &  command ,
				     bool  default_wait ) throw()
{
	return( server_connection.send_command( command , default_wait ) );
}

int    Soccer_Manager::send_composite_command
		( const Soccer_Composite_Command &  composite_command ,
		  bool  default_wait ) throw()
{
	return( this -> send_composite_command
		( composite_command ,
		  (default_wait ? server_connection.default_wait() : 0) ) );
}

int    Soccer_Manager::send_raw_message( const std::string &  str ,
					 bool  default_wait ) throw()
{
	return( server_connection.send( str , default_wait ) );
}
