#ifndef	   SOCCER_MANAGER_H_INCLUDED
#define	   SOCCER_MANAGER_H_INCLUDED

// Author:		H. Shimora
// Last-Modified:	Apr 27 2000
// Created:		Apr 27 2000
// Version:		0.00

///-----------------------------------------------
/// Change Log:
///-----------------------------------------------
// version 0.00  Apr 27 2000    base version.
//
//

#include  "sserver_param.h"
#include  "sserver_player_connection.h"
#include  "debug_client_connection.h"
#include  "field_recog_abstract.h"
#include  "soccer_command.h"
#include  "client_debug_view.h"
#include  <string>

class  Soccer_Manager
{
private:
	const SServer_Param &		param;
	SServer_Player_Connection &	server_connection;
	bool				debug_server;

	bool				game_over_flag;

	std::vector< Field_Recog_Abstract * >  field_recog_list;
	Field_Recog_Abstract *		       main_field_recog;

	Debug_Client_Connection *		debug_connection;
	ref_count_ptr<Client_Debug_View>	debug_view;

protected:
	void	register_info( const Information_from_Server &  info ,
			       const Time_Stamp &  stamp );
public:
	 Soccer_Manager( const SServer_Param & ,
			 SServer_Player_Connection & );
	~Soccer_Manager();

	//
	// Register Field_Recog
	//
	void	register_field_recog( Field_Recog_Abstract * ,
				      bool  main_field_recog_flag = true );

	//
	// Register Debug Connection
	//
	void	register_debug_connection( Debug_Client_Connection * );


	//
	// playing game now or not.
	//
	bool	game_over() const throw();

	//
	// server responsive or not.
	//
	bool	server_no_response() const throw();

	//
	// go to beginning of next step
	//
	void	next_step();



	//
	// establish connection
	//
	int	init_connection(
			const std::string &  team_name ,
			bool  goalie = false ,
			Game_Info *  g_info = NULL ,
			int  major_version
			  = SServer_Player_Connection
				::SSERVER_DEFAULT_MAJOR_VERSION ,
			int  minor_version
			  = SServer_Player_Connection
				::SSERVER_DEFAULT_MINOR_VERSION ,
			int  n_trial = 2 )
			  throw();

	int	reconnect_connection( const std::string &  team_name ,
				      int  player_number ,
				      Game_Info *  g_info ,
				      long  interval_usec = 0 ) throw();

	//
	// Server Raw Command
	//
	int	send_init( const std::string &  team_name ,
			   bool  goalie = false ,
			   Game_Info *  g_info = NULL ,
			   int  major_version
				  = SServer_Player_Connection
				     ::SSERVER_DEFAULT_MAJOR_VERSION ,
			   int  minor_version
				  = SServer_Player_Connection
				     ::SSERVER_DEFAULT_MINOR_VERSION ) throw();

	int	send_reconnect( const std::string &  team_name ,
				int  player_number ,
				Game_Info *  g_info ,
				long  interval_usec = 0 ) throw();

	int	send_bye( long  interval_usec = 0 ) throw();

	int	send_move( double  x ,  double  y ,
			   long  interval_usec = 0 ) throw();
	int	send_dash( double  power ,  long  interval_usec = 0 ) throw();

	int	send_kick( double  power ,  const Angle &  direction ,
			   long  interval_usec = 0 ) throw();
	int	send_turn( const Angle &  moment ,
			   long  interval_usec = 0 ) throw();
	int	send_say( const std::string &  message ,
			  long  interval_usec = 0 ) throw();
	int	send_catch( const Angle &  direction ,
			    long  interval_usec = 0 ) throw();
	int	send_change_view( View_Width  width ,  View_Quality  quality ,
				  long  interval_usec = 0 ) throw();
	int	send_sense_body( long  interval_usec = 0 ) throw();
	int	send_turn_neck( const Angle &  moment ,
				long  interval_usec = 0 ) throw();
	int	send_composite_command
			( const Soccer_Composite_Command &  composite_command ,
			  long  interval_usec = 0 ) throw();

	int	send_raw_message( const std::string &  str ,
				  long  interval_usec = 0 ) throw();


	int	send_command( const Soccer_Command &  command ,
			      long  interval_usec = 0 )	throw();

	int	send_reconnect( const std::string &  team_name ,
				int  player_number ,
				bool  default_wait ) throw();

	int	send_bye( bool  default_wait ) throw();

	int	send_move( double  x ,  double  y ,
			   bool  default_wait ) throw();
	int	send_dash( double  power ,  bool  default_wait ) throw();
	int	send_kick( double  power ,  const Angle &  direction ,
			   bool  default_wait ) throw();
	int	send_turn( const Angle &  moment ,
			   bool  default_wait ) throw();
	int	send_say( const std::string &  message ,
			  bool  default_wait ) throw();
	int	send_catch( const Angle &  direction ,
			    bool  default_wait ) throw();
	int	send_change_view( View_Width  width ,  View_Quality  quality ,
				  bool  default_wait ) throw();
	int	send_sense_body( bool  default_wait ) throw();
	int	send_turn_neck( const Angle &  direction ,
				bool  default_wait ) throw();

	int	send_command( const Soccer_Command &  command ,
			      bool  default_wait ) throw();
	int	send_composite_command
			( const Soccer_Composite_Command &  composite_command ,
			  bool  default_wait ) throw();

	int	send_raw_message( const std::string &  str ,
				  bool  default_wait ) throw();
};


#endif	/* SOCCER_MANAGER_H_INCLUDED */
