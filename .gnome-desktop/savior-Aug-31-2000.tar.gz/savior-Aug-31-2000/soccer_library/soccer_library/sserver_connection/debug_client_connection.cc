#include  "debug_client_connection.h"
#include  "debugstream.h"
#include  <string>

using namespace std;

Debug_Client_Connection::Debug_Client_Connection( const string &  host ,
						  ip_port_number_t  port ,
						  long  max_response )
	: udp( host , port ,
	       Debug_Server_Connection::MAX_MESSAGE_LENGTH , max_response )
{
}

Debug_Client_Connection::~Debug_Client_Connection()
{
}

int   Debug_Client_Connection::fd() const
{
	return( udp.fd() );
}


Debug_Client_Connection::operator bool() const
{
	return( this -> udp.operator bool() );
}

bool   Debug_Client_Connection::responsive() const
{
	return( this -> udp.responsive() );
}


int    Debug_Client_Connection::send( const string &  str )
{
	int	n = this -> udp.send( str );

#if 1
	Debug_Stream::dbg << "send[" << str << "]" << endl;
#endif

	// XXX
	// compare int and size_t
	//
	if ( static_cast<size_t>(n) == str.length() )
	{
		return( n );
	}
	else
	{
		return( -1 );
	}
}


bool   Debug_Client_Connection::recv( string *  data ,  bool  block )
{
	(void)(this -> udp.recv( data  , block ));

#if 1
	if ( data -> length() != 0 )
	{
		Debug_Stream::dbg << "recv[" << (*data) << "]" << endl;
	}
#endif

	return( data -> length() != 0 );
}


bool   Debug_Client_Connection::recv( string *  data ,  long  usec )
{
	(void)(this -> udp.recv( data , usec ));

#if 1
	if ( data -> length() != 0 )
	{
		Debug_Stream::dbg << "recv[" << (*data) << "]" << endl;
	}
#endif

	return( data -> length() != 0 );
}
