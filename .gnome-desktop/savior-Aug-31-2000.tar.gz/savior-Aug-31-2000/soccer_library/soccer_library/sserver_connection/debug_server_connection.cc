#include  "debug_server_connection.h"
#include  "debugstream.h"

using namespace std;

Debug_Server_Connection::Debug_Server_Connection( ip_port_number_t  port ,
						  long  max_response )
	: udp( port , MAX_MESSAGE_LENGTH , max_response )
{
}

Debug_Server_Connection::~Debug_Server_Connection()
{
}

int   Debug_Server_Connection::fd() const
{
	return( udp.fd() );
}


Debug_Server_Connection::operator bool() const
{
	return( this -> udp.operator bool() );
}

bool   Debug_Server_Connection::responsive() const
{
	return( this -> udp.responsive() );
}


bool   Debug_Server_Connection::recv( string *  data ,  bool  block )
{
	(void)(this -> udp.recv( data  , block ));

#if 1
	if ( data -> length() != 0 )
	{
		Debug_Stream::dbg << "recv[" << (*data) << "]" << endl;
	}
#endif

	return( data -> length() != 0 );
}


bool   Debug_Server_Connection::recv( string *  data ,  long  usec )
{
	(void)(this -> udp.recv( data , usec ));

#if 1
	if ( data -> length() != 0 )
	{
		Debug_Stream::dbg << "recv[" << (*data) << "]" << endl;
	}
#endif

	return( data -> length() != 0 );
}
