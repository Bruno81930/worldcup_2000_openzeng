#ifndef	   DEBUG_SERVER_CONNECTION_H_INCLUDED
#define	   DEBUG_SERVER_CONNECTION_H_INCLUDED

// Author:		H. Shimora
// Last-Modified:	May 25 2000
// Created:		May 25 2000
// Version:		0.00

///-----------------------------------------------
/// Change Log:
///-----------------------------------------------
// version 0.00  May 25 2000    base version.
//
//


#include  "udp_connection.h"
#include  "ip_address.h"

class  Debug_Server_Connection
{
public:
	static	const	size_t	MAX_MESSAGE_LENGTH = 65536;
	static	const	long	DEFAULT_MAX_RESPONCE_TIME
						= 5 * 1000 * 1000; // 5 sec.

	static	const	ip_port_number_t	DEFAULT_PORT = 6032;
	static	const	ip_port_number_t	DEFAULT_PORT_OFFSET = 32;

protected:
	UDP_Connection	udp;

protected:
	// Don't allow this.
	 Debug_Server_Connection( const Debug_Server_Connection & );
	// Don't allow this.
	 Debug_Server_Connection &
			 operator=( const Debug_Server_Connection & );

public:
		 Debug_Server_Connection( ip_port_number_t  port
							     = DEFAULT_PORT ,
					  long  max_response
						 = DEFAULT_MAX_RESPONCE_TIME );
	virtual	~Debug_Server_Connection();

	virtual	int		fd() const;

	virtual			operator bool() const;
	virtual	bool		responsive() const;

	virtual	bool		recv( std::string *  data ,
				      bool  block = false );

	virtual	bool		recv( std::string *  data ,  long  usec );
};

#endif	/* DEBUG_SERVER_CONNECTION_H_INCLUDED */
