#ifdef    SSERVER_MESSAGE_TRANSLATOR_TEST
#include  "sserver_message_translator.h"
#include  <string>
#include  <iostream>

#include  "prof_stopwatch.h"

using namespace std;

int    main( void )
{
	Information_from_Server	info;

#if 1
# if 0
	string	input = "(sense_body 12 (view_mode high normal) (stamina 2000 0.5) (speed 2.2) (head_angle 3.6) (kick 2) (dash 7) (turn 5) (say 9) (turn_neck 4))\n";
# elif 0
	string	input = "(see 0 ((Goal) 2.5 180) ((goal r) 102.5 0) ((flag c) 49.9 0) ((flag r t) 107.8 -18) ((flag r b) 107.8 18) ((flag p l c) 14 0 -0 0) ((flag p r t) 88.2 -13) ((flag p r c) 85.6 0) ((flag p r b) 88.2 13) ((flag g r t) 102.5 -3) ((flag g r b) 102.5 3) ((flag t r 50) 107.8 -21) ((flag b r 50) 107.8 21) ((flag r t 30) 111.1 -15) ((flag r t 20) 108.9 -10) ((flag r t 10) 107.8 -5) ((flag r 0) 107.8 0) ((flag r b 10) 107.8 5) ((flag r b 20) 108.9 10) ((flag r b 30) 111.1 15) ((ball) 49.4 0) ((line r) 102.5 -90))\n";
# elif 1
	string	input = "(see 0 ((G) 2.5 180) ((g r) 102.5 0) ((f c) 49.9 0) ((f c t) 60.3 -34) ((f c b) 60.3 34) ((f r t) 107.8 -18) ((f r b) 107.8 18) ((f p l c) 14 0 -0 0) ((f p r t) 88.2 -13) ((f p r c) 85.6 0) ((f p r b) 88.2 13) ((f g r t) 102.5 -3) ((f g r b) 102.5 3) ((f t l 10) 55.7 -44) ((f t 0) 63.4 -37) ((f t r 10) 71.5 -33) ((f t r 20) 79.8 -29) ((f t r 30) 89.1 -25) ((f t r 40) 98.5 -23) ((f t r 50) 107.8 -21) ((f b l 10) 55.7 44) ((f b 0) 63.4 37) ((f b r 10) 71.5 33) ((f b r 20) 79.8 29) ((f b r 30) 89.1 25) ((f b r 40) 98.5 23) ((f b r 50) 107.8 21) ((f r t 30) 111.1 -15) ((f r t 20) 108.9 -10) ((f r t 10) 107.8 -5) ((f r 0) 107.8 0) ((f r b 10) 107.8 5) ((f r b 20) 108.9 10) ((f r b 30) 111.1 15) ((b) 49.4 0) ((p \"test\" 2 goalie) 0.6 0 0 0 0 0) ((l r) 102.5 -90))\n";
# else
	string	input = "(see 50 ((g r) 90 4) ((f c) 37.7 5) ((f r t) 96.5 -16) ((F) 2 29) ((f p r t) 75.9 -10) ((f p r c) 73.7 4) ((f p r b) 76.7 19) ((f g r t) 90.9 0) ((f g r b) 90.9 8) ((f t r 40) 86.5 -22) ((f t r 50) 95.6 -19) ((f r t 30) 99.5 -13) ((f r t 20) 97.5 -7) ((f r t 10) 95.6 -1) ((f r 0) 95.6 4) ((f r b 10) 95.6 10) ((f r b 20) 97.5 16) ((f r b 30) 100.5 21) ((b) 6.7 0 -0 -0) ((l r) 90.9 -86))\n";
# endif

	SServer_Message_Translator::parse_message( &info ,
						   input ,
						   S_Side_LR::Left_Side ,
						   "test-team" );
#else
	string	input = "(see 0 ((Goal) 2.5 180) ((goal r) 102.5 0) ((flag c) 49.9 0) ((flag r t) 107.8 -18) ((flag r b) 107.8 18) ((flag p l c) 14 0 -0 0) ((flag p r t) 88.2 -13) ((flag p r c) 85.6 0) ((flag p r b) 88.2 13) ((flag g r t) 102.5 -3) ((flag g r b) 102.5 3) ((flag t r 50) 107.8 -21) ((flag b r 50) 107.8 21) ((flag r t 30) 111.1 -15) ((flag r t 20) 108.9 -10) ((flag r t 10) 107.8 -5) ((flag r 0) 107.8 0) ((flag r b 10) 107.8 5) ((flag r b 20) 108.9 10) ((flag r b 30) 111.1 15) ((ball) 49.4 0) ((line r) 102.5 -90))\n";

	Prof_Stopwatch	sw;

	sw.start();

	int	LOOP = 1000;

	for ( int i = 0  ;  i < LOOP  ;  i ++ )
	{
		SServer_Message_Translator::parse_message(
			  &info , input , S_Side_LR::Left_Side , "test-team" );
	}

	sw.stop();

	cout << sw.real().usec() / LOOP << " usec" << endl;
#endif

	if ( info.illegal() )
	{
		cerr << "Unknown format: ["
		     << info.raw_message() << "]" << endl;
	}

	return( 0 );
}
#endif // SSERVER_MESSAGE_TRANSLATOR_TEST




#include  "sserver_message_translator.h"
#include  "ref_count_ptr.h"
#include  <string>
#include  <strstream>
#include  <cstring>
#include  <cfloat>
#include  <cmath>
#include  <cstdio>
#include  <climits>

using namespace std;

#include  "sserver_param.h"
const	size_t	SServer_Message_Translator::SSERVER_MAX_MESSAGE_LENGTH
			= SServer_Param::SSERVER_MAX_MESSAGE_LENGTH;

static	const	double	SHOWINFO_SCALE = 16.0;

string  SServer_Message_Translator::init_command( const string &  team_name ,
						  bool  goalie ,
						  int  major_version ,
						  int  minor_version )
{
	//
	// Send "init" message to server.
	//
	string	send_string = static_cast<string>("(init ") + team_name;

	if ( major_version >= 0 )
	{
		ref_count_ptr<char>	version_string;
		try
		{
			version_string
			    = new char[1024 + SSERVER_MAX_MESSAGE_LENGTH + 1];
		}
		catch( ... )
		{
			cerr << "Can't allocate memory" << endl;
			throw;
		}

		sprintf( version_string.get() , " (version %d.%02d)" ,
						major_version ,
						minor_version );
		send_string += version_string.get();
	}

	if ( goalie )
	{
		send_string += " (goalie)";
	}

	send_string += ")\n";

	return( send_string );
}


string  SServer_Message_Translator::reconnect_command(
					      const string &  team_name ,
					      int  player_number )
{
	bool	bad_player_number = false;

	if ( ! (1 <= player_number && player_number <= MAX_PLAYER) )
	{
		cerr << "bad player number: " << player_number << endl;
		bad_player_number = true;
	}

#ifndef LIB_MEMORY
	strstream	send_string;

	send_string  <<  "(reconnect " << team_name << " "
		     <<  player_number << ")" << endl  << ends;

	return( send_string.str() );
#else
	if ( team_name.length() > SSERVER_MAX_MESSAGE_LENGTH )
	{
		cerr << "teamname too long: \"" << team_name << "\"" << endl;
		return( "" );
	}

	if ( bad_player_number )
	{
		return( "" );
	}

	ref_count_ptr<char>	buf;
	try
	{
		buf = new char[ 1024 + SSERVER_MAX_MESSAGE_LENGTH + 1 ];
	}
	catch( ... )
	{
		cerr << "Can't allocate memory" << endl;
		throw;
	}

	sprintf( buf.get() , "(reconnect %s %d)\n" ,
		 team_name.c_str() , player_number );

	return( buf.get() );
#endif
}


string  SServer_Message_Translator::bye_command()
{
	return( "(bye)\n" );
}


string  SServer_Message_Translator::move_command( double  x ,  double  y )
{
#ifndef LIB_MEMORY
	strstream	send_string;
	send_string.precision( DBL_DIG );

	send_string  <<  "(move " << x << " " << y << ")" << endl  <<  ends;

	return( send_string );
#else
	char	buf[1024 + DBL_DIG * 2];
	sprintf( buf , "(move %.*f %.*f)\n" ,
		 DBL_DIG , x , DBL_DIG , y );

	return( buf );
#endif
}


string  SServer_Message_Translator::dash_command( double  power )
{
#ifndef LIB_MEMORY
	strstream	send_string;
	send_string.precision( DBL_DIG );

	send_string  <<  "(dash " << power << ")" << endl  << ends;

	return( send_string );
#else
	char	buf[1024 + DBL_DIG];
	sprintf( buf , "(dash %.*f)\n" , DBL_DIG , power );

	return( buf );
#endif
}


string  SServer_Message_Translator::kick_command( double  power ,
						  const Angle &  direction )
{
#ifndef LIB_MEMORY
	strstream	send_string;
	send_string.precision( DBL_DIG );

	send_string  <<  "(kick " << power << " " << direction.degree() << ")"
		     <<  endl  << ends;

	return( send_string );
#else
	char	buf[1024 + DBL_DIG * 2];

	sprintf( buf , "(kick %.*f %.*f)\n" ,
		 DBL_DIG , power , DBL_DIG , direction.degree() );

	return( buf );
#endif
}

string  SServer_Message_Translator::turn_command( const Angle &  moment )
{
#ifndef LIB_MEMORY
	strstream	send_string;
	send_string.precision( DBL_DIG );

	send_string  << "(turn " << moment.degree() << ")" << endl  << ends;

	return( send_string );
#else
	char	buf[1024 + DBL_DIG];

	sprintf( buf , "(turn %.*f)\n" , DBL_DIG , moment.degree() );

	return( buf );
#endif
}


string  SServer_Message_Translator::say_command( const string &  message )
{
	// no check for message here.
	// message must be consist of [a-zA-Z().+-*/?<>_].
	string	send_string = static_cast<string>("(say ") + message + ")\n";

	return( send_string );
}


string  SServer_Message_Translator::catch_command( const Angle &  direction )
{
#ifndef LIB_MEMORY
	strstream	send_string;

	send_string  <<  "(catch " << direction.degree() << ")" << endl
		     << ends;

	return( send_string );
#else
	char	buf[1024 + DBL_DIG];

	sprintf( buf , "(catch %.*f)\n" , DBL_DIG , direction.degree() );

	return( buf );
#endif
}


string  SServer_Message_Translator::change_view_command(
						View_Width  width ,
						View_Quality  quality )
{
	string	width_string;
	string	quality_string;

	switch( width )
	{
		case View_Width::Narrow:	width_string = "narrow"; break;
		case View_Width::Normal:	width_string = "normal"; break;
		case View_Width::Wide:		width_string = "wide"  ; break;
	}

	switch( quality )
	{
		case View_Quality::High:	quality_string = "high"; break;
		case View_Quality::Low:		quality_string = "low" ; break;
	}

	string	send_string = static_cast<string>("(change_view ")
				+ width_string + " " + quality_string + ")\n";

	return( send_string );
}


string  SServer_Message_Translator::sense_body_command()
{
	return( "(sense_body)" );
}


string  SServer_Message_Translator::turn_neck_command(
						const Angle &  direction )
{
#ifndef LIB_MEMORY
	strstream	send_string;

	send_string  <<  "(turn_neck "
		     <<  direction.degree() << ")" << endl  << ends;

	return( send_string );
#else
	char	buf[1024 + DBL_DIG];

	sprintf( buf , "(turn_neck %.*f)\n" , DBL_DIG , direction.degree() );

	return( buf );
#endif
}


#if 1
//
// Coach Commands
//
string  SServer_Message_Translator::look_command()
{
	return( "(look)" );
}

string  SServer_Message_Translator::check_ball_command()
{
	return( "(check_ball)" );
}

string  SServer_Message_Translator::ear_command( bool  on_off )
{
	string	send_string = static_cast<string>("(err ")
		+ (on_off ? "on" : "off") + ")\n";

	return( send_string );
}

#if 0
string  SServer_Message_Translator::change_mode_command( Play_Mode  mode )
{
	string	send_string = (string)"(change_mode "
		+ play_mode_to_string( mode , our_side ) + ")\n";

	return( send_string );
}
#endif
#endif

//
// Monitor Commands
//
string  SServer_Message_Translator::dispinit_command()
{
	return( "(dispinit)" );
}

string  SServer_Message_Translator::dispstart_command()
{
	return( "(dispstart)" );
}

string  SServer_Message_Translator::dispdiscard_command( S_Side_LR  side ,
							 int  player_number )
{
	int	side_number;

	switch( side )
	{
	case S_Side_LR::Left_Side:
		side_number = 1;
		break;


	case S_Side_LR::Right_Side:
		side_number = -1;
		break;

	case S_Side_LR::Unknown:
	default:
		return( "" );
		break;
	}

	char	buf[ 1024 + (sizeof(int) * CHAR_BIT + 1) * 2 ];

	sprintf( buf , "(dispdiscard %d %d)" , side_number , player_number );

	return( buf );
}

string  SServer_Message_Translator::dispfoul_command( double  x ,
						      double  y ,
						      S_Side_LR  side )
{
	int	side_number;

	switch( side )
	{
	case S_Side_LR::Left_Side:
		side_number = 1;
		break;

	case S_Side_LR::Right_Side:
		side_number = -1;
		break;

	case S_Side_LR::Unknown:
		side_number = 0;
		break;

	default:
		return( "" );
		break;
	}

	char	buf[ 1024 + (sizeof(int) * CHAR_BIT + 1) * 2 ];

	sprintf( buf , "(dispfoul %d %d %d)" ,
		 double_to_nearest_int( x * SHOWINFO_SCALE ) ,
		 double_to_nearest_int( y * SHOWINFO_SCALE ) ,
		 side_number );

	return( buf );
}




void   SServer_Message_Translator::parse_init_message( Game_Info *  g_info ,
						       const  string &  mes )
{
	char			side;
	int			player_number;
	ref_count_ptr<char>	play_mode;
	try
	{
		play_mode = new char[ SSERVER_MAX_MESSAGE_LENGTH + 1 ];
	}
	catch( ... )
	{
		cerr << "Can't allocate memory" << endl;
		throw;
	}

	if ( sscanf( mes.c_str() , "(init %c %d %[a-z_])" ,
		     &side , &player_number , play_mode.get() ) != 3
	  || ! (side == 'l' || 'r') )
	{
		cerr << "\"" << mes << "\" : ";
		cerr << "Unexpected initial message from server." << endl;

		g_info -> our_side         = S_Side_LR::Unknown;
		g_info -> my_player_number = -1;
		g_info -> play_mode        = Play_Mode::Unknown;
	}
	else
	{
		g_info -> our_side
			= ((side == 'l') ?
			   S_Side_LR::Left_Side : S_Side_LR::Right_Side);
		g_info -> my_player_number = player_number;
		g_info -> play_mode = string_to_play_mode(
						  play_mode.get() ,
						  g_info -> our_side );
	}
}


void   SServer_Message_Translator::
		parse_reconnect_message( Game_Info *  g_info ,
					 const  string &  mes ,
					 int  player_number )
{
	char		side;
	ref_count_ptr<char>	play_mode;
	try
	{
		play_mode = new char[ SSERVER_MAX_MESSAGE_LENGTH + 1 ];
	}
	catch( ... )
	{
		cerr << "Can't allocate memory" << endl;
		throw;
	}

	if ( sscanf( mes.c_str() , "(reconnect %c %[a-z_])" ,
		     &side , play_mode.get() ) != 2
	  || ! (side == 'l' || 'r') )
	{
		cerr << "\"" << mes << "\" : ";
		cerr << "Unexpected reconnect message from server." << endl;

		g_info -> our_side         = S_Side_LR::Unknown;
		g_info -> my_player_number = -1;
		g_info -> play_mode        = Play_Mode::Unknown;
	}
	else
	{
		g_info -> our_side
			= ((side == 'l') ?
			   S_Side_LR::Left_Side : S_Side_LR::Right_Side);
		g_info -> my_player_number = player_number;
		g_info -> play_mode = string_to_play_mode(
						  play_mode.get() ,
						  g_info -> our_side );
	}
}


Play_Mode  SServer_Message_Translator::string_to_play_mode(
						   const string &  mode ,
						   S_Side_LR  our_side )
{
	if ( mode  ==  "before_kick_off" )
	{
		return( Play_Mode::Before_Kick_Off );
	}
	else if ( mode  ==  "play_on" )
	{
		return( Play_Mode::Play_On );
	}
	else if ( mode  ==  "time_over" )
	{
		return( Play_Mode::Time_Over );
	}


	string	l_or_r;
	string	mode_base;

	if ( mode.length() < 2
	 ||  our_side == S_Side_LR::Unknown )
	{
		return( Play_Mode::Unknown );
	}

	l_or_r    = mode.substr( mode.length() - 2 , 2 );
	mode_base = mode.substr( 0 , mode.length() - 2 );

	if ( ! (l_or_r == "_l" || l_or_r == "_r" ) )
	{
		return( Play_Mode::Unknown );
	}

	S_Side	side;
	if ( (l_or_r == "_l" && our_side == S_Side_LR::Left_Side)
	  || (l_or_r == "_r" && our_side == S_Side_LR::Right_Side) )
	{
		side = S_Side::Our_Side;
	}
	else
	{
		side = S_Side::Opponent_Side;
	}

	if ( mode_base == "kick_off" )
	{
		if ( side == S_Side::Our_Side )
		{
			return( Play_Mode::Our_Kick_Off );
		}
		else
		{
			return( Play_Mode::Opponent_Kick_Off );
		}
	}
	else if ( mode_base == "kick_in" )
	{
		if ( side == S_Side::Our_Side )
		{
			return( Play_Mode::Our_Kick_In );
		}
		else
		{
			return( Play_Mode::Opponent_Kick_In );
		}
	}
	else if ( mode_base == "free_kick" )
	{
		if ( side == S_Side::Our_Side )
		{
			return( Play_Mode::Our_Free_Kick );
		}
		else
		{
			return( Play_Mode::Opponent_Free_Kick );
		}
	}
	else if ( mode_base == "corner_kick" )
	{
		if ( side == S_Side::Our_Side )
		{
			return( Play_Mode::Our_Corner_Kick );
		}
		else
		{
			return( Play_Mode::Opponent_Corner_Kick );
		}
	}
	else if ( mode_base == "goal_kick" )
	{
		if ( side == S_Side::Our_Side )
		{
			return( Play_Mode::Our_Goal_Kick );
		}
		else
		{
			return( Play_Mode::Our_Goal );
		}
	}
	else if ( mode_base == "goal_kick" )
	{
		if ( side == S_Side::Our_Side )
		{
			return( Play_Mode::Our_Goal_Kick );
		}
		else
		{
			return( Play_Mode::Opponent_Goal_Kick );
		}
	}
	else if ( mode_base == "goal" )
	{
		if ( side == S_Side::Our_Side )
		{
			return( Play_Mode::Our_Goal );
		}
		else
		{
			return( Play_Mode::Opponent_Goal );
		}
	}
	else
	{
		return( Play_Mode::Unknown );
	}
}


void   SServer_Message_Translator::parse_message(
					Information_from_Server *  info ,
					const string &  mes ,
					S_Side_LR  our_side ,
					const string &  team_name )
{
	info -> reset_info();
	info -> set_time( -1 );
	info -> set_raw_message( mes );

	Information_from_Server	illegal_info;
	illegal_info.reset_info();
	illegal_info.set_time( -1 );
	illegal_info.set_raw_message( mes );

	if ( mes.length() == 0 )
	{
		info -> set_no_info();
		return;
	}

#if 0
	// TTT
	cout  <<  "info["  <<  mes  <<  "]"  <<  endl;
#endif

	if ( strncmp( mes.c_str() ,"(hear " ,
		      strlen("(hear ") ) == 0 )
	{
		// analyze audio and whistle info.
		if ( ! analyze_audio_info_brief( info , mes , our_side ) )
		{
			info -> reset_info();
		}

		return;
	}
#ifndef LISP_LEX_PARSE
	else if ( strncmp( mes.c_str() ,"(sense_body " ,
			   strlen("(sense_body ") ) == 0 )
	{
		// analyze body info.
		if ( ! analyze_body_info_brief( info , mes ) )
		{
			info -> reset_info();
		}

		return;
	}
	else if ( strncmp( mes.c_str() ,"(see " ,
			   strlen("(see ") ) == 0 )
	{
		// analyze sight info.
		if ( ! analyze_sight_info_brief( info , mes ,
						 our_side , team_name ) )
		{
			info -> reset_info();
		}

		return;
	}
#endif


	Lisp_Lexical_Analyser	lisp_lex;
	if ( ! lisp_lex.analyze( mes ) )
	{
		*info = illegal_info;
		return;
	}
	Lisp_Lexical_Object	input = lisp_lex.result();

	// Make sure each input format is this.
	//	(% % ...)
	// % : symbol
	if ( ! (   input.list.size() == 1
		&& input.list[0].type == Lisp_Lexical_Object::List
		&& input.list[0].has_right_paren == true
		&& input.list[0].list.size() >= 2
		&& input.list[0].list[0].type == Lisp_Lexical_Object::Symbol
		&& input.list[0].list[1].type == Lisp_Lexical_Object::Symbol) )
	{
		return;
	}

	int	info_time;
	if ( input.list[0].list[0].symbol == "error" )
	{
		analyze_error_info( info , input.list[0] );
		return;
	}
	else if ( ! str_to_int( &info_time , input.list[0].list[1].symbol ) )
	{
		*info = illegal_info;
		return;
	}

	info -> set_time( info_time );
	illegal_info.set_time( info_time );

	string	info_type = input.list[0].list[0].symbol;
#ifdef LISP_LEX_PARSE
	if ( info_type == "see" )
	{
		// analyze sight info.
		analyze_sight_info( info , input.list[0] ,
				    our_side , team_name );
	}
#else
	if ( 0 )
	{
	}
#endif
#ifdef LISP_LEX_PARSE
	else if ( info_type == "sense_body" )
	{
		// analyze body info.
		analyze_body_info( info , input.list[0] );
	}
#endif
	else if ( info_type == "debug" )
	{
		// analyze debug info.
		analyze_debug_info( info , input.list[0] );
	}
	else
	{
		*info = illegal_info;
	}
}


#ifdef LISP_LEX_PARSE
// only for SServer_Message_Translator::analyze_sight_info()
bool   SServer_Message_Translator::analyze_sight_info_check_format(
					   const Lisp_Lexical_Object &  obj )
{
	// Make sure each input entry's format is this.
	//	     ((...) *)
	//	  || ((...) * *)
	//	  || ((...) * * * *)
	//	  || ((...) * * * * *)
	//	  || ((...) * * * * * * *)
	if ( obj.type != Lisp_Lexical_Object::List
	 ||   (    obj.list.size() != 2
	        && obj.list.size() != 3
	        && obj.list.size() != 5
	        && obj.list.size() != 6
	        && obj.list.size() != 7 )
	 ||  obj.list[0].type != Lisp_Lexical_Object::List )
	{
		return( false );
	}

	// Make sure each input entry's format is this.
	//	     ((% ...) %)
	//	  || ((% ...) % %)
	//	  || ((% ...) % % % %)
	//	  || ((% ...) % % % % %)
	//	  || ((% ...) % % % % % % %)
	for( unsigned int  i = 0  ;  i  < obj.list[0].list.size()  ;  i ++ )
	{
		if ( obj.list[0].list[i].type
		     != Lisp_Lexical_Object::Symbol )
		{
			return( false );
		}
	}

	// Make sure each input entry's format is this.
	//	     ((% ...) %)
	//	  || ((% ...) % %)
	//	  || ((% ...) % % % %)
	//	  || ((% ...) % % % % %)
	//	  || ((% ...) % % % % % % %)
	for( unsigned int  i = 1  ;  i  < obj.list.size()  ;  i ++ )
	{
		if ( obj.list[i].type != Lisp_Lexical_Object::Symbol )
		{
			return( false );
		}
	}

	return( true );
}

// only for SServer_Message_Translator::analyze_sight_info()
bool   SServer_Message_Translator::analyze_sight_info_get_relative(
			SObject_Locational_Info_from_Server *  relative ,
			const Lisp_Lexical_Object &  obj )
{
	//
	// get locational information
	//
	relative -> have_distance       = false;
	relative -> have_direction      = false;
	relative -> have_d_distance     = false;
	relative -> have_d_direction    = false;
	relative -> have_body_direction = false;
	relative -> have_face_direction = false;

	relative -> distance       = 0.0;
	relative -> direction      = Radian(0.0);
	relative -> d_distance     = 0.0;
	relative -> d_direction    = Radian(0.0);
	relative -> body_direction = Radian(0.0);
	relative -> face_direction = Radian(0.0);


	if ( obj.list.size() >= 8 )
	{
		return( false );
	}

	if ( obj.list.size() >= 7 )
	{
		relative -> have_face_direction = true;
		if ( ! server_str_to_dir( &(relative -> face_direction) ,
					  obj.list[6].symbol ) )
		{
			return( false );
		}
	}

	if ( obj.list.size() >= 6 )
	{
		relative -> have_body_direction = true;
		if ( ! server_str_to_dir( &(relative -> body_direction) ,
					  obj.list[5].symbol ) )
		{
			return( false );
		}
	}

	if ( obj.list.size() >= 5 )
	{
		relative -> have_d_direction = true;
		relative -> have_d_distance  = true;

		if ( ! server_str_to_dir( &(relative -> d_direction) ,
					  obj.list[4].symbol )
		  || ! str_to_real( &(relative -> d_distance) ,
				    obj.list[3].symbol ) )
		{
			return( false );
		}
	}

	if ( obj.list.size() >= 3 )
	{
		relative -> have_direction = true;
		relative -> have_distance  = true;

		if ( ! server_str_to_dir( &(relative -> direction) ,
					  obj.list[2].symbol )
		  || ! str_to_real( &(relative -> distance) ,
				    obj.list[1].symbol ) )
		{
			return( false );
		}
	}
	else // if ( obj.list.size() == 2 )
	{
		relative -> have_direction = true;

		if ( ! server_str_to_dir( &relative -> direction ,
					  obj.list[1].symbol ) )
		{
			return( false );
		}
	}

	return( true );
}


#include  "fixed_sobject_location.h"
void   SServer_Message_Translator::analyze_sight_info(
					    Information_from_Server * info ,
					    Lisp_Lexical_Object & input ,
					    S_Side_LR  our_side ,
					    const string &  team_name )
{
	static	Fixed_SObject_Location_Translator	obj_to_location;

	// Make sure input format is this.
	//	(* * ...)
	if ( input.list.size()  <  2 )
	{
		info -> reset_info();
		return;
	}


	ref_count_ptr<Sight_Info_from_Server>
		sight_info( new Sight_Info_from_Server );

	string	quoted_team_name = string("\"") + team_name + "\"";

	for ( unsigned int  i = 2  ;  i < input.list.size()  ;  i ++ )
	{
		Lisp_Lexical_Object &	obj = input.list[i];

		if ( ! analyze_sight_info_check_format( obj ) )
		{
			info -> reset_info();
			return;
		}

		SObject_Locational_Info_from_Server	relative;
		if ( ! analyze_sight_info_get_relative( &relative , obj ) )
		{
			info -> reset_info();
			return;
		}

		//
		// Get object identification and set to Sight_Info_from_Server
		//

		Lisp_Lexical_Object &	obj_ident = obj.list[0];
		string	obj_type = obj_ident.list[0].symbol;

		if ( obj_type == "f"    || obj_type == "F"
		  || obj_type == "flag" || obj_type == "Flag" )
		{
			if ( ! (   (2 <= obj_ident.list.size()
				    &&   obj_ident.list.size() <= 4)
			        || (obj_type[0] == 'F'
				    && obj_ident.list.size() == 1) ) )
			{
				info -> reset_info();
				return;
			}

			Field_Marker_Info_from_Server	flag_info;
			flag_info.relative = relative;
			flag_info.relative.in_sight = (obj_type[0] == 'f');
			flag_info.entity.marker_flag = true;

			flag_info.entity.location_known
				= obj_to_location.get_location(
				      &flag_info.entity.location ,
				      obj_ident , our_side );

			sight_info -> field_marker.push_back( flag_info );
		}

		else if ( obj_type == "p"      || obj_type == "P"
		       || obj_type == "player" || obj_type == "Player" )
		{
			Player_Info_from_Server	player_info;
			player_info.relative = relative;
			player_info.relative.in_sight = (obj_type[0] == 'p');

			if ( obj_type[0] == 'p' )
			{
				if ( ! (obj_ident.list.size() <= 4) )
				{
					info -> reset_info();
					return;
				}

				if ( obj_ident.list.size() < 2 )
				{
					player_info.entity.side
						= S_Side::Unknown;
				}
				else if ( obj_ident.list[1].symbol
						    == quoted_team_name
				       || obj_ident.list[1].symbol
						    == team_name )
				{
					player_info.entity.side
						= S_Side::Our_Side;
				}
				else
				{
					player_info.entity.side
						= S_Side::Opponent_Side;
				}

				if ( obj_ident.list.size() < 3 )
				{
					player_info.entity.player_number = -1;

					player_info.have_goalie_info = false;
					player_info.goalie = false;
				}
				else
				{
					str_to_int(
					   &player_info.entity.player_number ,
					   obj_ident.list[2].symbol );

					if (! (1 <= player_info.entity
						     .player_number
					        &&  player_info.entity
						     .player_number
						<= MAX_PLAYER) )
					{
						info -> reset_info();
						return;
					}

					player_info.entity.have_goalie_info
						= true;

					if ( obj_ident.list.size() >= 4 )
					{
						if ( obj_ident.list[3].symbol
						     != "goalie" )
						{
							info -> reset_info();
							return;
						}
						else
						{
							player_info.goalie
								= true;
						}
					}
					else
					{
						player_info.goalie = false;
					}
				}
			}
			else // if ( obj_type == "P" || obj_type == "Player" )
			{
				if ( obj_ident.list.size() != 1 )
				{
					info -> reset_info();
					return;
				}

				player_info.entity.side = S_Side::Unknown;
				player_info.entity.player_number = -1;
			}

			sight_info -> player.push_back( player_info );
		}
		else if ( obj_type == "b"     ||  obj_type == "B"
		       || obj_type == "ball"  ||  obj_type == "Ball" )
		{
			if ( obj_ident.list.size() != 1 )
			{
				info -> reset_info();
				return;
			}

			Ball_Info_from_Server	ball_info;
			ball_info.relative = relative;
			ball_info.relative.in_sight = (obj_type[0] == 'b');

			sight_info -> ball.push_back( ball_info );
		}
		else if ( obj_type == "g"    || obj_type == "G"
		       || obj_type == "goal" || obj_type == "Goal" )
		{
			Field_Marker_Info_from_Server	goal_info;
			goal_info.relative = relative;
			goal_info.relative.in_sight = (obj_type[0] == 'g');

			goal_info.entity.marker_flag = false;

			if ( obj_type[0] == 'g' )
			{
				const string	side_str
						  = obj_ident.list[1].symbol;
				if ( ! ( obj_ident.list.size() == 2
				      && (side_str == "l"
				       || side_str == "r" ) ) )
				{
					info -> reset_info();
					return;
				}

				goal_info.entity.location_known
					= obj_to_location.get_location(
						&goal_info.entity.location ,
						obj_ident , our_side );
			}
			else // if ( obj_type == "G" || obj_type == "Goal" )
			{
				if ( ! (obj_ident.list.size() == 1) )
				{
					info -> reset_info();
					return;
				}

				goal_info.entity.location_known = false;
				goal_info.entity.location.set( D2_Vector::XY ,
							       0.0 , 0.0 );
			}

			sight_info -> field_marker.push_back( goal_info );
		}
		else if ( obj_type == "l" || obj_type == "line" )
		{
			if ( obj_ident.list.size() != 2 )
			{
				info -> reset_info();
				return;
			}

			Line_Info_from_Server	line_info;
			line_info.relative = relative;
			line_info.relative.in_sight = true;

			const string	ln_str = obj_ident.list[1].symbol;

			if ( (ln_str == "l"
				  && our_side == S_Side_LR::Left_Side)
			  || (ln_str == "r"
				  && our_side == S_Side_LR::Right_Side) )
			{
				line_info.entity.which_line
				 = SObject_Line_Identifier::Our_Goal_Line;
			}
			else if ( (ln_str == "l"
				       && our_side == S_Side_LR::Right_Side)
			       || (ln_str == "r"
				       && our_side == S_Side_LR::Left_Side) )
			{
				line_info.entity.which_line
				 = SObject_Line_Identifier::Opponent_Goal_Line;
			}
			else if ( (ln_str == "b"
				       && our_side == S_Side_LR::Left_Side)
			       || (ln_str == "t"
				       && our_side == S_Side_LR::Right_Side) )
			{
				line_info.entity.which_line
				 = SObject_Line_Identifier::Left_Wing_Line;
			}
			else if ( (ln_str == "b"
				       && our_side == S_Side_LR::Right_Side)
			       || (ln_str == "t"
				       && our_side == S_Side_LR::Left_Side) )
			{
				line_info.entity.which_line
				 = SObject_Line_Identifier::Right_Wing_Line;
			}
			else
			{
				info -> reset_info();
				return;
			}

			sight_info -> line.push_back( line_info );
		}
		else
		{
			info -> reset_info();
			return;
		}
	}

	info -> set_sight_info( sight_info );
}
#endif

#ifndef LISP_LEX_PARSE
// XXX
//   Now, the follow code is almost same as analyze_sight_info*
//   But this will be faster in the future.

// only for SServer_Message_Translator::analyze_sight_info_brief()

#include  "fixed_sobject_location.h"
bool   SServer_Message_Translator::analyze_sight_info_brief_get_obj_info(
		    const ref_count_ptr<Sight_Info_from_Server> & sight_info ,
		    int  obj_ident_size ,
		    char **  obj_ident ,
		    const SObject_Locational_Info_from_Server &  relative ,
		    S_Side_LR  our_side ,
		    const string &  team_name )
{
	static	Fixed_SObject_Location_Translator	obj_to_location;

	if ( obj_ident_size <= 0 )
	{
		return( false );
	}

	const string	obj_type( obj_ident[0] );

	string	quoted_team_name = string("\"") + team_name + "\"";

	if ( obj_type == "f"    || obj_type == "F"
	  || obj_type == "flag" || obj_type == "Flag" )
	{
		if ( ! (    (2 <= obj_ident_size &&  obj_ident_size <= 4)
			 || (obj_type[0] == 'F' && obj_ident_size == 1)  ) )
		{
			return( false );
		}

		Field_Marker_Info_from_Server	marker_info;
		marker_info.relative = relative;
		marker_info.relative.in_sight = (obj_type[0] == 'f');
		marker_info.entity.location_known
		 = obj_to_location.get_location( &marker_info.entity.location ,
						 obj_ident_size , obj_ident ,
						 our_side );

		marker_info.entity.marker_flag = true;
		sight_info -> field_marker.push_back( marker_info );
	}
	else if ( obj_type == "p"      || obj_type == "P"
	       || obj_type == "player" || obj_type == "Player" )
	{
		Player_Info_from_Server	player_info;
		player_info.relative = relative;
		player_info.relative.in_sight = (obj_type[0] == 'p');

		if ( obj_type[0] == 'p' )
		{
			if ( ! (obj_ident_size <= 4) )
			{
				return( false );
			}

			if ( obj_ident_size < 2 )
			{
				player_info.entity.side = S_Side::Unknown;
			}
			else if ( obj_ident[1] == quoted_team_name
			       || obj_ident[1] == team_name )
			{
				player_info.entity.side = S_Side::Our_Side;
			}
			else
			{
				player_info.entity.side
					= S_Side::Opponent_Side;
			}

			if ( obj_ident_size < 3 )
			{
				player_info.entity.player_number = -1;

				player_info.have_goalie_info = false;
				player_info.goalie = false;
			}
			else
			{
				str_to_int( &player_info.entity.player_number ,
					    obj_ident[2] );

				if (! (1 <= player_info.entity.player_number
				       &&  player_info.entity.player_number
				       <= MAX_PLAYER) )
				{
					return( false );
				}

				player_info.have_goalie_info = true;

				if ( obj_ident_size >= 4 )
				{
					if ( strcmp( obj_ident[3] ,
						     "goalie" ) != 0 )
					{
						return( false );
					}
					else
					{
						player_info.goalie = true;
					}
				}
				else
				{
					player_info.goalie = false;
				}
			}
		}
		else // if ( obj_type == "P" || obj_type == "Player" )
		{
			if ( obj_ident_size != 1 )
			{
				return( false );
			}

			player_info.entity.side = S_Side::Unknown;
			player_info.entity.player_number = -1;
		}

		sight_info -> player.push_back( player_info );
	}
	else if ( obj_type == "b"     ||  obj_type == "B"
	       || obj_type == "ball"  ||  obj_type == "Ball" )
	{
		if ( obj_ident_size != 1 )
		{
			return( false );
		}

		Ball_Info_from_Server	ball_info;
		ball_info.relative = relative;
		ball_info.relative.in_sight = (obj_type[0] == 'b');

		sight_info -> ball.push_back( ball_info );
	}
	else if ( obj_type == "g"    || obj_type == "G"
	       || obj_type == "goal" || obj_type == "Goal" )
	{
		Field_Marker_Info_from_Server	marker_info;
		marker_info.relative = relative;
		marker_info.relative.in_sight = (obj_type[0] == 'g');

		if ( obj_type[0] == 'g' )
		{
			const string	side_str = obj_ident[1];
			if ( ! ( obj_ident_size == 2
				 && (side_str == "l"
				     || side_str == "r" ) ) )
			{
				return( false );
			}

			marker_info.entity.location_known
				= obj_to_location.get_location(
					     &marker_info.entity.location ,
					     obj_ident_size , obj_ident ,
					     our_side );
		}
		else // if ( obj_type == "G" || obj_type == "Goal" )
		{
			if ( ! (obj_ident_size == 1) )
			{
				return( false );
			}

			marker_info.entity.location_known = false;
			marker_info.entity.location.set( D2_Vector::XY ,
							 0.0 , 0.0 );
		}
		marker_info.entity.marker_flag = false;
		sight_info -> field_marker.push_back( marker_info );
	}
	else if ( obj_type == "l" || obj_type == "line" )
	{
		if ( obj_ident_size != 2 )
		{
			return( false );
		}

		Line_Info_from_Server	line_info;
		line_info.relative = relative;
		line_info.relative.in_sight = true;

		const string	ln_str = obj_ident[1];

		if ( (ln_str == "l"
		      && our_side == S_Side_LR::Left_Side)
		     || (ln_str == "r"
			 && our_side == S_Side_LR::Right_Side) )
		{
			line_info.entity.which_line
				= SObject_Line_Identifier::Our_Goal_Line;
		}
		else if ( (ln_str == "l"
			   && our_side == S_Side_LR::Right_Side)
			  || (ln_str == "r"
			      && our_side == S_Side_LR::Left_Side) )
		{
			line_info.entity.which_line
				= SObject_Line_Identifier::Opponent_Goal_Line;
		}
		else if ( (ln_str == "b"
			   && our_side == S_Side_LR::Left_Side)
			  || (ln_str == "t"
			      && our_side == S_Side_LR::Right_Side) )
		{
			line_info.entity.which_line
				= SObject_Line_Identifier::Left_Wing_Line;
		}
		else if ( (ln_str == "b"
			   && our_side == S_Side_LR::Right_Side)
			  || (ln_str == "t"
			      && our_side == S_Side_LR::Left_Side) )
		{
			line_info.entity.which_line
				= SObject_Line_Identifier::Right_Wing_Line;
		}
		else
		{
			return( false );
		}

		sight_info -> line.push_back( line_info );
	}
	else
	{
		return( false );
	}

	return( true );
}


// XXX
// only for SServer_Message_Translator::analyze_sight_info_brief()
bool   SServer_Message_Translator::analyze_sight_info_brief_get_relative(
		 SObject_Locational_Info_from_Server *  relative ,
		 int  n_data ,  double  data[] )
{
	//
	// get locational information
	//
	relative -> have_distance       = false;
	relative -> have_direction      = false;
	relative -> have_d_distance     = false;
	relative -> have_d_direction    = false;
	relative -> have_body_direction = false;
	relative -> have_face_direction = false;

	relative -> distance       = 0.0;
	relative -> direction      = Radian(0.0);
	relative -> d_distance     = 0.0;
	relative -> d_direction    = Radian(0.0);
	relative -> body_direction = Radian(0.0);
	relative -> face_direction = Radian(0.0);


	if ( n_data >= 7 )
	{
		return( false );
	}

	if ( n_data >= 6 )
	{
		relative -> have_face_direction = true;
		relative -> face_direction = Degree( data[5] );
	}

	if ( n_data >= 5 )
	{
		relative -> have_body_direction = true;
		relative -> body_direction     = Degree( data[4] );
	}

	if ( n_data >= 4 )
	{
		relative -> have_d_direction = true;
		relative -> have_d_distance  = true;

		relative -> d_direction = Degree( data[3] );
		relative -> d_distance  = data[2];
	}

	if ( n_data >= 2 )
	{
		relative -> have_direction = true;
		relative -> have_distance  = true;

		relative -> direction = Degree( data[1] );
		relative -> distance = data[0];
	}
	else // if ( n_data == 1 )
	{
		relative -> have_direction = true;

		relative -> direction = Degree( data[0] );
	}

	return( true );
}

bool   SServer_Message_Translator::analyze_sight_info_brief(
				    Information_from_Server *  info ,
				    const string &  mes ,
				    S_Side_LR  our_side ,
				    const string &  team_name )
{
	static	Fixed_SObject_Location_Translator	obj_to_location;
	ref_count_ptr<Sight_Info_from_Server>
		sight( new Sight_Info_from_Server );

	int	info_time;
	char	next_char;
	int	start_point;

	if ( sscanf( mes.c_str() ,
		     "(see %d %n%c" ,
		     &info_time , &start_point , &next_char ) != 2 )
	{
		return( false );
	}

	info -> set_time( info_time );

	if ( next_char == ')' )
	{
		info -> set_sight_info( sight );

		return( true );
	}

	if ( next_char != '(' )
	{
		return( false );
	}


	const char *	ptr = mes.c_str() + start_point;

	for(;;)
	{
		// XXX: magic number 256
		char	oid_entity[4][256 + 1];
		char *	oid[4];
		int	oid_n[4];
		int	oid_n_match;

		for ( size_t  i = 0  ;  i < 4  ;  i ++ )
		{
			oid[i] = oid_entity[i];
		}


		// XXX: magic number 256
		oid_n_match = sscanf( ptr ,
				      " ((%256[^() ] %n%256[^() ] %n"
				         "%256[^() ] %n%256[^() ] %n" ,
				      oid[0] , oid_n + 0 ,
				      oid[1] , oid_n + 1 ,
				      oid[2] , oid_n + 2 ,
				      oid[3] , oid_n + 3 );

		if ( oid_n_match <= 0 )
		{
			return( false );
		}

		if ( *(ptr += oid_n[oid_n_match - 1]) != ')' )
		{
			return( false );
		}

		ptr ++;


		double	rel[6];
		int	rel_n[6];
		int	rel_n_match;

		rel_n_match = sscanf( ptr ,
				      "%lf%n%lf%n%lf%n%lf%n%lf%n%lf%n" ,
				      &rel[0] , &rel_n[0] ,
				      &rel[1] , &rel_n[1] ,
				      &rel[2] , &rel_n[2] ,
				      &rel[3] , &rel_n[3] ,
				      &rel[4] , &rel_n[4] ,
				      &rel[5] , &rel_n[5] );

		if ( rel_n_match <= 0 )
		{
			return( false );
		}

		SObject_Locational_Info_from_Server	relative;

		if ( ! analyze_sight_info_brief_get_relative( &relative ,
							      rel_n_match ,
							      rel ) )
		{
			return( false );
		}


		if ( *(ptr += rel_n[rel_n_match - 1]) != ')' )
		{
			return( false );
		}

		ptr ++;

		if ( ! analyze_sight_info_brief_get_obj_info(
							sight ,
							oid_n_match ,
							oid ,
							relative ,
							our_side ,
							team_name ) )
		{
			return( false );
		}

		if ( *ptr == ')' )
		{
			ptr ++;

			if ( strcmp( ptr , "\n" ) != 0
			 &&  strcmp( ptr , "" )   != 0 )
			{
				return( false );
			}
			else
			{
				break;
			}
		}
	}

	info -> set_sight_info( sight );

	return( true );
}
#endif



bool   SServer_Message_Translator::analyze_audio_info_brief(
					    Information_from_Server * info ,
					    const string &  mes ,
					    S_Side_LR  our_side )
{
	int	info_time;

	ref_count_ptr<char>	from;
	from = new char[SSERVER_MAX_MESSAGE_LENGTH + 1];

	int	n;

	{
		static	bool	initialized = false;
		static	char	format[1024
				       + (sizeof(int) * CHAR_BIT + 1) * 2];

		if ( ! initialized )
		{
			sprintf( format ,
				 "(hear %%d %%%ds %%n" ,
				 static_cast<int>(SSERVER_MAX_MESSAGE_LENGTH)
				 );

			initialized = true;
		}

		if ( sscanf( mes.c_str() , format ,
			     &info_time , from.get() , &n ) != 2 )
		{
			return( false );
		}
	}

	info -> set_time( info_time );

	string	m( mes.c_str() + n );
	size_t	m_len = m.length();

	if ( m_len >= 1  &&  m[ m_len - 1 ] == '\n' )
	{
		m_len --;
		m.resize( m_len );
	}

	if ( m_len < 1  ||  m[ m_len - 1 ] != ')' )
	{
		return( false );
	}

	m_len --;
	m.resize( m_len );

	const string	message( m );

	if ( strcmp( from.get() , "referee" ) == 0 )
	{
		ref_count_ptr<Whistle_Info_from_Server>
			wi( new Whistle_Info_from_Server );
		wi -> type = Judgement_Type::Unknown;
		wi -> play_mode = Play_Mode::Unknown;
		wi -> score = 0;
		wi -> side = S_Side::Unknown;
		wi -> player_number = -1;

		Play_Mode	play_mode;
		play_mode = SServer_Message_Translator::string_to_play_mode(
							message , our_side );

		if ( play_mode != Play_Mode::Unknown )
		{
			wi -> type = Judgement_Type::One_of_Play_Modes;
			wi -> play_mode = play_mode;
		}
		else if ( message == "half_time" )
		{
			wi -> type = Judgement_Type::Half_Time;
		}
		else if ( message == "time_up" )
		{
			wi -> type = Judgement_Type::Time_Up;
		}
		else if ( message == "time_up_without_a_team" )
		{
			wi -> type = Judgement_Type::
				      Time_Up_Without_A_Team;
		}
		else if ( message == "time_extended" )
		{
			wi -> type = Judgement_Type::Time_Extended;
		}
		else if ( message.length() == strlen("goalie_catch_ball_?")
		       && (   message[strlen("goalie_catch_ball_")] == 'l'
			   || message[strlen("goalie_catch_ball_")] == 'r' ) )
		{
			wi -> type = Judgement_Type::Goalie_Catch_Ball;
			wi -> side
			  = lr_to_side( message[strlen("goalie_catch_ball_")] ,
					our_side );
		}
		else if ( message.length() >= strlen("goal_?_?")
		      &&  message.substr(0 , strlen("goal_")) == "goal_"
		      &&  (   message[strlen("goal_")] == 'l'
			   || message[strlen("goal_")] == 'r' )
		      &&  message[strlen("goal_") + 1] == '_' )
		{
			wi -> type = Judgement_Type::Goal;
			wi -> side = lr_to_side( message[strlen("goal_")] ,
					      our_side );
			if ( !(str_to_int( &(wi -> score) ,
					   message.substr(
						     strlen("goal_?_")) )) )
			{
				info -> reset_info();
			}
		}
		else if ( message.length() >= strlen("foul_?")
		      &&  message.substr(0 , strlen("foul_")) == "foul_"
		      &&  (message[strlen("foul_")] == 'l'
			|| message[strlen("foul_")] == 'r' ) )
		{
			wi -> type = Judgement_Type::Foul;
			wi -> side = lr_to_side( message[strlen("foul_")] ,
						 our_side );

			if ( message.length() >= strlen("foul_?_" ) )
			{
				if ( message[strlen("foul_") + 1] != '_'
				 || !(str_to_int( &(wi -> player_number) ,
					message.substr(strlen("foul_?_")) )) )
				{
					info -> reset_info();
				}
			}
			else
			{
				wi -> player_number = -1;
			}

		}
		else if ( message == "drop_ball" )
		{
			wi -> type = Judgement_Type::Drop_Ball;
		}
		else if ( message.length() >= strlen("offside_?")
		      &&  message.substr(0 , strlen("offside_")) == "offside_"
		      &&  (message[strlen("offside_")] == 'l'
			|| message[strlen("offside_")] == 'r' ) )
		{
			wi -> type = Judgement_Type::Offside;
			wi -> side = lr_to_side( message[strlen("offside_")] ,
						 our_side );
		}
		else
		{
			return( false );
		}

		info -> set_whistle_info( wi );
	}
	else
	{
		ref_count_ptr<Audio_Info_from_Server>
			au( new Audio_Info_from_Server );

		au -> message = message;

		if ( strcmp( from.get() , "self" ) == 0 )
		{
			au -> sender    = Audio_Info_from_Server::ST_Self;
			au -> direction = Radian(0.0);
		}
		else
		{
			au -> sender = Audio_Info_from_Server::ST_Player;
			if ( ! server_str_to_dir( &(au -> direction) ,
						  from.get() ) )
			{
				return( false );
			}
		}

		info -> set_audio_info( au );
	}

	return( true );
}



void   SServer_Message_Translator::analyze_body_info(
					      Information_from_Server * info ,
					      Lisp_Lexical_Object & input )
{
	//
	// Format Check
	//
	// Make sure input format is this.
	//	(* * (view_mode % %)
	//	     (stamina % %)
	//	     (speed %)
	//	     (kick %)
	//	     (dash %)
	//	     (turn %)
	//	     (say %))
	// * : list or symbol
	// % : symbol

	// start
	//
	struct  Sense_Body_Format
	{
		string		parameter;
		unsigned int	n_arguments;
	};

	static const  size_t		n_entry_ver4 = 7;
	static const  Sense_Body_Format	format_ver4[n_entry_ver4] =
	{
		{ "view_mode" , 2 },
		{ "stamina"   , 2 },
		{ "speed"     , 1 },
		{ "kick"      , 1 },
		{ "dash"      , 1 },
		{ "turn"      , 1 },
		{ "say"       , 1 }
	};

	static const  size_t		n_entry_ver5 = 9;
	static const  Sense_Body_Format	format_ver5[n_entry_ver5] =
	{
		{ "view_mode" , 2 },
		{ "stamina"   , 2 },
		{ "speed"     , 1 },
		{ "head_angle", 1 },
		{ "kick"      , 1 },
		{ "dash"      , 1 },
		{ "turn"      , 1 },
		{ "say"       , 1 },
		{ "turn_neck" , 1 }
	};

	static const  size_t		n_entry_ver6 = 9;
	static const  Sense_Body_Format	format_ver6[n_entry_ver6] =
	{
		{ "view_mode" , 2 },
		{ "stamina"   , 2 },
		{ "speed"     , 2 },
		{ "head_angle", 1 },
		{ "kick"      , 1 },
		{ "dash"      , 1 },
		{ "turn"      , 1 },
		{ "say"       , 1 },
		{ "turn_neck" , 1 }
	};

	// Make sure input format is this.
	//	(* * * * * * * * *) || (* * * * * * * * * * *)
	int	sense_body_version;
	size_t	n_entry;
	const  Sense_Body_Format *	format;
	if ( input.list.size() == (2 + n_entry_ver4) )
	{
		sense_body_version = 4;
		format  = format_ver4;
		n_entry = n_entry_ver4;
	}
	else if ( input.list.size() == (2 + n_entry_ver5)
	       && input.list[4].list.size() == 2 )
	{
		sense_body_version = 5;
		format  = format_ver5;
		n_entry = n_entry_ver5;
	}
	else if ( input.list.size() == (2 + n_entry_ver6)
	       && input.list[4].list.size() == 3 )
	{
		sense_body_version = 5;
		format  = format_ver6;
		n_entry = n_entry_ver6;
	}
	else
	{
		info -> reset_info();
		return;
	}


	// Make sure input format is this.
	//	(* * (view_mode % %)
	//	     (stamina % %)
	//	     (speed %)
	//	     (kick %)
	//	     (dash %)
	//	     (turn %)
	//	     (say %))
	for ( unsigned int  i = 0  ;  i < n_entry  ;  i ++ )
	{
		Lisp_Lexical_Object &	entry = input.list[i + 2];
		Sense_Body_Format	entry_format = format[i];

		// Make sure each input entry's format is this.
		//	     (* *) || (* * *)
		if ( entry.type  !=  Lisp_Lexical_Object::List
		 ||  entry.list.size() != entry_format.n_arguments + 1)
		{
			info -> reset_info();
			return;
		}

		// Make sure each input entry's format is this.
		//	     (% %) || (% % %)
		for ( unsigned int  x = 0  ;  x < entry_format.n_arguments  ;
		      x ++ )
		{
			if ( entry.list[x].type
			     !=  Lisp_Lexical_Object::Symbol )
			{
				info -> reset_info();
				return;
			}
		}

		// Make sure each input entry's format is this.
		//	(view_mode % %) || (stamina % %) || ...
		if ( entry.list[0].symbol != entry_format.parameter )
		{
			info -> reset_info();
			return;
		}
	}
	//
	// Test input format
	//
	// end


	// no errors.
	// now, we know input data format is valid.


	//
	// Set parameter to Body_Info_from_Server instance.
	//
	// start

	ref_count_ptr<Body_Info_from_Server>
		body( new Body_Info_from_Server );

	string	vq = input.list[2].list[1].symbol;
	if ( vq == "high" )
	{
		body -> v_quality = View_Quality::High;
	}
	else if ( vq == "low" )
	{
		body -> v_quality = View_Quality::Low;
	}
	else
	{
		info -> reset_info();
		return;
	}


	string	va = input.list[2].list[2].symbol;
	if ( va == "wide" )
	{
		body -> v_width = View_Width::Wide;
	}
	else if ( va == "normal" )
	{
		body -> v_width = View_Width::Normal;
	}
	else if ( va == "narrow" )
	{
		body -> v_width = View_Width::Narrow;
	}
	else
	{
		info -> reset_info();
		return;
	}

	if ( sense_body_version == 4 )
	{
		if ( ! str_to_real( &(body -> stamina) ,
				    input.list[3].list[1].symbol )
		  || ! str_to_real( &(body -> effort) ,
				    input.list[3].list[2].symbol )
		  || ! str_to_real( &(body -> speed) ,
				    input.list[4].list[1].symbol )
		  || ! str_to_int ( &(body -> n_kick) ,
				    input.list[5].list[1].symbol )
		  || ! str_to_int ( &(body -> n_dash) ,
				    input.list[6].list[1].symbol )
		  || ! str_to_int ( &(body -> n_turn) ,
				    input.list[7].list[1].symbol )
		  || ! str_to_int ( &(body -> n_say) ,
				    input.list[8].list[1].symbol ) )
		{
			info -> reset_info();
			return;
		}

		body -> neck_angle  = Radian(0.0);
		body -> n_turn_neck = 0;
	}
	else if ( sense_body_version == 5 )
	{
		if ( ! str_to_real( &(body -> stamina) ,
				    input.list[3].list[1].symbol )
		  || ! str_to_real( &(body -> effort) ,
				    input.list[3].list[2].symbol )
		  || ! str_to_real( &(body -> speed) ,
				    input.list[4].list[1].symbol )
		  || ! server_str_to_dir( &(body -> neck_angle) ,
					  input.list[5].list[1].symbol )
		  || ! str_to_int ( &(body -> n_kick) ,
				    input.list[6].list[1].symbol )
		  || ! str_to_int ( &(body -> n_dash) ,
				    input.list[7].list[1].symbol )
		  || ! str_to_int ( &(body -> n_turn) ,
				    input.list[8].list[1].symbol )
		  || ! str_to_int ( &(body -> n_say) ,
				    input.list[9].list[1].symbol )
		  || ! str_to_int ( &(body -> n_turn_neck) ,
				    input.list[10].list[1].symbol ) )
		{
			info -> reset_info();
			return;
		}
	}
	else // if ( sense_body_version == 6 )
	{
		if ( ! str_to_real( &(body -> stamina) ,
				    input.list[3].list[1].symbol )
		  || ! str_to_real( &(body -> effort) ,
				    input.list[3].list[2].symbol )
		  || ! str_to_real( &(body -> speed) ,
				    input.list[4].list[1].symbol )
		  || ! server_str_to_dir( &(body -> speed_angle) ,
				    input.list[4].list[2].symbol )
		  || ! server_str_to_dir( &(body -> neck_angle) ,
					  input.list[5].list[1].symbol )
		  || ! str_to_int ( &(body -> n_kick) ,
				    input.list[6].list[1].symbol )
		  || ! str_to_int ( &(body -> n_dash) ,
				    input.list[7].list[1].symbol )
		  || ! str_to_int ( &(body -> n_turn) ,
				    input.list[8].list[1].symbol )
		  || ! str_to_int ( &(body -> n_say) ,
				    input.list[9].list[1].symbol )
		  || ! str_to_int ( &(body -> n_turn_neck) ,
				    input.list[10].list[1].symbol ) )
		{
			info -> reset_info();
			return;
		}

		body -> have_speed_angle = true;
	}


	//
	// Set parameter to Body_Info_from_Server instance.
	//
	// end

	//
	// Rest is to set data that we get only.
	//
	info -> set_body_info( body );
}


bool   SServer_Message_Translator::analyze_body_info_brief(
					      Information_from_Server * info ,
					      const string &  mes )
{
	//
	// Format
	//
	//	(sense_body % (view_mode % %)
	//	              (stamina % %)
	//	              (speed %)
	//	              (kick %)
	//	              (dash %)
	//	              (turn %)
	//	              (say %))
	// * : list or symbol
	// % : symbol

	int	info_time;

	ref_count_ptr<Body_Info_from_Server>
		body( new Body_Info_from_Server );

	// XXX: magic number 256
	char	view_quality[256 + 1];
	char	view_angle[256 + 1];

	double	head_ang;
	double	speed_ang;

	// soccer server version 6
	if ( sscanf( mes.c_str() ,
		     "(sense_body %d (view_mode %256s %256s"
		     " (stamina %lf %lf)"
		     " (speed %lf %lf) (head_angle %lf)"
		     " (kick %d) (dash %d) (turn %d)"
		     " (say %d) (turn_neck %d))" ,
		     &info_time , view_quality , view_angle ,
		     &(body -> stamina) , &(body -> effort) ,
		     &(body -> speed) , &speed_ang , &head_ang ,
		     &(body -> n_kick) , &(body -> n_dash) ,
		     &(body -> n_turn) , &(body -> n_say) ,
		     &(body -> n_turn_neck) ) == 13 )
	{
		body -> neck_angle = Degree(head_ang);
		body -> speed_angle = Degree(speed_ang);
		body -> have_speed_angle = true;
	}
	// soccer server version 5
	else if ( sscanf( mes.c_str() ,
			  "(sense_body %d (view_mode %256s %256s"
			  " (stamina %lf %lf)"
			  " (speed %lf) (head_angle %lf)"
			  " (kick %d) (dash %d) (turn %d)"
			  " (say %d) (turn_neck %d))" ,
			  &info_time , view_quality , view_angle ,
			  &(body -> stamina) , &(body -> effort) ,
			  &(body -> speed) , &head_ang ,
			  &(body -> n_kick) , &(body -> n_dash) ,
			  &(body -> n_turn) , &(body -> n_say) ,
			  &(body -> n_turn_neck) ) == 12 )
	{
		body -> neck_angle = Degree(head_ang);
	}
	// soccer server version 4
	else if ( sscanf( mes.c_str() ,
			  "(sense_body %d (view_mode %256s %256s"
			  " (stamina %lf %lf)"
			  " (speed %lf)"
			  " (kick %d) (dash %d) (turn %d)"
			  " (say %d))" ,
			  &info_time , view_quality , view_angle ,
			  &(body -> stamina) , &(body -> effort) ,
			  &(body -> speed) ,
			  &(body -> n_kick) , &(body -> n_dash) ,
			  &(body -> n_turn) , &(body -> n_say) ) == 10 )
	{
		body -> neck_angle  = Radian(0.0);
		body -> n_turn_neck = 0;
	}
	else
	{
		return( false );
	}


	info -> set_time( info_time );


	if ( strcmp( view_quality , "high" ) == 0 )
	{
		body -> v_quality = View_Quality::High;
	}
	else if ( strcmp( view_quality , "low" ) )
	{
		body -> v_quality = View_Quality::Low;
	}
	else
	{
		return( false );
	}

	if ( strcmp( view_angle , "wide)" ) == 0 )
	{
		body -> v_width = View_Width::Wide;
	}
	else if ( strcmp( view_angle , "normal)" ) == 0 )
	{
		body -> v_width = View_Width::Normal;
	}
	else if ( strcmp( view_angle , "narrow)" ) == 0 )
	{
		body -> v_width = View_Width::Narrow;
	}
	else
	{
		return( false );
	}

	info -> set_body_info( body );

	return( true );
}


void   SServer_Message_Translator::analyze_error_info(
					      Information_from_Server *  info ,
					      Lisp_Lexical_Object &  input )
{
	if ( input.list.size() != 2
	  || input.list[1].type != Lisp_Lexical_Object::Symbol )
	{
		info -> reset_info();
		return;
	}

	ref_count_ptr<Error_Info_from_Server>
		err( new Error_Info_from_Server );
	err -> error_message = input.list[1].symbol;

	info -> set_error_info( err );
}


void   SServer_Message_Translator::analyze_debug_info(
					      Information_from_Server *  info ,
					      Lisp_Lexical_Object &  input )
{
	if ( ! (input.list.size() > 2) )
	{
		info -> reset_info();
		return;
	}

	ref_count_ptr<Debug_Info_from_Server>
		debug( new Debug_Info_from_Server );

	for ( size_t  i = 2  ;  i < input.list.size()  ;  i ++ )
	{
		const Lisp_Lexical_Object &		obj = input.list[i];
		const vector<Lisp_Lexical_Object> &	obj_list = obj.list;

		if ( obj.type != Lisp_Lexical_Object::List
		  || obj_list.size() == 0 )
		{
			info -> reset_info();
			return;
		}

		if ( obj_list[0].symbol == "coordinate"
		  && obj_list.size() == 3 )
		{
			double	coord_x;
			double	coord_y;

			if ( ! str_to_real( &coord_x , obj_list[1].symbol )
			  || ! str_to_real( &coord_y , obj_list[2].symbol ) )
			{
				info -> reset_info();
				return;
			}

			debug -> true_my_coordinate.set( coord_x , coord_y );
		}
		else if ( obj_list[0].symbol == "body_angle"
		       && obj_list.size() == 2 )
		{
			if ( ! server_str_to_dir(
					 &(debug -> true_my_body_angle) ,
					 obj_list[1].symbol ) )
			{
				info -> reset_info();
				return;
			}
		}
		else if ( obj_list[0].symbol == "head_angle"
		       && obj_list.size() == 2 )
		{
			if ( ! server_str_to_dir(
					 &(debug -> true_my_neck_angle) ,
					 obj_list[1].symbol ) )
			{
				info -> reset_info();
				return;
			}
		}
		else if ( obj_list[0].symbol == "stamina"
		       && obj_list.size() == 3 )
		{
			double	st;
			double	ef;

			if ( ! str_to_real( &st , obj_list[1].symbol )
			  || ! str_to_real( &ef , obj_list[2].symbol ) )
			{
				info -> reset_info();
				return;
			}

			debug -> true_my_stamina = st;
			debug -> true_my_effort  = ef;
		}
		else if ( obj_list[0].symbol == "speed"
		       && obj_list.size() == 2 )
		{
			double	sp;

			if ( ! str_to_real( &sp , obj_list[1].symbol ) )
			{
				info -> reset_info();
				return;
			}

			debug -> true_my_speed = sp;
		}
		else if ( obj_list[0].symbol == "offside"
		       && obj_list.size() == 2 )
		{
			if ( obj_list[1].symbol == "true" )
			{
				debug -> offside_position = true;
			}
			else if ( obj_list[1].symbol == "false" )
			{
				debug -> offside_position = false;
			}
			else
			{
				info -> reset_info();
				return;
			}
		}
		else
		{
			info -> reset_info();
			return;
		}
	}

	debug -> have_info = true;
	info -> set_debug_info( debug );
}




bool   SServer_Message_Translator::str_to_real( double *  num ,
						const string &  str )
{
	if ( str.find( " "  ) != string::npos
	  || str.find( "\t" ) != string::npos
	  || str.find( "\n" ) != string::npos )
	{
		return( false );
	}

	char *	c;
	double	double_num;
	double_num = strtod( str.c_str() , &c );

	if ( *c != '\0'
	 ||  double_num == HUGE_VAL )
	{
		return( false );
	}
	else
	{
		*num = double_num;

		return( true );
	}
}

bool   SServer_Message_Translator::str_to_int( int *  num ,
					       const string &  str )
{
	if ( str.find( " "  ) != string::npos
	  || str.find( "\t" ) != string::npos
	  || str.find( "\n" ) != string::npos )
	{
		return( false );
	}

	char *	c;
	long	long_num;
	long_num = strtol( str.c_str() , &c , 10 );

	if ( *c != '\0'
	 ||  (long_num == LONG_MIN || long_num == LONG_MAX)
	 ||  (long_num < INT_MIN || INT_MAX < long_num) )
	{
		return( false );
	}
	else
	{
		*num = static_cast<int>(long_num);

		return( true );
	}
}


bool   SServer_Message_Translator::server_str_to_dir( Angle *  dir ,
						      const string &  str )
{
	double	d = 0.0;

	if ( ! str_to_real( &d , str ) )
	{
		return( false );
	}

	(*dir) = Degree( d );

	return( true );
}


S_Side  SServer_Message_Translator::lr_to_side( char  l_or_r ,
						S_Side_LR  our_side )
{
	return( lr_to_side( string( 1 , l_or_r ) , our_side ) );
}


S_Side  SServer_Message_Translator::lr_to_side( const string &  l_or_r ,
						S_Side_LR  our_side )
{
	if ( l_or_r == "l"  &&  our_side == S_Side_LR::Left_Side
	  || l_or_r == "r"  &&  our_side == S_Side_LR::Right_Side )
	{
		return( S_Side::Our_Side );
	}
	else if ( l_or_r == "l"  &&  our_side == S_Side_LR::Right_Side
	       || l_or_r == "r"  &&  our_side == S_Side_LR::Left_Side )
	{
		return( S_Side::Opponent_Side );
	}
	else
	{
		return( S_Side::Unknown );
	}
}

int    SServer_Message_Translator::double_to_nearest_int( double  x )
{
	if ( x < 0.0 )
	{
		x -= 0.5;
	}
	else if ( x > 0.0 )
	{
		x += 0.5;
	}

	return( static_cast<int>( x ) );
}
