#ifdef SSERVER_MONITOR_CONNECTION_TEST
#include  "sserver_monitor_connection.h"

using namespace std;

int    main( void )
{
	SServer_Param			param;
	SServer_Monitor_Connection	connection( param );

	connection.send_dispinit();
	connection.send_dispstart();

	for(;;)
	{
		string		data;
		connection.recv( &data );
	}

	return( 0 );
}
#endif




#include  "sserver_monitor_connection.h"
#include  "sserver_message_translator.h"
#include  "debugstream.h"
#include  <string>

using namespace std;

SServer_Monitor_Connection::SServer_Monitor_Connection(
					       const SServer_Param &  param ,
					       const std::string &  host ,
					       ip_port_number_t  port ,
					       long  max_response )
	: sserver_param( param ) ,
	  udp( host , port ,
	       SServer_Param::SSERVER_MAX_MESSAGE_LENGTH , max_response )
{
}

SServer_Monitor_Connection::~SServer_Monitor_Connection()
{
}

int   SServer_Monitor_Connection::fd() const
{
	return( udp.fd() );
}


SServer_Monitor_Connection::operator bool() const
{
	return( this -> udp.operator bool() );
}

bool   SServer_Monitor_Connection::responsive() const
{
	return( this -> udp.responsive() );
}


int    SServer_Monitor_Connection::send( const string &  str )
{
	int	n = this -> udp.send( str );

#if 1
	Debug_Stream::dbg << "send[" << str << "]" << endl;
#endif

	// XXX
	// compare int and size_t
	//
	if ( static_cast<size_t>(n) == str.length() )
	{
		return( n );
	}
	else
	{
		return( -1 );
	}
}


bool   SServer_Monitor_Connection::recv( string *  data ,  bool  block )
{
	(void)(this -> udp.recv( data  , block ));

#if 0
	if ( data -> length() != 0 )
	{
		Debug_Stream::dbg << "recv[" << (*data) << "]" << endl;
	}
#endif

	return( data -> length() != 0 );
}


bool   SServer_Monitor_Connection::recv( string *  data ,  long  usec )
{
	(void)(this -> udp.recv( data , usec ));

#if 0
	if ( data -> length() != 0 )
	{
		Debug_Stream::dbg << "recv[" << (*data) << "]" << endl;
	}
#endif

	return( data -> length() != 0 );
}


int    SServer_Monitor_Connection::send_dispinit()
{
	return( this -> send(
		  SServer_Message_Translator::dispinit_command() ) );
}

int    SServer_Monitor_Connection::send_dispstart()
{
	return( this -> send(
		  SServer_Message_Translator::dispstart_command() ) );
}

int    SServer_Monitor_Connection::send_dispdiscard( S_Side_LR  side ,
						    int  player_number )
{
	return( this -> send(
		  SServer_Message_Translator::dispdiscard_command(
							  side ,
							  player_number ) ) );
}

int    SServer_Monitor_Connection::send_dispfoul( double  x ,
						  double  y ,
						  S_Side_LR  side )
{
	return( this -> send(
		  SServer_Message_Translator::dispfoul_command( x , y ,
								side ) ) );
}
