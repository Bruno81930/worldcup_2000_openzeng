#ifndef	   SSERVER_MONITOR_CONNECTION_H_INCLUDED
#define	   SSERVER_MONITOR_CONNECTION_H_INCLUDED

// Author:		H. Shimora
// Last-Modified:	Apr  7 2000
// Created:		Apr  7 2000
// Version:		0.10

///-----------------------------------------------
/// Change Log:
///-----------------------------------------------
// version 0.10  Apr  7 2000
//
//


#include  "udp_connection.h"
#include  "ip_address.h"
#include  "sserver_param.h"
#include  "s_basic.h"
#include  <string>

class  SServer_Monitor_Connection
{
public:
	static	const	long	DEFAULT_MAX_RESPONCE_TIME
						= 5 * 1000 * 1000; // 5 sec.

protected:
	const SServer_Param &	sserver_param;  // XXX: unused in this version.

	UDP_Connection		udp;

protected:
	// Don't allow this.
	 SServer_Monitor_Connection( const SServer_Monitor_Connection & );
	// Don't allow this.
	 SServer_Monitor_Connection &
			 operator=( const SServer_Monitor_Connection & );

public:
	 SServer_Monitor_Connection(
			const SServer_Param &  param ,
			const std::string &  host = "localhost" ,
			ip_port_number_t  port = SServer_Param::DEFAULT_PORT ,
			long  max_response = DEFAULT_MAX_RESPONCE_TIME );

	virtual	~SServer_Monitor_Connection();

	virtual	int		fd() const;


	virtual			operator bool() const;
	virtual	bool		responsive() const;

	virtual	int		send( const std::string &  str );

	virtual	bool		recv( std::string *  data ,
				      bool  block = false );
	virtual	bool		recv( std::string *  data ,  long  usec );

	virtual	int		send_dispinit();
	virtual	int		send_dispstart();
	virtual	int		send_dispdiscard( S_Side_LR  side ,
						  int  player_number );

	virtual	int		send_dispfoul( double  x ,  double  y ,
					       S_Side_LR  side );
};


#endif	/* SSERVER_MONITOR_CONNECTION_H_INCLUDED */
