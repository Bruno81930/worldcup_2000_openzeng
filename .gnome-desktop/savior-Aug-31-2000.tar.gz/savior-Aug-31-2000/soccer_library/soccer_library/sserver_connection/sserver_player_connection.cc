#ifdef SSERVER_PLAYER_CONNECTION_TEST
#include  "sserver_player_connection.h"

int    main( void )
{
	SServer_Param			param;
	SServer_Player_Connection  server( param );

	server.send_init( "test" );

	server.send_move( -3.0 , 0.12345678 );

	for(;;)
	{
		Information_from_Server	info;

		server.recv_info( &info );
	}

	return( 0 );
}
#endif




#include  "sserver_player_connection.h"
#include  "sserver_message_translator.h"
#include  "adjust_usleep.h"
#include  "debugstream.h"
#include  <string>

using namespace std;

const	double  SServer_Player_Connection::DEFAULT_WAIT_TIME_STEP = 1.1;

SServer_Player_Connection::SServer_Player_Connection(
					const SServer_Param &  param ,
					const string &  host ,
					ip_port_number_t  port ,
					long  max_response ,
					long  default_wait_time )
	: sserver_param( param ) ,
	  udp( host , port ,
	       SServer_Param::SSERVER_MAX_MESSAGE_LENGTH , max_response )
{
	this -> our_side = S_Side_LR::Unknown;
	this -> send_time.set_current_time();

	if ( default_wait_time == -1 )
	{
		this -> default_wait_time
			= static_cast<long>( param.SIMULATOR_STEP() * 1000
					     * DEFAULT_WAIT_TIME_STEP );
	}
	else
	{
		this -> default_wait_time = default_wait_time;
	}
}


SServer_Player_Connection::~SServer_Player_Connection()
{
}


SServer_Player_Connection::operator bool() const
{
	return( this -> udp.operator bool() );
}

bool   SServer_Player_Connection::responsive() const
{
	return( this -> udp.responsive() );
}



long  SServer_Player_Connection::default_wait() const
{
	return( this -> default_wait_time );
}


int    SServer_Player_Connection::send( const string &  str ,
					long  interval_usec )
{
	if ( interval_usec != 0 )
	{
		Time_Stamp	current_time;
		current_time.set_current_time();

		long	diff = (current_time - send_time).usec();

		if ( diff  <  interval_usec )
		{
			Adjust_USleep::usleep( interval_usec - diff );
		}
	}

	int	n = this -> udp.send( str );

#if 1
	Debug_Stream::dbg << "send[" << str << "]" << endl;
#endif

	this -> send_time.set_current_time();

	// XXX
	// compare int and size_t
	//
	if ( static_cast<size_t>(n) == str.length() )
	{
		return( n );
	}
	else
	{
		return( -1 );
	}
}


bool   SServer_Player_Connection::recv( string *  data ,  bool  block )
{
	(void)(this -> udp.recv( data  , block ));

#if 0
	if ( data -> length() != 0 )
	{
		dbg << "recv[" << (*data) << "]" << endl;
	}
#endif

	return( data -> length() != 0 );
}


bool   SServer_Player_Connection::recv( string *  data ,  long  usec )
{
	(void)(this -> udp.recv( data , usec ));

#if 0
	if ( data -> length() != 0 )
	{
		dbg << "recv[" << (*data) << "]" << endl;
	}
#endif

	return( data -> length() != 0 );
}


int    SServer_Player_Connection::send_init( const string &  team_name ,
					     bool  goalie ,
					     Game_Info *  g_info ,
					     int  major_version ,
					     int  minor_version )
{
	string	send_string = SServer_Message_Translator::init_command(
							      team_name ,
							      goalie ,
							      major_version ,
							      minor_version );


	int	ret = this -> send( send_string );


	string	buf;
	for(;;)
	{
		(void)(this -> udp.recv( &buf , true , true ));

		if ( buf.length() != 0 )
		{
			break;
		}

		if ( ! (this -> udp.responsive()) )
		{
			return( -1 );
		}
	}

#if 0
	cout << "init_string = [" << buf << "]" << endl;
#endif

	Game_Info	g;
	SServer_Message_Translator::parse_init_message( &g , buf );

	this ->  team_name = team_name;
	this ->  our_side  = g.our_side;

	if ( g_info != NULL )
	{
		*g_info = g;
	}

	return( ret );
}

int    SServer_Player_Connection::send_init( const string &  team_name ,
					     bool  goalie ,
					     Game_Info *  g_info )
{
	return( this -> send_init( team_name ,
				   goalie ,
				   g_info ,
				   SSERVER_DEFAULT_MAJOR_VERSION ,
				   SSERVER_DEFAULT_MINOR_VERSION ) );
}



int    SServer_Player_Connection::send_reconnect( const string &  team_name ,
						  int  player_number ,
						  Game_Info *  g_info ,
						  long  interval_usec )
{
	string	send_string;
	send_string = SServer_Message_Translator::reconnect_command(
							    team_name ,
							    player_number );

	int	ret = this -> send( send_string , interval_usec );

	string	buf;
	for(;;)
	{
		(void)(this -> udp.recv( &buf , true , true ));

		if ( buf.length() != 0 )
		{
			break;
		}

		if ( ! (this -> udp.responsive()) )
		{
			return( -1 );
		}
	}

#if 0
	cout << "recconect_string = [" << buf << "]" << endl;
#endif

	Game_Info	g;
	SServer_Message_Translator::
		parse_reconnect_message( &g , buf , player_number );

	this ->  team_name = team_name;
	this ->  our_side  = g.our_side;

	// XXX
	if ( g_info != NULL )
	{
		*g_info = g;
	}

	return( ret );
}


int    SServer_Player_Connection::send_bye( long  interval_usec )
{
	string	send_string;
	send_string = SServer_Message_Translator::bye_command();

	return( this -> send( send_string , interval_usec ) );
}


int    SServer_Player_Connection::send_move( double  x ,  double  y ,
					     long  interval_usec )
{
	string	send_string;
	send_string = SServer_Message_Translator::move_command( x , y );

	return( this -> send( send_string , interval_usec ) );
}


int    SServer_Player_Connection::send_dash( double  power ,
					     long  interval_usec )
{
	string	send_string;
	send_string = SServer_Message_Translator::dash_command( power );

	return( this -> send( send_string , interval_usec ) );
}


int    SServer_Player_Connection::send_kick( double  power ,
					     const Angle &  direction ,
					     long  interval_usec )
{
	string	send_string;
	send_string = SServer_Message_Translator::kick_command(
			power ,
			direction.normalize() );

	return( this -> send( send_string , interval_usec ) );
}


int    SServer_Player_Connection::send_turn( const Angle &  moment ,
					     long  interval_usec )
{
	string	send_string;
	send_string = SServer_Message_Translator::turn_command( moment );

	return( this -> send( send_string , interval_usec ) );
}


int    SServer_Player_Connection::send_say( const string &  message ,
					    long  interval_usec )
{
	string	send_string;
	send_string = SServer_Message_Translator::say_command( message );

	return( this -> send( send_string , interval_usec ) );
}


int    SServer_Player_Connection::send_catch( const Angle &  direction ,
					      long  interval_usec )
{
	string	send_string;
	send_string
	  = SServer_Message_Translator::catch_command( direction.normalize() );

	return( this -> send( send_string , interval_usec ) );
}


int    SServer_Player_Connection::send_change_view( View_Width  width ,
						    View_Quality  quality ,
						    long  interval_usec )
{
	string	send_string;
	send_string = SServer_Message_Translator::change_view_command(
								width ,
								quality );

	return( this -> send( send_string , interval_usec ) );
}


int    SServer_Player_Connection::send_sense_body( long  interval_usec )
{
	string	send_string;
	send_string = SServer_Message_Translator::sense_body_command();

	return( this -> send( send_string , interval_usec ) );
}


int    SServer_Player_Connection::send_turn_neck( const Angle &  direction ,
						  long  interval_usec )
{
	string	send_string;
	send_string = SServer_Message_Translator::turn_neck_command(
						    direction.normalize() );

	return( this -> send( send_string , interval_usec ) );
}


int    SServer_Player_Connection::send_command( const Soccer_Command &  com ,
						long  interval_usec )
{
	int	ret = -1;

	switch( com.type() )
	{
	case Soccer_Command::Move_Command:
		ret = send_move( com.move_x() , com.move_y() , interval_usec );
		break;
	case Soccer_Command::Dash_Command:
		ret = send_dash( com.dash_power() , interval_usec );
		break;
	case Soccer_Command::Kick_Command:
		ret = send_kick( com.kick_power() , com.kick_direction() ,
				 interval_usec );
		break;
	case Soccer_Command::Turn_Command:
		ret = send_turn( com.turn_moment() , interval_usec );
		break;
	case Soccer_Command::Catch_Ball_Command:
		ret = send_catch( com.catch_direction() , interval_usec );
		break;
	case Soccer_Command::Turn_Neck_Command:
		ret = send_turn_neck( com.turn_neck_direction() ,
				      interval_usec );
		break;
	case Soccer_Command::Change_View_Command:
		ret = send_change_view( com.change_view_view_width() ,
					com.change_view_view_quality() ,
					interval_usec );
		break;
	case Soccer_Command::Sense_Body_Command:
		ret = send_sense_body( interval_usec );
		break;
	case Soccer_Command::Say_Command:
		ret = send_say( com.say_message() , interval_usec );
		break;
	case Soccer_Command::Wait_Command:
	case Soccer_Command::No_Command_Command:
	case Soccer_Command::Illegal_Command:
		break;
	}

	return( ret );
}


#if 0
//
// coach commands
//
int    SServer_Player_Connection::send_look( long  interval_usec = 0 )
{
	string	send_string;
	send_string = SServer_Message_Translator::look_command();

	return( this -> send( send_string , interval_usec ) );
}

int    SServer_Player_Connection::send_check_ball( long  interval_usec = 0 )
{
	string	send_string;
	send_string = SServer_Message_Translator::check_ball_command();

	return( this -> send( send_string , interval_usec ) );
}

int    SServer_Player_Connection::send_ear( bool  on_off ,
					    long  interval_usec = 0 )
{
	string	send_string;
	send_string = SServer_Message_Translator::err_command( on_off );

	return( this -> send( send_string , interval_usec ) );
}

int    SServer_Player_Connection::send_change_mode( Play_Mode  mode ,
					     long  interval_usec = 0 )
{
	string	send_string;
	send_string = SServer_Message_Translator::change_mode_command( mode );

	return( this -> send( send_string , interval_usec ) );
}
#endif




int    SServer_Player_Connection::send_reconnect( const string &  team_name ,
						  int  player_number ,
						  Game_Info *  g_info ,
						  bool  default_wait )
{
	return( send_reconnect( team_name , player_number , g_info ,
				(default_wait ? default_wait_time : 0) ) );
}

int    SServer_Player_Connection::send_bye( bool  default_wait )
{
	return( send_bye( (default_wait ? default_wait_time : 0) ) );
}

int    SServer_Player_Connection::send_move( double  x ,  double  y ,
					     bool  default_wait )
{
	return( send_move( x , y , (default_wait ? default_wait_time : 0) ) );
}

int    SServer_Player_Connection::send_dash( double  power ,
					     bool  default_wait )
{
	return( send_dash( power , (default_wait ? default_wait_time : 0) ) );
}

int    SServer_Player_Connection::send_kick( double  power ,
					     const Angle &  direction ,
					     bool  default_wait )
{
	return( send_kick( power , direction ,
			   (default_wait ? default_wait_time : 0) ) );
}

int    SServer_Player_Connection::send_turn( const Angle &  moment ,
					     bool  default_wait )
{
	return( send_turn( moment , (default_wait ? default_wait_time : 0) ) );
}

int    SServer_Player_Connection::send_say( const string &  message ,
					    bool  default_wait )
{
	return( send_say( message , (default_wait ? default_wait_time : 0) ) );
}

int    SServer_Player_Connection::send_catch( const Angle &  direction ,
					      bool  default_wait )
{
	return( send_catch( direction ,
			    (default_wait ? default_wait_time : 0) ) );
}

int    SServer_Player_Connection::send_change_view( View_Width  width ,
						    View_Quality  quality ,
					     bool  default_wait )
{
	return( send_change_view( width , quality ,
				  (default_wait ? default_wait_time : 0) ) );
}

int    SServer_Player_Connection::send_sense_body( bool  default_wait )
{
	return( send_sense_body( (default_wait ? default_wait_time : 0) ) );
}

int    SServer_Player_Connection::send_turn_neck( const Angle &  direction ,
						  bool  default_wait )
{
	return( send_turn_neck( direction ,
				(default_wait ? default_wait_time : 0) ) );
}

int    SServer_Player_Connection::send_command(
					 const Soccer_Command &  command ,
					 bool  default_wait )
{
	return( send_command( command ,
			      (default_wait ? default_wait_time : 0) ) );
}




bool   SServer_Player_Connection::recv_info( Information_from_Server *  info ,
					     bool  block )
{
	string	data;
	this -> recv( &data , block );

	SServer_Message_Translator::parse_message( info ,
						   data ,
						   our_side ,
						   team_name );

	if ( info -> type() == Information_from_Server::Type_Unknown )
	{
		cerr << "Unknown format: [" << (info -> raw_message()) << "]"
		     << endl;
	}

	return( ! (info -> no_info()) );
}


bool   SServer_Player_Connection::recv_info( Information_from_Server *  info ,
					     long  usec )
{
	string	data;
	this -> recv( &data , usec );

	SServer_Message_Translator::parse_message( info ,
						   data ,
						   our_side ,
						   team_name );

	if ( info -> type() == Information_from_Server::Type_Unknown )
	{
		cerr << "Unknown format: [" << (info -> raw_message()) << "]"
		     << endl;
	}

	return( ! (info -> no_info()) );
}
