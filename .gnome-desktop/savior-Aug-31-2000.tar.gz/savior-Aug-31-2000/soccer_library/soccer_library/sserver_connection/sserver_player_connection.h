#ifndef	   SSERVER_PLAYER_CONNECTION_H_INCLUDED
#define	   SSERVER_PLAYER_CONNECTION_H_INCLUDED

// Author:		H. Shimora
// Last-Modified:	Aug 11 1998
// Version:		0.10

///-----------------------------------------------
/// Change Log:
///-----------------------------------------------
// version 0.10  Aug 11 1998
//
//


#include  "udp_connection.h"
#include  "information_from_server.h"
#include  "game_info.h"
#include  "sserver_param.h"
#include  "time_stamp.h"
#include  "soccer_command.h"
#include  "ip_address.h"
#include  "angle.h"
#include  <string>
#include  <cstddef>

class  SServer_Player_Connection
{
public:
	static	const	int	SSERVER_DEFAULT_MAJOR_VERSION = 5;
	static	const	int	SSERVER_DEFAULT_MINOR_VERSION = 0;

	static	const	long	DEFAULT_MAX_RESPONCE_TIME
						= 5 * 1000 * 1000; // 5 sec.

	static	const	double	DEFAULT_WAIT_TIME_STEP;

protected:
	const SServer_Param &	sserver_param;  // XXX: unused in this version.

	UDP_Connection		udp;

	std::string		team_name;
	S_Side_LR		our_side;

	Time_Stamp		send_time;

	long			default_wait_time;

protected:
	// Don't allow this.
	 SServer_Player_Connection( const SServer_Player_Connection & );
	// Don't allow this.
	 SServer_Player_Connection &
			 operator=( const SServer_Player_Connection & );

public:
		 SServer_Player_Connection(
			     const SServer_Param &  param ,
			     const std::string &  host = "localhost" ,
			     ip_port_number_t  port
			       = SServer_Param::DEFAULT_PORT ,
			     long  max_response = DEFAULT_MAX_RESPONCE_TIME ,
			     long  default_wait_time = -1 );

	virtual	~SServer_Player_Connection();

	virtual			operator bool() const;
	virtual	bool		responsive() const;

	virtual	int		send( const std::string &  str ,
				      long  interval_usec = 0 );

	virtual	bool		recv( std::string *  data ,  bool  block );
	virtual	bool		recv( std::string *  data ,  long  usec );

	virtual	long		default_wait() const;

	virtual	int	send_init(
			 const std::string &  team_name ,
			 bool  goalie = false ,
			 Game_Info *  g_info = static_cast<Game_Info *>(NULL) ,
			 int  major_version = SSERVER_DEFAULT_MAJOR_VERSION ,
			 int  minor_version = SSERVER_DEFAULT_MINOR_VERSION );

	virtual	int	send_init( const std::string &  team_name ,
				   bool  goalie ,
				   Game_Info *  g_info );

	virtual	int	send_reconnect( const std::string &  team_name ,
					int  player_number ,
					Game_Info *  g_info
					  = static_cast<Game_Info *>(NULL) ,
					long  interval_usec = 0 );

	virtual	int	send_bye( long  interval_usec = 0 );

	virtual	int	send_move( double  x ,  double  y ,
				   long  interval_usec = 0 );
	virtual	int	send_dash( double  power ,  long  interval_usec = 0 );

	virtual	int	send_kick( double  power ,  const Angle &  direction ,
				   long  interval_usec = 0 );
	virtual	int	send_turn( const Angle &  moment ,
				   long  interval_usec = 0 );
	virtual	int	send_say( const std::string &  message ,
				  long  interval_usec = 0 );
	virtual	int	send_catch( const Angle &  direction ,
				    long  interval_usec = 0 );
	virtual	int	send_change_view( View_Width  width ,
					  View_Quality  quality ,
					  long  interval_usec = 0 );
	virtual	int	send_sense_body( long  interval_usec = 0 );
	virtual	int	send_turn_neck( const Angle &  direction ,
					long  interval_usec = 0 );

	virtual	int	send_command( const Soccer_Command &  command ,
				      long  interval_usec = 0 );

#if 0
	//
	// coach commands
	//
	virtual	int	send_look( long  interval_usec = 0 );
	virtual	int	send_check_ball( long  interval_usec = 0 );
	virtual	int	send_ear( bool  on_off , long  interval_usec = 0 );
	virtual	int	send_change_mode( Play_Mode  mode ,
					  long  interval_usec = 0 );
#endif

	virtual	int	send_reconnect( const std::string &  team_name ,
					int  player_number ,
					Game_Info *  g_info ,
					bool  default_wait );

	virtual	int	send_bye( bool  default_wait );

	virtual	int	send_move( double  x ,  double  y ,
				   bool  default_wait );
	virtual	int	send_dash( double  power ,  bool  default_wait );
	virtual	int	send_kick( double  power ,  const Angle &  direction ,
				   bool  default_wait );
	virtual	int	send_turn( const Angle &  moment ,
				   bool  default_wait );
	virtual	int	send_say( const std::string &  message ,
				  bool  default_wait );
	virtual	int	send_catch( const Angle &  direction ,
				    bool  default_wait );
	virtual	int	send_change_view( View_Width  width ,
					  View_Quality  quality ,
					  bool  default_wait );
	virtual	int	send_sense_body( bool  default_wait );
	virtual	int	send_turn_neck( const Angle &  direction ,
					bool  default_wait );

	virtual	int	send_command( const Soccer_Command &  command ,
				      bool  default_wait );

	virtual	bool	recv_info( Information_from_Server *  info ,
				   bool  block = false );

	virtual	bool	recv_info( Information_from_Server *  info ,
				   long  usec );
};


#endif	/* SSERVER_PLAYER_CONNECTION_H_INCLUDED */
