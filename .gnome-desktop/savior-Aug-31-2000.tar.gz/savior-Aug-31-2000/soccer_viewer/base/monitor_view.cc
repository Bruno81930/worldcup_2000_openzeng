#include "monitor_view.h"

Monitor_View::Monitor_View()
	: play_mode() ,
	  time_count( -1 ) ,
	  ball( 0.0 , 0.0 ) ,
	  player(),
	  team()
{
}

Monitor_View::Monitor_View
      ( const SServer_Monitor_Log_Format::dispinfo_t &  info )
	: play_mode() ,
	  time_count( -1 ) ,
	  ball( 0.0 , 0.0 ) ,
	  player() ,
	  team()
{
	this -> set_info( info );
}

Monitor_View::~Monitor_View()
{
}


void   Monitor_View::set_info
	 ( const SServer_Monitor_Log_Format::dispinfo_t &  info )
{
	if ( info.mode != SServer_Monitor_Log_Format::dispinfo_t::SHOW_MODE )
	{
		return;
	}

	this -> time_count = info.body.show.time;
	this -> play_mode  = info.body.show.pmode;

	this -> team[0].team_name = info.body.show.team[0].name;
	this -> team[0].score     = info.body.show.team[0].score;
	this -> team[1].team_name = info.body.show.team[1].name;
	this -> team[1].score     = info.body.show.team[1].score;

	this -> ball.set( info.body.show.pos[0].real_x() ,
			  info.body.show.pos[0].real_y() );

	for ( int  i = 0  ;
	      i < SServer_Monitor_Log_Format::MAX_PLAYER * 2  ;  i ++ )
	{
		this -> player[i] = info.body.show.pos[i + 1];
	}
}
