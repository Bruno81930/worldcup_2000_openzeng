#ifndef	   MONITOR_VIEW_H_INCLUDED
#define	   MONITOR_VIEW_H_INCLUDED

// Author:		H. Shimora
// Last-Modified:	May 22 2000
// Created:		May 22 2000
// Version:		0.00

///-----------------------------------------------
/// Change Log:
///-----------------------------------------------
// version 0.00  May 22 2000    base version.
//
//

#include  "sserver_monitor_log_format.h"
#include  "s_basic.h"
#include  "angle.h"
#include  <vector>
#include  <string>
#include  <iostream>

class  Monitor_View
{
public:
	class  Player_State
	{
	protected:
		bool	valid_		: 1;

		bool	goalie_		: 1;
		bool	kicking_	: 1;
		bool	kick_fault_	: 1;
		bool	catching_	: 1;
		bool	catch_fault_	: 1;
		bool	ball_to_player_	: 1;
		bool	player_to_ball_	: 1;
		bool	discard_	: 1;

		int		uniform_number_	: 8;

		int		side_		: 2;
		float		body_angle_;
		float		x_;
		float		y_;

	public:
		bool	valid()		const { return( valid_ ); }

		bool	goalie()	const { return( goalie_ ); }
		bool	kicking()	const { return( kicking_ ); }
		bool	kick_fault()	const { return( kick_fault_ );}
		bool	catching()	const { return( catching_ ); }
		bool	catch_fault()	const { return( catch_fault_ ); }
		bool	ball_to_player()const { return( ball_to_player_ ); }
		bool	player_to_ball()const { return( player_to_ball_ ); }
		bool	discard()	const { return( discard_ ); }

		int	uniform_number()const { return( uniform_number_ ); }

		S_Side_LR	side() const
		{
			if ( side_ > 0 )
			{
				return( S_Side_LR::Left_Side );
			}
			else if ( side_ < 0 )
			{
				return( S_Side_LR::Right_Side );
			}
			else
			{
				return( S_Side_LR::Unknown );
			}
		}

		Angle	body_angle() const { return( Degree( body_angle_ ) ); }
		double	x()	     const { return( x_ ); }
		double	y()	     const { return( y_ ); }


		void	set_valid( bool  b )		{valid_ = b;}
		void	set_goalie( bool  b )		{goalie_ = b;}
		void	set_kicking( bool  b )		{kicking_ = b;}
		void	set_kick_fault( bool  b )	{kick_fault_ = b;}
		void	set_catching( bool  b )		{catching_ = b;}
		void	set_catch_fault( bool  b )	{catch_fault_ = b ;}
		void	set_ball_to_player(bool  b)	{ball_to_player_ = b;}
		void	set_player_to_ball(bool  b)	{player_to_ball_ = b;}
		void	set_discard( bool  b )		{discard_ = b;}

		void	set_uniform_number( int  u )	{uniform_number_ = u;}

		void	set_side( const S_Side_LR &  s )
		{
			if ( s == S_Side_LR::Left_Side )	{ side_ =  1; }
			else if ( s == S_Side_LR::Right_Side )	{ side_ = -1; }
			else					{ side_ =  0; }
		}

		void	set_body_angle( const Angle &  a )
				{ body_angle_ = a.degree() ; }
		void	set_x( double  d )	{ x_ = d; }
		void	set_y( double  d )	{ y_ = d; }

	public:
		Player_State()
			: valid_( false ) ,
			  goalie_( false ) ,
			  kicking_( false ) , kick_fault_( false ) ,
			  catching_( false ) , catch_fault_( false ) ,
			  ball_to_player_( false ) , player_to_ball_( false ) ,
			  discard_( false ) ,
			  uniform_number_( -1 ) ,
			  side_( 0 ) ,
			  body_angle_( 0.0 ) ,
			  x_( 0.0 ) , y_( 0.0 )
		{
		}

		Player_State( const SServer_Monitor_Log_Format::pos_t &  pos )
			: valid_( pos.enable ) ,
			  goalie_( pos.enable
			   & SServer_Monitor_Log_Format::pos_t::GOALIE ) ,
			  kicking_( pos.enable
			   & SServer_Monitor_Log_Format::pos_t::KICK ) ,
			  kick_fault_( pos.enable
			   & SServer_Monitor_Log_Format::pos_t::KICK_FAULT ) ,
			  catching_( pos.enable
			   & SServer_Monitor_Log_Format::pos_t::CATCH ) ,
			  catch_fault_( pos.enable
			   & SServer_Monitor_Log_Format::pos_t::CATCH_FAULT ) ,
			  ball_to_player_( pos.enable
			   & SServer_Monitor_Log_Format::pos_t::
							  BALL_TO_PLAYER ) ,
			  player_to_ball_( pos.enable
			   & SServer_Monitor_Log_Format::pos_t::
							  PLAYER_TO_BALL ) ,
			  discard_( pos.enable
			   & SServer_Monitor_Log_Format::pos_t::DISCARD ) ,
			  uniform_number_( pos.unum ) ,
			  side_( 0 ) ,
			  body_angle_( pos.angle ) ,
			  x_( pos.real_x() ) , y_( pos.real_y() )
		{
			if ( pos.side_lr() == S_Side_LR::Left_Side )
			{
				side_ = 1;
			}
			else if ( pos.side_lr() == S_Side_LR::Right_Side )
			{
				side_ = -1;
			}
			else
			{
				side_ = 0;
			}
		}
	};

	struct  Team_State
	{
		std::string	team_name;
		long		score;

	public:
		 Team_State() : team_name("") , score(0) {}
		~Team_State() {}
	};

	struct  Monitor_Play_Mode
	{
		char	pmode;

	public:
		enum Mode { Null ,		Before_Kick_Off ,
			    Time_Over ,		Play_On ,
			    Kick_Off_Left ,	Kick_Off_Right ,
			    Kick_In_Left ,	Kick_In_Right ,
			    Free_Kick_Left ,	Free_Kick_Right ,
			    Corner_Kick_Left ,	Corner_Kick_Right ,
			    Goal_Kick_Left ,	Goal_Kick_Right ,
			    Goal_Left ,		Goal_Right ,
			    Drop_Ball ,
			    Offside_Left ,	Offside_Right };

		static const int	N_MODE = 19;

	public:
		Monitor_Play_Mode( char  m = Null ) : pmode(m) {}

		operator Monitor_Play_Mode::Mode() const
		{
			return( static_cast<Monitor_Play_Mode::Mode>(pmode) );
		}

		bool	operator == ( const Mode &  m ) const
		{
			return( pmode == static_cast<char>(m) );
		}

		bool	operator != ( const Mode &  m ) const
		{
			return( ! ((*this) == m) );
		}

		bool	operator == ( const Monitor_Play_Mode &  m ) const
		{
			return( pmode == m.pmode );
		}

		bool	operator != ( const Monitor_Play_Mode &  m ) const
		{
			return( ! ((*this) == m) );
		}

		string	play_mode_str( const string &  left_teamname = "" ,
				       const string &  right_teamname = "" )
									 const
		{
			struct  Mode_Trans_Table
			{
				string		mode_string;
				S_Side_LR	side;
			};

			static	Mode_Trans_Table	table[N_MODE]
			= {
				{ "null" ,            S_Side_LR::Unknown } ,
				{ "before kick off" , S_Side_LR::Unknown } ,
				{ "time over" ,       S_Side_LR::Unknown } ,
				{ "play on" ,         S_Side_LR::Unknown } ,
				{ "kick off" ,        S_Side_LR::Left_Side } ,
				{ "kick off" ,        S_Side_LR::Right_Side } ,
				{ "kick in" ,         S_Side_LR::Left_Side } ,
				{ "kick in" ,         S_Side_LR::Right_Side } ,
				{ "free kick" ,       S_Side_LR::Left_Side } ,
				{ "free kick" ,       S_Side_LR::Right_Side } ,
				{ "corner kick" ,     S_Side_LR::Left_Side } ,
				{ "corner kick" ,     S_Side_LR::Right_Side } ,
				{ "goal kick" ,       S_Side_LR::Left_Side } ,
				{ "goal kick" ,       S_Side_LR::Right_Side } ,
				{ "goal" ,            S_Side_LR::Left_Side } ,
				{ "goal" ,            S_Side_LR::Right_Side } ,
				{ "drop ball" ,       S_Side_LR::Unknown } ,
				{ "offside" ,         S_Side_LR::Left_Side } ,
				{ "offside right" ,   S_Side_LR::Right_Side }
			};

			if ( static_cast<size_t>(pmode)
			       >= (sizeof(table) / sizeof(table[0]))
			  || pmode < 0 )
			{
				std::cerr << "Unknown play mode" << endl;

				return( "Unknown" );
			}


			string	left_str;
			if ( left_teamname.length() == 0 )
			{
				left_str = "left";
			}
			else
			{
				left_str = string("\"") + left_teamname + "\"";
			}

			string	right_str;
			if ( right_teamname.length() == 0 )
			{
				right_str = "right";
			}
			else
			{
				right_str
				    = string("\"") + right_teamname + "\"";
			}

			const Mode_Trans_Table &
				m = table[static_cast<int>(pmode)];

			if ( m.side == S_Side_LR::Left_Side )
			{
				return( m.mode_string + " " + left_str );
			}
			else if ( m.side == S_Side_LR::Right_Side )
			{
				return( m.mode_string + " " + right_str );
			}
			else
			{
				return( m.mode_string );
			}
		}

		S_Side_LR	advantage() const
		{
			switch( pmode )
			{
			case Kick_Off_Left:
			case Kick_In_Left:
			case Free_Kick_Left:
			case Corner_Kick_Left:
			case Goal_Kick_Left:
			case Offside_Right:
				return( S_Side_LR::Left_Side );
				break;

			case Kick_Off_Right:
			case Kick_In_Right:
			case Free_Kick_Right:
			case Corner_Kick_Right:
			case Goal_Kick_Right:
			case Offside_Left:
				return( S_Side_LR::Right_Side );
				break;

			case Null:
			case Before_Kick_Off:
			case Time_Over:
			case Play_On:
			case Goal_Left:
			case Goal_Right:
			case Drop_Ball:
			default:
				return( S_Side_LR::Unknown );
				break;
			}
		}

		static	std::vector<Monitor_Play_Mode>	mode_list()
		{
			std::vector<Monitor_Play_Mode>	m_list;

			for( int  i = 0  ;  i < N_MODE  ;  i ++ )
			{
				m_list.push_back( Mode(i) );
			}

			return( m_list );
		}
	};


public:
	Monitor_Play_Mode		play_mode;
	long				time_count;
	D2_Vector			ball;
	Player_State			player[MAX_PLAYER * 2];
	Team_State			team[2];

protected:
	void	set_info( const SServer_Monitor_Log_Format::dispinfo_t & );

public:
	 Monitor_View();
	 Monitor_View( const SServer_Monitor_Log_Format::dispinfo_t & );

	~Monitor_View();
};


#endif	/* MONITOR_VIEW_H_INCLUDED */
