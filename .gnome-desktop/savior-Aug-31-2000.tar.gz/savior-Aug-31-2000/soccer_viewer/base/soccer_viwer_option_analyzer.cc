#include  "soccer_viwer_option_analyzer.h"
#include  "debug_server_connection.h"

using namespace std;

void   Soccer_Viwer_Option_Analyzer::usage( ostream &  ostr ) const
{
	ostr << "Usage: " << this -> program_name() << " [option ...]" << endl
	     << "Possible options are:" << endl
	     << "      --help" << endl
	     << "  -h, --host HOST" << endl
	     << "  -p, --port, --server-port PORT" << endl
	     << "  -P, --debug-port PORT" << endl;
}


Soccer_Viwer_Option_Analyzer::Soccer_Viwer_Option_Analyzer
			       ( const string &  default_server_host_name ,
				 ip_port_number_t  default_server_port_number ,
				 ip_port_number_t  default_debug_port_number )
{
	//
	// Initialize
	//
	this -> help_flag   = false;
	this -> server_host = default_server_host_name;
	this -> server_port = default_server_port_number;
	this -> debug_port  = default_debug_port_number;


	//
	// Add Options
	//
	this -> add_long_option_flag_on(       "--help"       , &help_flag );
	this -> add_option_string      ( 'h' , "--host"       , &server_host );
	this -> add_long_option_string (       "--server-host", &server_host );
	this -> add_option_integer     ( 'p' , "--port"       , &server_port );
	this -> add_long_option_integer(       "--server-port", &server_port );
	this -> add_option_integer     ( 'P' , "--debug-port" , &debug_port );
}

Soccer_Viwer_Option_Analyzer::~Soccer_Viwer_Option_Analyzer()
{
}

bool   Soccer_Viwer_Option_Analyzer::help() const
{
	return( this -> help_flag );
}

string  Soccer_Viwer_Option_Analyzer::server_hostname() const
{
	return( this -> server_host );
}

ip_port_number_t  Soccer_Viwer_Option_Analyzer::server_port_number() const
{
	return( static_cast<ip_port_number_t>( this -> server_port ) );
}

ip_port_number_t  Soccer_Viwer_Option_Analyzer::debug_port_number() const
{
	if ( this -> debug_port == 0 )
	{
		return( this -> server_port_number()
			  + Debug_Server_Connection::DEFAULT_PORT_OFFSET );
	}
	else
	{
		return( static_cast<ip_port_number_t>( this -> debug_port ) );
	}
}
