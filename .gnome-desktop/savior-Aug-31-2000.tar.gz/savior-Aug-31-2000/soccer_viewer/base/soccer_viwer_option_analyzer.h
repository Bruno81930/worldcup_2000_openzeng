#ifndef	   SOCCER_VIWER_OPTION_ANALYZER_H_INCLUDED
#define	   SOCCER_VIWER_OPTION_ANALYZER_H_INCLUDED

#include  <string>
#include  <iostream>
#include  "option_analyser.h"
#include  "ip_address.h"
#include  "sserver_param.h"

class  Soccer_Viwer_Option_Analyzer : public Option_Analyser
{
protected:
	bool		help_flag;

	std::string	server_host;
	int		server_port;
	int		debug_port;

public:
		 Soccer_Viwer_Option_Analyzer
		   ( const std::string &  default_server_host_name
					 = "localhost" ,
		     ip_port_number_t  default_server_port_number
					 = SServer_Param::DEFAULT_PORT ,
		     ip_port_number_t  default_debug_port_number
					 = 0 /* server_port
						 + Debug_Server_Connection
						    ::DEFAULT_PORT_OFFSET */ );
	virtual	~Soccer_Viwer_Option_Analyzer();

	virtual	void   usage( std::ostream &  ostr = std::cerr ) const;

	virtual	bool			help() const;

	virtual	std::string		server_hostname() const;
	virtual	ip_port_number_t	server_port_number() const;
	virtual	ip_port_number_t	debug_port_number() const;
};


#endif	/* SOCCER_VIWER_OPTION_ANALYZER_H_INCLUDED */
