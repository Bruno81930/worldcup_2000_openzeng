#include  "sserver_monitor_log_format.h"

#include  <sys/types.h>
#include  <netinet/in.h>

using namespace std;

const	double	SServer_Monitor_Log_Format::SHOWINFO_SCALE = 16.0;

bool   SServer_Monitor_Log_Format::parse( dispinfo_t  *  info ,
					  istream &  input )
{
	memset( info , 0 , sizeof( info ) );

	input.read( &(info -> mode) , sizeof( info -> mode ) );
	info -> mode = ntohs( info -> mode );

	switch( info -> mode )
	{
	case dispinfo_t::SHOW_MODE:
	    {
		input.read( &(info -> body.show) ,
			    sizeof( info -> body.show ) );

		showinfo_t &	show = info -> body.show;

		show.time          = ntohs( info -> body.show.time );
		show.team[0].score = ntohs( show.team[0].score );
		show.team[1].score = ntohs( show.team[1].score );

		for ( int  i = 0  ;  i < MAX_PLAYER * 2 + 1  ;  i ++ )
		{
			show.pos[i].enable = ntohs( show.pos[i].enable );
			show.pos[i].side   = ntohs( show.pos[i].side   );
			show.pos[i].unum   = ntohs( show.pos[i].unum   );
			show.pos[i].angle  = ntohs( show.pos[i].angle  );
			show.pos[i].x      = ntohs( show.pos[i].x      );
			show.pos[i].y      = ntohs( show.pos[i].y      );
		}
	    }
	    break;

	case dispinfo_t::MSG_MODE:
	    {
		input.read( &(info -> body.msg.board) ,
			    sizeof( info -> body.msg.board ) );
		info -> body.msg.board = ntohs( info -> body.msg.board );

		short	message_length = 0;
		input.read( &message_length , sizeof( message_length ) );
#if 0
		message_length = ntohs( message_length );
#endif
		if ( static_cast<size_t>(message_length)
		     > sizeof( info -> body.msg.message ) - 1 )
		{
			return( false );
		}

		input.read( info -> body.msg.message , message_length );
	    }
	}

	return( true );
}

#include  <strstream>
bool   SServer_Monitor_Log_Format::parse( dispinfo_t  *  info ,
					  const string &  input )
{
	istrstream	stream( input.data() , input.length() );

	return( SServer_Monitor_Log_Format::parse( info , stream ) );
}
