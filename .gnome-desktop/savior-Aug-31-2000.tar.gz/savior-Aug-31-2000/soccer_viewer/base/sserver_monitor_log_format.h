#ifndef	   SSERVER_MONITOR_LOG_FORMAT_H_INCLUDED
#define	   SSERVER_MONITOR_LOG_FORMAT_H_INCLUDED

#include  <string>
#include  "s_basic.h"

class  SServer_Monitor_Log_Format
{
public:
	static	const	int	MAX_PLAYER = 11;
	static	const	int	COLOR_NAME_MAX = 64;
	static	const	int	REC_VERSION_2 = 2;

	static	const	double	SHOWINFO_SCALE;

public:
	struct  pos_t
	{
	public:
		enum
		{
			DISABLE        = 0x0000 ,
			STAND          = 0x0001 ,
			KICK           = 0x0002 ,
			KICK_FAULT     = 0x0004 ,
			GOALIE         = 0x0008 ,
			CATCH          = 0x0010 ,
			CATCH_FAULT    = 0x0020 ,
			BALL_TO_PLAYER = 0x0040 ,
			PLAYER_TO_BALL = 0x0080 ,
			DISCARD        = 0x0100
		};

	public:
		static	const	int	LEFT = 1;
		static	const	int	NEUTRAL = 0;
		static	const	int	RIGHT = -1;

	public:
		short	enable;
		short	side;
		short	unum;
		short	angle;
		short	x;
		short	y;

	public:
		double	real_x() const { return( x / SHOWINFO_SCALE ); }
		double	real_y() const { return( y / SHOWINFO_SCALE ); }

		S_Side_LR	side_lr() const
		{
			switch( side )
			{
			case LEFT:
				return( S_Side_LR::Left_Side );
				break;

			case RIGHT:
				return( S_Side_LR::Right_Side );
				break;

			default:
				return( S_Side_LR::Unknown );
				break;
			}
		}
	};

	struct  team_t
	{
		char	name[16];
		short	score;
	};

	struct  showinfo_t
	{
		char	pmode;
		team_t	team[2];
		pos_t	pos[MAX_PLAYER * 2 + 1];
		short	time;
	};

	struct  msginfo_t
	{
		short	board;
		char	message[2048];
	};

	struct  pointinfo_t
	{
		short	x;
		short	y;
		char	color[COLOR_NAME_MAX];
	};

	struct  circleinfo_t
	{
		short	x;
		short	y;
		short	r;
		char	color[COLOR_NAME_MAX];
	};

	struct  lineinfo_t
	{
		short	x1;
		short	y1;
		short	x2;
		short	y2;
		char	color[COLOR_NAME_MAX];
	};

	struct  drawinfo_t
	{
		short	mode;
		union
		{
			pointinfo_t	pinfo;
			circleinfo_t	cinfo;
			lineinfo_t	linfo;
		} object;
	};

	struct  dispinfo_t
	{
		enum  type
		{
			NO_INFO    = 0 ,
			SHOW_MODE  = 1 ,
			MSG_MODE   = 2 ,
			DRAW_MODE  = 3 ,
			BLANK_MODE = 4
		};

		short	mode;

		union
		{
			showinfo_t	show;
			msginfo_t	msg;
			drawinfo_t	draw;
		} body;

	public:
		dispinfo_t() : mode( NO_INFO ){}
	};

public:
	static	bool	parse( dispinfo_t  *  info ,
			       std::istream &  input );

	static	bool	parse( dispinfo_t  *  info ,
			       const std::string &  input );
};


#endif	/* SSERVER_MONITOR_LOG_FORMAT_H_INCLUDED */
