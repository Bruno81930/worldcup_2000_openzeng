#include  "view_controller.h"
#include  "sserver_monitor_log_format.h"
#include  "client_debug_view.h"
#include  <algorithm>
#include  <string>
#include  <cmath>

using namespace std;

const double	View_Controller::PENALTY_AREA_LENGTH     = 16.5  /* meter */;
const double	View_Controller::PENALTY_AREA_HALF_WIDTH = 20.16 /* meter */;
const double	View_Controller::FIELD_HALF_LENGTH       = 52.5  /* meter */;

const int	View_Controller::SIMULATOR_STEP_MSEC = 100 /* msec */;
const int	View_Controller::FAST_SIMULATOR_STEP_MSEC = 20 /* msec */;
const int	View_Controller::N_STEP_DELAY = 2 /* step */;
const long	View_Controller::AUTO_KICK_OFF_WAIT_STEP = 300 /* step */;
const int	View_Controller::MAX_AUTO_KICK_OFF_COLUMN = 4;
const long	View_Controller::AUTO_DROP_WAIT_STEP = 150 /* step */;
const double	View_Controller::AUTO_DROP_CIRCLE_R = 2.0 /* meter */;
const int	View_Controller::MAX_AUTO_DROP_COLUMN = 4;
const int	View_Controller::AUTO_DROP_COUNT = 5 /* sec */;

View_Controller::View_Controller( const std::string &  host_name ,
				  ip_port_number_t  server_port_number ,
				  ip_port_number_t  debug_port_number )
	: param() ,
	  connection( param , host_name , server_port_number ) ,
	  debug_connection( debug_port_number ) ,
	  live_mode_flag( true ) , monitor_responsive( false ) ,
	  server_time( 0 ) , log_count( 0 ) ,
	  log_wait( 0 ) , log_forward( true ) ,
	  game_log() ,
	  old_play_mode( Monitor_View::Monitor_Play_Mode::Null ) ,
	  ball_track( AUTO_DROP_WAIT_STEP ) ,
	  auto_kick_off_flag( false ) , auto_kick_off_count( 0 ) ,
	  auto_drop_flag( false ) , auto_drop_count( 0 ) ,
	  goal_time()
{
	//
	// Monitor Connection
	//
	connection.send_dispinit();

	input_descripter.push_back( connection.fd() );

	for ( int i = 0  ;  i < N_STEP_DELAY  ;  i ++ )
	{
		prev_server_time_queue.push( 0 );
	}
}

View_Controller::~View_Controller()
{
}

std::vector<int>  View_Controller::input_list() const
{
	return( input_descripter );
}

bool   View_Controller::live_mode() const
{
	return( live_mode_flag );
}

bool   View_Controller::monitor_connection_responsive() const
{
	return( connection.responsive() );
}

void   View_Controller::update()
{
	string	debug_message;

	while( debug_connection.recv( &debug_message , false ) > 0 )
	{
		ref_count_ptr<Client_Debug_View>
			c = new Client_Debug_View( param );

		if ( ! (c -> decode( debug_message )) )
		{
			cerr << "Unknown user debug message ["
			     << debug_message << "]" << endl;

			continue;
		}

		if ( c -> field_snapshot() )
		{
			long	t = c -> field_snapshot()
					   -> game_state.current_time.step;

			if ( ! game_log[ t ] )
			{
				game_log[ t ] = new View_Snapshot();
			}

			game_log[ t ] -> set_client_view
				 ( new Debug_Client_Field_Recog( *c ) );
		}
	}


	string	input;

	while( connection.recv( &input , false ) > 0 )
	{
		SServer_Monitor_Log_Format::dispinfo_t	info;

		if ( ! SServer_Monitor_Log_Format::parse( &info , input ) )
		{
			continue;
		}

		if ( info.mode == SServer_Monitor_Log_Format
						::dispinfo_t::SHOW_MODE )
		{
			ref_count_ptr<Monitor_View>
				m = new Monitor_View( info );

			long	t = m -> time_count;

			if ( t < 0 )
			{
				t = 0;
			}

			prev_server_time_queue.pop();
			prev_server_time_queue.push( server_time );

			server_time = t;

			if ( live_mode_flag )
			{
				log_count = prev_server_time_queue.front();
			}

			if ( ! game_log[ t ] )
			{
				game_log[ t ] = new View_Snapshot();
			}

			game_log[ t ] -> set_monitor_view( m );


			if ( live_mode_flag && viewer )
			{
				viewer -> display();
			}


			if ( old_play_mode != m -> play_mode
			  && m -> play_mode == Monitor_View::Monitor_Play_Mode
							    ::Before_Kick_Off )
			{
				auto_kick_off_count = 0;
			}

			if ( auto_kick_off_flag
			  && m -> play_mode == Monitor_View::Monitor_Play_Mode
							    ::Before_Kick_Off
			  && auto_kick_off_count >= 0 )
			{
				if ( (++ auto_kick_off_count)
				     >= AUTO_KICK_OFF_WAIT_STEP )
				{
					this -> send_start();
				}
			}

			if ( old_play_mode != m -> play_mode
			  || m -> play_mode == Monitor_View::Monitor_Play_Mode
							    ::Time_Over )
			{
				ball_track.clear();
			}

			if ( auto_drop_flag
			  && m -> play_mode != Monitor_View::Monitor_Play_Mode
							    ::Before_Kick_Off )
			{
				ball_track.push_front( m -> ball );

				while( ball_track.size()
				   > static_cast<size_t>(AUTO_DROP_WAIT_STEP) )
				{
					list<D2_Vector>::iterator
						it = ball_track.end();
					it --;
					ball_track.erase( it );
				}

				auto_drop_count = 0;
				list<D2_Vector>::iterator	it;
				for ( it = ball_track.begin()  ;
				      it != ball_track.end()  ;  it ++ )
				{
					if ( (*it - (m -> ball)).r()
					     >= AUTO_DROP_CIRCLE_R )
					{
						break;
					}

					auto_drop_count ++;
				}

				if ( auto_drop_count == AUTO_DROP_WAIT_STEP )
				{
					this -> auto_drop_ball
						  ( m -> ball ,
						    m -> play_mode );

				}
			}

			//
			// set goal time
			//
			if ( m -> play_mode == Monitor_View::Monitor_Play_Mode
							    ::Goal_Left )
			{
				if ( find( goal_time.begin() ,
					   goal_time.end() ,
					   pair<long,S_Side_LR>
					   (m -> time_count ,
					    S_Side_LR::Left_Side) )
				     != goal_time.end() )
				{
					goal_time
					.push_back( pair<long,S_Side_LR>
						     (m -> time_count ,
						      S_Side_LR::Left_Side) );
				}
			}

			if ( m -> play_mode == Monitor_View::Monitor_Play_Mode
							    ::Goal_Right )
			{
				if ( find( goal_time.begin() ,
					   goal_time.end() ,
					   pair<long,S_Side_LR>
					   (m -> time_count ,
					    S_Side_LR::Left_Side) )
				     != goal_time.end() )
				{
					goal_time
					.push_back( pair<long,S_Side_LR>
						    (m -> time_count ,
						     S_Side_LR::Right_Side) );
				}
			}

			old_play_mode = m -> play_mode;
		}
	}

	bool	resp = this -> monitor_connection_responsive();

	if ( monitor_responsive != resp )
	{
		viewer -> display();
	}

	monitor_responsive = resp;
}

void   View_Controller::set_viewer
		( const ref_count_ptr<Soccer_Viewer_Abstract> &  v )
{
	viewer = v;

	if ( viewer )
	{
		viewer -> display();
	}
}

void   View_Controller::set_updater
		( const ref_count_ptr<View_Controller_Updater_Abstract> &  u )
{
	updater = u;
}


int    View_Controller::send_start()
{
	auto_kick_off_count = -1;
	return( connection.send_dispstart() );
}

int    View_Controller::send_foul( double  x ,  double  y ,  S_Side_LR  side ,
				   bool  change_to_live_mode )
{
	if ( change_to_live_mode )
	{
		live_mode_flag = true;
		log_wait = 0;
	}

	auto_drop_count = 0;

	return( connection.send_dispfoul( x , y , side ) );
}

void   View_Controller::set_auto_kick_off( bool  f )
{
	this -> auto_kick_off_flag = f;
}

bool   View_Controller::auto_kick_off_mode() const
{
	return( this -> auto_kick_off_flag );
}

long   View_Controller::auto_kick_off_rest_step() const
{
	if ( this -> auto_kick_off_count < static_cast<long>(0) )
	{
		return( static_cast<long>(0) );
	}
	else
	{
		return( View_Controller::AUTO_KICK_OFF_WAIT_STEP
			- this -> auto_kick_off_count );
	}
}

long   View_Controller::auto_kick_off_rest_second() const
{
	if ( this -> auto_kick_off_rest_step() == static_cast<long>(0) )
	{
		return( static_cast<long>(0) );
	}
	else
	{
		return( static_cast<long>
			( (this -> auto_kick_off_rest_step() - 1)
			   * View_Controller::SIMULATOR_STEP_MSEC / 1000
			  + 1 ) );
	}
}

void   View_Controller::set_auto_drop( bool  f )
{
	if ( this -> auto_drop_flag != f )
	{
		ball_track.clear();
	}

	this -> auto_drop_flag = f;
}


bool   View_Controller::auto_drop_mode() const
{
	return( this -> auto_drop_flag );
}

long   View_Controller::auto_drop_rest_step() const
{
	return( View_Controller::AUTO_DROP_WAIT_STEP
			- this -> auto_drop_count );
}

long   View_Controller::auto_drop_rest_second() const
{
	if ( this -> auto_drop_rest_step() == static_cast<long>(0) )
	{
		return( static_cast<long>(0) );
	}
	else
	{
		return( static_cast<long>
			( (this -> auto_drop_rest_step() - 1)
			   * View_Controller::SIMULATOR_STEP_MSEC / 1000
			  + 1 ) );
	}
}

int   View_Controller::auto_drop_ball
		( const D2_Vector &  ball ,
		  const Monitor_View::Monitor_Play_Mode &  play_mode )
{
	ball_track.clear();

	D2_Vector	drop_point = ball;

	if ( fabs( ball.y() ) <= PENALTY_AREA_HALF_WIDTH
	  && fabs( ball.x() ) >= FIELD_HALF_LENGTH
					     - PENALTY_AREA_LENGTH )
	{
		double	drop_x;
		double	drop_y;

		drop_x = ((ball.x() >= 0) ?
			    + (FIELD_HALF_LENGTH - PENALTY_AREA_LENGTH)
			  : - (FIELD_HALF_LENGTH - PENALTY_AREA_LENGTH));

		drop_y = ((ball.y() >= 0) ?
			    + PENALTY_AREA_HALF_WIDTH
			  : - PENALTY_AREA_HALF_WIDTH );

		drop_point.set( drop_x , drop_y );
	}

	S_Side_LR	which_ball;
	switch( play_mode.advantage() )
	{
	case S_Side_LR::Left_Side:
		which_ball = S_Side_LR::Right_Side;
		break;

	case S_Side_LR::Right_Side:
		which_ball = S_Side_LR::Left_Side;
		break;

	case S_Side_LR::Unknown:
	default:
		which_ball = S_Side_LR::Unknown;
		break;
	}

	return( this -> send_foul( drop_point.x() , drop_point.y() ,
				   which_ball , false ) );
}


const SServer_Param &  View_Controller::sserver_param() const
{
	return( param );
}


ref_count_ptr<const Monitor_View>   View_Controller::monitor_view() const
{
	if ( this -> snapshot()  &&  this -> snapshot() -> monitor_view() )
	{
		return( this -> snapshot() -> monitor_view() );
	}
	else
	{
		return( ref_count_ptr<Monitor_View>( 0 ) );
	}
}

ref_count_ptr<const Debug_Client_Field_Recog>  View_Controller::client_view
						( const  S_Side_LR &  side ,
						  int  player_number ) const
{
	if ( this -> snapshot()
	  && this -> snapshot() -> client_view( side , player_number ) )
	{
		return( this
			-> snapshot() -> client_view( side , player_number ) );
	}
	else
	{
		return( ref_count_ptr<Debug_Client_Field_Recog>( 0 ) );
	}
}

ref_count_ptr<const View_Snapshot>  View_Controller::snapshot() const
{
	if ( live_mode_flag )
	{
		return( this -> current_snapshot() );
	}
	else
	{
		return( this -> log_snapshot() );
	}
}

long   View_Controller::snapshot_time() const
{
	if ( live_mode_flag )
	{
		return( prev_server_time_queue.front() );
	}
	else
	{
		return( log_count );
	}
}

ref_count_ptr<const View_Snapshot>  View_Controller::current_snapshot() const
{
	map< long , ref_count_ptr<View_Snapshot> >::const_iterator	it;

	it = game_log.find( prev_server_time_queue.front() );

	if ( it != game_log.end() )
	{
		return( it -> second );
	}
	else
	{
		return( ref_count_ptr<View_Snapshot>( 0 ) );
	}
}

ref_count_ptr<const View_Snapshot>  View_Controller::log_snapshot() const
{
	map< long , ref_count_ptr<View_Snapshot> >::const_iterator	it;

	it = game_log.find( log_count );

	if ( it != game_log.end() )
	{
		return( it -> second );
	}
	else
	{
		return( ref_count_ptr<View_Snapshot>( 0 ) );
	}
}



int    View_Controller::timed_out()
{
	if ( log_wait != 0 )
	{
		if ( log_wait < 0 )
		{
			log_wait = 0;
		}

		if ( log_forward )
		{
			if ( log_count <= prev_server_time_queue.front() )
			{
				this -> forward_log();
			}
			else
			{
				live_mode_flag = true;
				log_wait = 0;
			}
		}
		else
		{
			this -> backward_log();
		}
	}

	return( log_wait );
}

void   View_Controller::forward_log()
{
	log_count ++;

	if ( log_count < 0 )
	{
		log_count = 0;
	}

	viewer -> display();
}

void   View_Controller::backward_log()
{
	log_count --;

	if ( log_count < 0 )
	{
		log_count = 0;
	}

	viewer -> display();
}

void   View_Controller::stop_log()
{
	viewer -> display();
}

void   View_Controller::set_log( long  t )
{
	log_count = t;

	if ( log_count < 0 )
	{
		log_count = 0;
	}

	viewer -> display();
}


void   View_Controller::set_backward_fast()
{
	live_mode_flag = false;
	log_forward = false;

	if ( log_wait == 0 )
	{
		log_wait = FAST_SIMULATOR_STEP_MSEC;

		if ( updater )
		{
			updater -> add_timer( log_wait /* msec */ );
		}
	}
	else
	{
		log_wait = FAST_SIMULATOR_STEP_MSEC;
	}
}


void   View_Controller::set_backward()
{
	live_mode_flag = false;
	log_forward = false;

	if ( log_wait == 0 )
	{
		log_wait = SIMULATOR_STEP_MSEC;

		if ( updater )
		{
			updater -> add_timer( log_wait /* msec */ );
		}
	}
	else
	{
		log_wait = SIMULATOR_STEP_MSEC;
	}
}


void   View_Controller::set_backward_step()
{
	live_mode_flag = false;
	log_wait = 0;

	this -> backward_log();
}

void   View_Controller::set_stop()
{
	live_mode_flag = false;
	log_wait = 0;

	this -> stop_log();
}

void   View_Controller::set_forward_step()
{
	live_mode_flag = false;
	log_wait = 0;

	if ( this -> monitor_view() )
	{
		if ( this -> monitor_view() -> play_mode
		     == Monitor_View::Monitor_Play_Mode::Before_Kick_Off )
		{
			this -> send_start();

			if ( updater )
			{
				updater -> add_timer( SIMULATOR_STEP_MSEC
						      * (N_STEP_DELAY + 1) );
				log_wait = -1;
			}
		}
	}

	this -> forward_log();
}

void   View_Controller::set_forward()
{
	live_mode_flag = false;
	log_forward = true;

	if ( this -> monitor_view() )
	{
		if ( this -> monitor_view() -> play_mode
		     == Monitor_View::Monitor_Play_Mode::Before_Kick_Off )
		{
			this -> send_start();
		}
	}

	if ( log_wait == 0 )
	{
		log_wait = SIMULATOR_STEP_MSEC;

		if ( updater )
		{
			updater -> add_timer( log_wait /* msec */ );
		}
	}
	else
	{
		log_wait = SIMULATOR_STEP_MSEC;
	}
}

void   View_Controller::set_forward_fast()
{
	live_mode_flag = false;
	log_forward = true;

	if ( this -> monitor_view() )
	{
		if ( this -> monitor_view() -> play_mode
		     == Monitor_View::Monitor_Play_Mode::Before_Kick_Off )
		{
			this -> send_start();
		}
	}

	if ( log_wait == 0 )
	{
		log_wait = FAST_SIMULATOR_STEP_MSEC;

		if ( updater )
		{
			updater -> add_timer( log_wait /* msec */ );
		}
	}
	else
	{
		log_wait = FAST_SIMULATOR_STEP_MSEC;
	}
}

void   View_Controller::set_toggle_live_log()
{
	live_mode_flag = (! live_mode_flag);
	log_wait = 0;

	this -> stop_log();
}

void   View_Controller::set_time( long  t )
{
	live_mode_flag = false;
	log_wait = 0;

	set_log( t );
}
