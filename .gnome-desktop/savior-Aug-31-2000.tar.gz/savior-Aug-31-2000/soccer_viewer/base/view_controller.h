#ifndef	   VIEW_CONTROLLER_H_INCLUDED
#define	   VIEW_CONTROLLER_H_INCLUDED

// Author:		H. Shimora
// Last-Modified:	May 21 2000
// Created:		May 21 2000
// Version:		0.00

///-----------------------------------------------
/// Change Log:
///-----------------------------------------------
// version 0.00  May 21 2000    base version.
//
//

#include  "sserver_param.h"
#include  "sserver_monitor_connection.h"
#include  "debug_server_connection.h"
#include  "view_snapshot.h"
#include  "ref_count_ptr.h"
#include  "d2_vector.h"
#include  <vector>
#include  <map>
#include  <queue>
#include  <list>

class  Soccer_Viewer_Abstract;
class  View_Controller_Updater_Abstract;

class  View_Controller
{
public:
	static	const double	PENALTY_AREA_LENGTH;
	static	const double	PENALTY_AREA_HALF_WIDTH;
	static	const double	FIELD_HALF_LENGTH;

public:
	static	const int	SIMULATOR_STEP_MSEC;
	static	const int	FAST_SIMULATOR_STEP_MSEC;
	static	const int	N_STEP_DELAY;
	static	const long	AUTO_KICK_OFF_WAIT_STEP;
	static	const int	MAX_AUTO_KICK_OFF_COLUMN;
	static	const long	AUTO_DROP_WAIT_STEP;
	static	const double	AUTO_DROP_CIRCLE_R;
	static	const int	MAX_AUTO_DROP_COLUMN;
	static	const int	AUTO_DROP_COUNT;

protected:
	ref_count_ptr<Soccer_Viewer_Abstract>		viewer;
	ref_count_ptr<View_Controller_Updater_Abstract>	updater;

	std::vector<int>			input_descripter;

	SServer_Param				param;
	SServer_Monitor_Connection		connection;
	Debug_Server_Connection			debug_connection;

	bool					live_mode_flag;
	bool					monitor_responsive;

	long					server_time;
	std::queue<long>			prev_server_time_queue;

	long					log_count;
	int					log_wait;
	bool					log_forward;

	std::map< long , ref_count_ptr<View_Snapshot> >	game_log;

	Monitor_View::Monitor_Play_Mode		old_play_mode;
	std::list<D2_Vector>			ball_track;

	bool					auto_kick_off_flag;
	long					auto_kick_off_count;

	bool					auto_drop_flag;
	long					auto_drop_count;

	std::vector< pair<long,S_Side_LR> >	goal_time;

protected:
	ref_count_ptr<const View_Snapshot>	current_snapshot() const;
	ref_count_ptr<const View_Snapshot>	log_snapshot() const;

protected:
	void					forward_log();
	void					backward_log();
	void					stop_log();
	void					set_log( long  t );

	int	auto_drop_ball( const D2_Vector & ,
				const Monitor_View::Monitor_Play_Mode & );

public:
	 View_Controller( const std::string &  host_name = "localhost" ,
			  ip_port_number_t  server_port_number
					      = SServer_Param::DEFAULT_PORT ,
			  ip_port_number_t  debug_port_number
					      = Debug_Server_Connection
							     ::DEFAULT_PORT );


	~View_Controller();

	std::vector<int>	input_list() const;

	bool	live_mode() const;
	bool	monitor_connection_responsive() const;

	void	set_viewer
		  ( const ref_count_ptr<Soccer_Viewer_Abstract> & );
	void	set_updater
		  ( const ref_count_ptr<View_Controller_Updater_Abstract> & );

	void	update();
	int	timed_out();

	int	send_start();
	int	send_foul( double  x ,  double  y ,  S_Side_LR  side ,
			   bool  change_to_live_mode );

	void	set_auto_kick_off( bool  f );
	bool	auto_kick_off_mode() const;
	long	auto_kick_off_rest_step() const;
	long	auto_kick_off_rest_second() const;

	void	set_auto_drop( bool  f );
	bool	auto_drop_mode() const;
	long	auto_drop_rest_step() const;
	long	auto_drop_rest_second() const;

	const SServer_Param &			sserver_param() const;

	ref_count_ptr<const View_Snapshot>	snapshot() const;
	ref_count_ptr<const Monitor_View>	monitor_view() const;
	ref_count_ptr<const Debug_Client_Field_Recog>
						client_view
						  ( const  S_Side_LR &  side ,
						    int  player_number ) const;

	long					snapshot_time() const;

	void					set_forward_fast();
	void					set_forward();
	void					set_forward_step();
	void					set_stop();
	void					set_backward_step();
	void					set_backward();
	void					set_backward_fast();
	void					set_toggle_live_log();

	void					set_time( long  t );
};

class  View_Controller_Updater_Abstract
{
public:
		 View_Controller_Updater_Abstract(){}
	virtual	~View_Controller_Updater_Abstract(){}

	virtual	void	add_timer( int ){}
};

class  Soccer_Viewer_Abstract
{
public:
		 Soccer_Viewer_Abstract() {}
	virtual	~Soccer_Viewer_Abstract() {}

	virtual	void	display() = 0;
};


#endif	/* VIEW_CONTROLLER_H_INCLUDED */
