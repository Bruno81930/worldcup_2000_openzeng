#ifndef	   VIEW_SNAPSHOT_H_INCLUDED
#define	   VIEW_SNAPSHOT_H_INCLUDED

// Author:		H. Shimora
// Last-Modified:	May 22 2000
// Created:		May 22 2000
// Version:		0.00

///-----------------------------------------------
/// Change Log:
///-----------------------------------------------
// version 0.00  May 22 2000    base version.
//
//

#include  "monitor_view.h"
#include  "debug_client_field_recog.h"
#include  "ref_count_ptr.h"
#include  <vector>

class  View_Snapshot
{
protected:
	ref_count_ptr<const Monitor_View>			monitor;

	std::vector< ref_count_ptr<const Debug_Client_Field_Recog> >	client;

protected:
	static	int	player_to_offset( const  S_Side_LR &  side ,
					  int  player_number );

public:
	 View_Snapshot();
	~View_Snapshot();

	void	set_monitor_view
			( const ref_count_ptr<const Monitor_View> & );
	void	set_client_view
		( const ref_count_ptr<const Debug_Client_Field_Recog> & );

	ref_count_ptr<const Monitor_View>	monitor_view() const;

	ref_count_ptr<const Debug_Client_Field_Recog>
				client_view( const  S_Side_LR &  side ,
					     int  player_number ) const;
};


#endif	/* VIEW_SNAPSHOT_H_INCLUDED */
