#include  "field_canvas.h"
#include  "field_view.h"
#include  <set>
#include  <cmath>
#include  <cstring>
#include  <algorithm>

using namespace std;


//
// Default Size and Magnify
//
const	gint	Field_Canvas::DEFAULT_WIDTH  = 930;  // pixel
const	gint	Field_Canvas::DEFAULT_HEIGHT = 620;  // pixel

const	gdouble	Field_Canvas::DEFAULT_MAGNIFY = 8.0;


//
// Parameter for Drawing Field
//
const	gdouble	Field_Canvas::FIELD_HALF_WIDTH  = 34.0;
const	gdouble	Field_Canvas::FIELD_HALF_LENGTH = 52.5;
const	gdouble	Field_Canvas::FIELD_WIDTH  = FIELD_HALF_WIDTH * 2.0;
const	gdouble	Field_Canvas::FIELD_LENGTH = FIELD_HALF_LENGTH * 2.0;

const	gdouble	Field_Canvas::PENALTY_AREA_LENGTH     = 16.5;
const	gdouble	Field_Canvas::PENALTY_AREA_HALF_WIDTH = 20.16;

const	gdouble	Field_Canvas::GOAL_AREA_LENGTH     = 5.5;
const	gdouble	Field_Canvas::GOAL_AREA_HALF_WIDTH = 9.16;

const	gdouble	Field_Canvas::CENTER_CIRCLE_R = 9.15;
const	gdouble	Field_Canvas::CORNER_CIRCLE_R = 1.0;

const	gdouble	Field_Canvas::PENALTY_SPOT_DIST = 11.0;


Field_Canvas::Field_Canvas( View_Controller &  controller ,
			    Field_View &  field_view ,
			    View_Config &  config ,
			    const SServer_Param &  param ,
			    gdouble  view_point_x ,  gdouble  view_point_y ,
			    gdouble  mag ,
			    bool  inv_x , bool  inv_y )
	: PENALTY_ARC_DIGREE
		( std::acos((PENALTY_AREA_LENGTH - PENALTY_SPOT_DIST)
				/ CENTER_CIRCLE_R) * 180 / M_PI - 1.0 ) ,
	  config( config ) , param( param ) ,
	  controller( controller ) , field_view( field_view ) ,
	  ratio( 1.0 / mag ) ,
	  center_x( view_point_x ) , center_y( view_point_y ) ,
	  inverse_x( inv_x ) , inverse_y( inv_y ) ,
	  max_number_char_width( 0 ) ,
	  auto_kick_off_message_x( 0 ) , auto_kick_off_message_y( width() ) ,
	  auto_kick_off_message_width( 0 ) ,
	  auto_drop_message_x( 0 ) , auto_drop_message_y( width() ) ,
	  auto_drop_message_width( 0 ) ,
	  gc_font_initialized( false ) ,
	  drop_menu_window( GTK_WINDOW_POPUP ) ,
	  drop_menu_vbox( true ) ,
	  drop_ball_button( "Drop Ball" ) ,
	  free_kick_left_button ( "Free Kick Left" ) ,
	  free_kick_right_button( "Free Kick Right" )
{
	//
	// this window
	//
	this -> size( this -> DEFAULT_WIDTH , this -> DEFAULT_HEIGHT );

	this -> set_events( GDK_BUTTON_PRESS_MASK
			    | GDK_BUTTON_RELEASE_MASK
			    | GDK_KEY_PRESS_MASK
			    | GDK_KEY_RELEASE_MASK );

	//
	// drop window
	//
	drop_menu_vbox.pack_start( free_kick_left_button );
	drop_menu_vbox.pack_start( drop_ball_button );
	drop_menu_vbox.pack_start( free_kick_right_button );

	drop_ball_button      .show();
	free_kick_left_button .show();
	free_kick_right_button.show();

	drop_ball_button      .set_usize( 200 , 50 );
	free_kick_left_button .set_usize( 200 , 50 );
	free_kick_right_button.set_usize( 200 , 50 );

	drop_ball_button.released.connect
		( SigC::slot( this , &Field_Canvas::drop_ball ) );

	free_kick_left_button.released.connect
		( SigC::slot( this , &Field_Canvas::free_kick_left ) );

	free_kick_right_button.released.connect
		( SigC::slot( this , &Field_Canvas::free_kick_right ) );

	drop_menu_window.add( drop_menu_vbox );
	drop_menu_vbox.show();
}

Field_Canvas::~Field_Canvas()
{
}

void   Field_Canvas::view_change( gdouble  view_point_x ,
				  gdouble  view_point_y ,
				  gdouble  mag ,
				  bool  inv_x ,
				  bool  inv_y )
{
	this -> ratio = 1.0 / mag;
	this -> center_x = view_point_x;
	this -> center_y = view_point_y;
	this -> inverse_x = inv_x;
	this -> inverse_y = inv_y;

	this -> configure();
}


void   Field_Canvas::gc_font_initialize()
{
	//
	// GC
	//
	ground_gc.create( get_window() , "indianred" );
	frame_gc .create( get_window() , "antique white" );

	field_gc .create( get_window() , "forestgreen" );
	line_gc  .create( get_window() , "white" );
	goal_gc  .create( get_window() , "black" );
	window_gc.create( get_window() , "white" );

	grid_gc  .create( get_window() , "dark slate gray" );

	ball_gc        .create( get_window() , "white"      );
	debug_ball_gc  .create( get_window() , "royal blue" );
	ball_edge_gc   .create( get_window() , "black"      );
	ball_comment_gc.create( get_window() , "black"      );

	left_field_player_gc            .create( get_window() , "gold"       );
	left_goalie_gc                  .create( get_window() , "green"      );
	right_field_player_gc           .create( get_window() , "red"        );
	right_goalie_gc                 .create( get_window() , "purple"     );
	self_player_gc                  .create( get_window() , "royal blue" );
	unknown_player_gc               .create( get_window() , "gray"       );
	player_bg_gc                    .create( get_window() , "black"      );
	left_player_uniform_number_gc   .create( get_window() , "indian red" );
	right_player_uniform_number_gc  .create( get_window() , "gray"       );
	unknown_player_uniform_number_gc.create( get_window() , "gray"       );
	catch_fault_gc                  .create( get_window() , "gray"       );
#if 0
	popup_gc                        .create( get_window() , "gray"   );
#endif
	popup_string_gc                 .create( get_window() , "white"  );


	//
	// Font
	//
	uniform_number_font.load( "9x15bold" );
	comment_font.load( "9x15bold" );

	popup_font.load
		( "-adobe-helvetica-*-r-normal--24-240-75-75-p-*-iso8859-1" );

	gc_font_initialized = true;
}


gint   Field_Canvas::configure()
{
	if ( ! gc_font_initialized )
	{
		gc_font_initialize();
	}

	if ( config.auto_adjust_magnify )
	{
		config.field_magnify
		= std::min( static_cast<gdouble>( width() ) / DEFAULT_WIDTH ,
			    static_cast<gdouble>( height() ) / DEFAULT_HEIGHT )
			* DEFAULT_MAGNIFY;

		this -> ratio = 1.0 / config.field_magnify;

		// config_changed message will passing to field_view
		// in end of this method.
	}

	//
	// new field_environment_pixmap
	//
	field_environment_pixmap.create( this -> center_x , this -> center_y ,
					 this -> ratio ,
					 this -> inverse_x ,
					 this -> inverse_y ,
					 get_window() , width() , height() );


	//
	// draw field environment
	//
	draw_field_environment_to_pixmap( field_environment_pixmap );


	//
	// new pixmap
	//
	pixmap.entity().set_background( field_environment_pixmap.entity() );

	pixmap.create( this -> center_x , this -> center_y , this -> ratio ,
		       this -> inverse_x , this -> inverse_y ,
		       get_window() , width() , height() );


	//
	// draw background
	//
	this -> get_window().set_back_pixmap(
			     field_environment_pixmap.entity() , false );


	//
	// calculate auto_kick_off and auto_drop message position
	//
	{
		const string	numbers = "0123456789";
		for( size_t  i = 0  ;  i < numbers.length()  ;  i ++ )
		{
			gint	w = popup_font.char_width( numbers[i] );
			if ( w > this -> max_number_char_width )
			{
				this -> max_number_char_width = w;
			}
		}

		gint	lbearing;
		gint	rbearing;
		gint	text_width;
		gint	ascent;
		gint	descent;

		const string	auto_kick_off_string = "Auto Kick Off: ";

		popup_font.string_extents( auto_kick_off_string ,
					   lbearing , rbearing ,
					   text_width ,
					   ascent , descent );

		this -> auto_kick_off_message_width = rbearing - lbearing;

		this -> auto_kick_off_message_x
			  = width() - 3
			    - (this -> auto_kick_off_message_width)
			    - (this -> max_number_char_width)
				* View_Controller::MAX_AUTO_KICK_OFF_COLUMN;

		this -> auto_kick_off_message_y = height() - 8;


		const string	auto_drop_string = "Auto Drop: ";

		popup_font.string_extents( auto_drop_string ,
					   lbearing , rbearing ,
					   text_width ,
					   ascent , descent );

		this -> auto_drop_message_width = rbearing - lbearing;

		this -> auto_drop_message_x
			  = width() - 3
			    - (this -> auto_drop_message_width)
			    - (this -> max_number_char_width)
				* View_Controller::MAX_AUTO_DROP_COLUMN;

		this -> auto_drop_message_y = height() - 8;
	}

	// if config.auto_adjust_magnify is true,
	// config.field_magnify is already changed in this method.
	if ( config.auto_adjust_magnify )
	{
		field_view.config_changed();
	}

	return( true );
}

gint   Field_Canvas::configure_event_impl( GdkEventConfigure * )
{
	this -> configure();

	this -> field_view.display();

	get_window().draw_pixmap( pixmap.entity().gc() ,
				  pixmap.entity() ,
				  0 , 0 ,
				  0 , 0 ,
				  width() , height() );
	pixmap.entity().drawn();

	return( true );
}

gint   Field_Canvas::expose_event_impl( GdkEventExpose *  event )
{
	if ( event -> count == 0 )
	{
		get_window().draw_pixmap( pixmap.entity().gc() ,
					  pixmap.entity() ,
					  0 , 0 ,
					  0 , 0 ,
					  width() , height() );
		pixmap.entity().drawn();
	}

	return( false );
}



gint   Field_Canvas::button_press_event_impl( GdkEventButton *  event )
{
	if ( event -> button == 1 )
	{
		drop_point.set( pixmap.x_pixel_to_coordinate( event -> x ) ,
				pixmap.y_pixel_to_coordinate( event -> y ) );

		drop_menu_window.set_position( GTK_WIN_POS_MOUSE );
		drop_menu_window.show();
	}

	return( false );
}

gint   Field_Canvas::button_release_event_impl( GdkEventButton *  event )
{
	if ( event -> button == 1 )
	{
		drop_menu_window.hide();
	}

	return( false );
}


void   Field_Canvas::clear_field()
{
	pixmap.entity().clear();
}


void   Field_Canvas::draw_grid( double  grid_length )
{
	this -> draw_grid_to_pixmap( pixmap , grid_length );
}

void   Field_Canvas::draw_monitor_view( const Monitor_View &  monitor_view ,
					const View_Config &  config )
{
	for( int  i = 0  ;  i < MAX_PLAYER * 2  ;  i ++ )
	{
		this -> draw_player_to_pixmap( pixmap , config ,
					       monitor_view.player[i] );
	}

	this -> draw_ball_to_pixmap( pixmap , config , monitor_view.ball ,
				     monitor_view.play_mode );

	this -> draw_popup_to_pixmap( pixmap , config ,
				      monitor_view.play_mode ,
				      monitor_view.team[0].team_name ,
				      monitor_view.team[1].team_name );
}

void   Field_Canvas::draw_auto_kick_off_count_down
				( long  auto_kick_off_rest_count )
{
	this -> draw_auto_kick_off_count_down_to_pixmap
				( pixmap , auto_kick_off_rest_count );
}

void   Field_Canvas::draw_auto_drop_count_down
				( long  auto_drop_rest_count )
{
	this -> draw_auto_drop_count_down_to_pixmap
				( pixmap , auto_drop_rest_count );
}

void   Field_Canvas::draw_user_debug_ball( const Ball_Reference &  ball ,
					   S_Side_LR  self_side ,
					   const View_Config &  config ,
					   const char *  comment )
{
	D2_Vector	ball_coordinate;

	switch( self_side )
	{
	case S_Side_LR::Left_Side:
		ball_coordinate = (+ ball.coordinate());
		break;

	case S_Side_LR::Right_Side:
		ball_coordinate = (- ball.coordinate());
		break;

	case S_Side_LR::Unknown:
	default:
		// error
		return;
		break;
	}

	this -> draw_ball_to_pixmap( pixmap , config , ball_coordinate ,
				     Monitor_View::Monitor_Play_Mode::Play_On ,
				     true ,
				     comment );
}

void   Field_Canvas::draw_user_debug_player( const Player_Reference &  player ,
					     S_Side_LR  self_side ,
					     bool  self_player ,
					     const View_Config &  config ,
					     const char *  comment )
{
	Monitor_View::Player_State	state;

	state.set_valid( true );

	state.set_side( player.side_lr() );

	state.set_uniform_number( (player.player_number() == (-1)) ?
				  0 : player.player_number() );

	switch( self_side )
	{
	case S_Side_LR::Left_Side:
		if ( player.body_angle().accuracy_check() )
		{
			state.set_body_angle( player.body_angle() );
		}
		else
		{
			state.set_body_angle( Degree(0.0) );
		}
		state.set_x( player.coordinate().x() );
		state.set_y( player.coordinate().y() );
		break;

	case S_Side_LR::Right_Side:
		if ( player.body_angle().accuracy_check() )
		{
			state.set_body_angle( (player.body_angle()
					       - Degree(180.0)).normalize() );
		}
		else
		{
			state.set_body_angle( Degree(-180.0) );
		}
		state.set_x( - player.coordinate().x() );
		state.set_y( - player.coordinate().y() );
		break;

	case S_Side_LR::Unknown:
	default:
		// error
		return;
		break;
	}

	this -> draw_player_to_pixmap( pixmap , config , state ,
				       true , self_player , comment );
}


void   Field_Canvas::update_field()
{
	this -> draw( Gdk_Rectangle( 0 , 0 ,
				     this -> width() , this -> height() ) );
}

void   Field_Canvas::draw_grid_to_pixmap
			( Coordinate_View_Pixmap<Transparent_Pixmap> &  pix ,
			  gdouble  grid_width )
{
	gint	min_x = static_cast<gint>( pix.min_x() / grid_width );
	gint	max_x = static_cast<gint>( pix.max_x() / grid_width );
	gint	min_y = static_cast<gint>( pix.min_y() / grid_width );
	gint	max_y = static_cast<gint>( pix.max_y() / grid_width );

	for ( gint  x = min_x  ;  x <= max_x  ; x ++ )
	{
		pix.draw_line_absolute( grid_gc ,
					x * grid_width , pix.min_y() ,
					x * grid_width , pix.max_y() );
	}

	for ( gint  y = min_y  ;  y <= max_y  ; y ++ )
	{
		pix.draw_line_absolute( grid_gc ,
					pix.min_x() , y * grid_width ,
					pix.max_x() , y * grid_width );
	}
}

void   Field_Canvas::draw_ball_to_pixmap
	 ( Coordinate_View_Pixmap<Transparent_Pixmap> &  pix ,
	   const View_Config &  config ,
	   const D2_Vector &  ball ,
	   const Monitor_View::Monitor_Play_Mode &  mode ,
	   bool  for_debug ,
	   const char *  comment )
{
	Gdk_GC *	gc;

	if ( ! for_debug )
	{
		switch( mode )
		{
		case Monitor_View::Monitor_Play_Mode::Kick_In_Left:
		case Monitor_View::Monitor_Play_Mode::Corner_Kick_Left:
		case Monitor_View::Monitor_Play_Mode::Free_Kick_Left:
		case Monitor_View::Monitor_Play_Mode::Offside_Right:
			gc = &left_field_player_gc;
			break;

		case Monitor_View::Monitor_Play_Mode::Kick_In_Right:
		case Monitor_View::Monitor_Play_Mode::Corner_Kick_Right:
		case Monitor_View::Monitor_Play_Mode::Free_Kick_Right:
		case Monitor_View::Monitor_Play_Mode::Offside_Left:
			gc = &right_field_player_gc;
			break;

		default:
			gc = &ball_gc;
			break;
		}
	}
	else
	{
		gc = &debug_ball_gc;
	}

	// ball
	pix.draw_arc_absolute_another_interface
		( *gc ,
		  true ,
		  ball.x() , ball.y() ,
		  config.ball_size , config.ball_size ,
		  0.0 , 360.0 );

	// ball edge
	pix.draw_arc_absolute_another_interface
		( ball_edge_gc ,
		  false ,
		  ball.x() , ball.y() ,
		  config.ball_size , config.ball_size ,
		  0.0 , 360.0 );

	// comment
	if ( comment )
	{
		gint	lbearing;
		gint	rbearing;
		gint	text_width;
		gint	ascent;
		gint	descent;

		comment_font.string_extents( comment ,
					     lbearing , rbearing ,
					     text_width ,
					     ascent , descent );

		pix.entity().draw_string(
			comment_font ,
			ball_comment_gc ,
			pix.x_coordinate_to_pixel
			  ( ball.x()
			    + config.ball_size * (inverse_x ? (-1) : (1)) )
			 - rbearing ,
			pix.y_coordinate_to_pixel
			 ( ball.y()
			   - config.ball_size * (inverse_y ? (-1) : (1)) ) ,
			comment );
	}
}

void   Field_Canvas::draw_player_to_pixmap
	 ( Coordinate_View_Pixmap<Transparent_Pixmap> &  pix ,
	   const View_Config &  config ,
	   const Monitor_View::Player_State &  player ,
	   bool  for_debug ,  bool  self_player ,
	   const char *  comment )
{
	if ( ! player.valid() )
	{
		return;
	}


	Gdk_GC *	gc = &unknown_player_gc;
	Gdk_GC *	font_gc = &unknown_player_gc;

	switch( player.side() )
	{
	case S_Side_LR::Left_Side:
		if ( player.goalie() )
		{
			gc = &left_goalie_gc;
		}
		else
		{
			gc = &left_field_player_gc;
		}

		font_gc = &left_player_uniform_number_gc;
		break;

	case S_Side_LR::Right_Side:
		if ( player.goalie() )
		{
			gc = &right_goalie_gc;
		}
		else
		{
			gc = &right_field_player_gc;
		}

		font_gc = &right_player_uniform_number_gc;
		break;

	case S_Side_LR::Unknown:
		gc = &unknown_player_gc;
		font_gc = &unknown_player_uniform_number_gc;
		break;
	}


	if ( for_debug )
	{
		if ( self_player )
		{
			gc = &self_player_gc;
		}

		// draw front body
		pix.draw_arc_absolute_another_interface(
			*gc ,
			true ,
			player.x() , player.y() ,
			config.player_size , config.player_size ,
			player.body_angle().normalize().degree() - 90.0 ,
			180.0 );

		// draw edge
		pix.draw_arc_absolute_another_interface(
			*gc ,
			false ,
			player.x() , player.y() ,
			config.player_size , config.player_size ,
			0.0 , 360.0 );
	}
	else
	{
		// fill black
		pix.draw_arc_absolute_another_interface(
			player_bg_gc ,
			true ,
			player.x() , player.y() ,
			config.player_size , config.player_size ,
			0.0 , 360.0 );

		// draw front body
		pix.draw_arc_absolute_another_interface(
			*gc ,
			true ,
			player.x() , player.y() ,
			config.player_size , config.player_size ,
			player.body_angle().normalize().degree() - 90.0 ,
			180.0 );

		// draw edge
		pix.draw_arc_absolute_another_interface(
			*gc ,
			false ,
			player.x() , player.y() ,
			config.player_size , config.player_size ,
			0.0 , 360.0 );


		if ( player.kicking() )
		{
			pix.draw_arc_absolute_another_interface(
				*gc ,
				true ,
				player.x() , player.y() ,
				config.player_size ,
				config.player_size ,
				0.0 , 360.0 );

			pix.draw_arc_absolute_another_interface(
				player_bg_gc ,
				true ,
				player.x() , player.y() ,
				config.player_size * (3.0 / 4.0) ,
				config.player_size * (3.0 / 4.0) ,
				player.body_angle().normalize().degree()
				  + 90.0 ,
				180.0 );

			pix.draw_arc_absolute_another_interface(
				*gc ,
				true ,
				player.x() , player.y() ,
				config.player_size * (1.0 / 2.0) ,
				config.player_size * (1.0 / 2.0) ,
				0.0 , 360.0 );

			pix.draw_arc_absolute_another_interface(
				*gc ,
				false ,
				player.x() , player.y() ,
				config.player_size * (5.0 / 8.0) ,
				config.player_size * (5.0 / 8.0) ,
				0.0 , 360.0 );
		}

		if ( player.kick_fault() )
		{
			pix.draw_arc_absolute_another_interface(
				player_bg_gc ,
				true ,
				player.x() , player.y() ,
				config.player_size , config.player_size ,
				0.0 , 360.0 );

			pix.draw_arc_absolute_another_interface(
				*gc ,
				false ,
				player.x() , player.y() ,
				config.player_size , config.player_size ,
				0.0 , 360.0 );
		}

		if ( player.catching() )
		{
			pix.draw_arc_absolute_another_interface(
				*gc ,
				true ,
				player.x() , player.y() ,
				config.player_size , config.player_size ,
				0.0 , 360.0 );
		}

		if ( player.catch_fault() )
		{
			pix.draw_arc_absolute_another_interface(
				catch_fault_gc ,
				true ,
				player.x() , player.y() ,
				config.player_size , config.player_size ,
				0.0 , 360.0 );

			pix.draw_arc_absolute_another_interface(
				*gc ,
				false ,
				player.x() , player.y() ,
				config.player_size , config.player_size ,
				0.0 , 360.0 );
		}
	}


	// draw uniform number
	{
		gchar	buf[ sizeof(gint) * CHAR_BIT + strlen("-") + 1 ];

		sprintf( buf , "%d" , player.uniform_number() );

		gint	lbearing;
		gint	rbearing;
		gint	text_width;
		gint	ascent;
		gint	descent;

		uniform_number_font.string_extents( buf ,
						    lbearing , rbearing ,
						    text_width ,
						    ascent , descent );

		pix.entity().draw_string(
			uniform_number_font ,
			*font_gc ,
			pix.x_coordinate_to_pixel
			  ( player.x()
			    + config.player_size * (inverse_x ? (-1) : (1)) )
			  - rbearing ,
			pix.y_coordinate_to_pixel( player.y() ) ,
			buf );
	}

	// draw comment
	if ( comment )
	{
		gint	lbearing;
		gint	rbearing;
		gint	text_width;
		gint	ascent;
		gint	descent;

		comment_font.string_extents( comment ,
					     lbearing , rbearing ,
					     text_width ,
					     ascent , descent );

		pix.entity().draw_string(
			comment_font ,
			*font_gc ,
			pix.x_coordinate_to_pixel
			  ( player.x()
			    + config.player_size * (inverse_x ? (-1) : (1)) )
			 - rbearing ,
			pix.y_coordinate_to_pixel
			 ( player.y()
			   - config.player_size * (inverse_y ? (-1) : (1)) ) ,
			comment );
	}
}

void   Field_Canvas::draw_offside_line( const Monitor_View &  monitor_view ,
					const View_Config &  config )
{
	std::multiset<gdouble>	left_x_list;
	std::multiset<gdouble>	right_x_list;

	for ( int i = 0  ;  i < SServer_Monitor_Log_Format::MAX_PLAYER * 2  ;
	      i ++ )
	{
		const Monitor_View::Player_State &
			player = monitor_view.player[i];

		if ( player.valid() )
		{
			S_Side_LR	s = player.side();

			if ( s == S_Side_LR::Left_Side )
			{
				left_x_list.insert( player.x() );
			}
			else if ( s == S_Side_LR::Right_Side )
			{
				right_x_list.insert( player.x() );
			}
		}
	}


	//
	// Left Team Offside Line
	//
	gdouble	left_defencive_offside_line = 0.0;

	if ( left_x_list.size() >= 2 )
	{
		std::multiset<gdouble>::iterator	it;
		it = left_x_list.begin();
		it ++;

		if ( (*it) < left_defencive_offside_line )
		{
			left_defencive_offside_line = (*it);
		}
	}

	if ( monitor_view.ball.x() < left_defencive_offside_line )
	{
		left_defencive_offside_line = monitor_view.ball.x();
	}

	pixmap.draw_line_absolute
		       ( left_field_player_gc ,
			 left_defencive_offside_line , - FIELD_HALF_WIDTH ,
			 left_defencive_offside_line , + FIELD_HALF_WIDTH );


	//
	// Right Team Offside Line
	//
	gdouble	right_defencive_offside_line = 0.0;

	if ( right_x_list.size() >= 2 )
	{
		std::multiset<gdouble>::iterator	it;
		it = right_x_list.end();
		it --;
		it --;

		if ( (*it) > right_defencive_offside_line )
		{
			right_defencive_offside_line = (*it);
		}
	}

	if ( monitor_view.ball.x() > right_defencive_offside_line )
	{
		right_defencive_offside_line = monitor_view.ball.x();
	}

	pixmap.draw_line_absolute
		       ( right_field_player_gc ,
			 right_defencive_offside_line , - FIELD_HALF_WIDTH ,
			 right_defencive_offside_line , + FIELD_HALF_WIDTH );
}

void   Field_Canvas::draw_popup_to_pixmap
	 ( Coordinate_View_Pixmap<Transparent_Pixmap> &  pix ,
	   const View_Config &  config ,
	   const Monitor_View::Monitor_Play_Mode &  mode ,
	   const string &  left_teamname ,
	   const string &  right_teamname )
{
	if ( mode == Monitor_View::Monitor_Play_Mode::Offside_Left
	  || mode == Monitor_View::Monitor_Play_Mode::Offside_Right
	  || mode == Monitor_View::Monitor_Play_Mode::Goal_Left
	  || mode == Monitor_View::Monitor_Play_Mode::Goal_Right )
	{
#if 0
		//
		// draw pseudo popup window
		//
		pix.entity().draw_rectangle(
			popup_gc ,
			true ,
			width() * (3.0 / 7.0) , height() * (2.0 / 7.0) ,
			width() * (1.0 / 7.0) , height() * (3.0 / 7.0) );
#endif

		//
		// draw message
		//
		string	popup_message;

		if ( mode == Monitor_View::Monitor_Play_Mode::Offside_Left )
		{
			if ( config.use_teamname
			     && left_teamname.length() != 0 )
			{
#if 0
				popup_message = string("Offside \"")
						+ left_teamname + "\" !!";
#else
				popup_message = string("Offside ")
						+ left_teamname + " !!";
#endif
			}
			else
			{
				popup_message = "Offside Left !!";
			}
		}
		else if( mode
			   == Monitor_View::Monitor_Play_Mode::Offside_Right )
		{
			if ( config.use_teamname
			     && right_teamname.length() != 0 )
			{
#if 0
				popup_message = string("Offside \"")
						+ right_teamname + "\" !!";
#else
				popup_message = string("Offside ")
						+ right_teamname + " !!";
#endif
			}
			else
			{
				popup_message = "Offside Right !!";
			}
		}
		else if ( mode == Monitor_View::Monitor_Play_Mode::Goal_Left
		       || mode == Monitor_View::Monitor_Play_Mode::Goal_Right )
		{
			popup_message = "GOAL !!";
		}

		gint	lbearing;
		gint	rbearing;
		gint	text_width;
		gint	ascent;
		gint	descent;

		popup_font.string_extents( popup_message ,
					   lbearing , rbearing ,
					   text_width ,
					   ascent , descent );

		gint	message_width  = lbearing + rbearing;
		gint	message_height = ascent + descent;

		pix.entity().draw_string(
		      popup_font ,
		      popup_string_gc ,
		      (pix.width() / 2.0) - (message_width / 2.0) ,
		      (pix.height() / 2.0) - (message_height / 2.0) + ascent ,
		      popup_message );
	}
}

void   Field_Canvas::draw_auto_kick_off_count_down_to_pixmap(
			  Coordinate_View_Pixmap<Transparent_Pixmap> &  pix ,
			  long  auto_kick_off_rest_count )
{
	//
	// draw "Auto Kick Off: "
	//
	const string	auto_kick_off_string = "Auto Kick Off: ";

	pix.entity().draw_string(
		popup_font ,
		popup_string_gc ,
		this -> auto_kick_off_message_x ,
		this -> auto_kick_off_message_y ,
		auto_kick_off_string );


	//
	// draw count down number
	//
	gchar	num[ sizeof(gint) * CHAR_BIT + strlen("-") + 1 ];
	sprintf( num , "%ld" ,
		 static_cast<long>(auto_kick_off_rest_count) );

	gint	padding	= std::max( View_Controller::MAX_AUTO_KICK_OFF_COLUMN
				    - static_cast<gint>( strlen( num ) ) - 1 ,
				    0 );

	pix.entity().draw_string(
		popup_font ,
		popup_string_gc ,
		(this -> auto_kick_off_message_x)
		  + (this -> auto_kick_off_message_width)
		  + (this -> max_number_char_width) * padding ,
		this -> auto_kick_off_message_y ,
		num );
}

void   Field_Canvas::draw_auto_drop_count_down_to_pixmap(
			  Coordinate_View_Pixmap<Transparent_Pixmap> &  pix ,
			  long  auto_drop_rest_count )
{
	//
	// draw "Auto Kick Off: "
	//
	const string	auto_drop_string = "Auto Drop: ";

	pix.entity().draw_string(
		popup_font ,
		popup_string_gc ,
		this -> auto_drop_message_x ,
		this -> auto_drop_message_y ,
		auto_drop_string );


	//
	// draw count down number
	//
	gchar	num[ sizeof(gint) * CHAR_BIT + strlen("-") + 1 ];
	sprintf( num , "%ld" ,
		 static_cast<long>(auto_drop_rest_count) );

	gint	padding	= std::max( View_Controller::MAX_AUTO_DROP_COLUMN
				    - static_cast<gint>( strlen( num ) ) - 1 ,
				    0 );

	pix.entity().draw_string(
		popup_font ,
		popup_string_gc ,
		(this -> auto_drop_message_x)
		  + (this -> auto_drop_message_width)
		  + (this -> max_number_char_width) * padding ,
		this -> auto_drop_message_y ,
		num );
}

void   Field_Canvas::draw_field_environment_to_pixmap
	 ( Coordinate_View_Pixmap<Gdk_Pixmap> &  pix )
{
	// ground
	pix.entity().draw_rectangle( ground_gc ,
				     true ,
				     0 , 0 ,
				     width() , height() );

	// field
	pix.draw_rectangle_absolute_another_interface(
				 field_gc ,
				 true ,
				 - FIELD_HALF_LENGTH , - FIELD_HALF_WIDTH ,
				 + FIELD_HALF_LENGTH , + FIELD_HALF_WIDTH );

	// field line
	pix.draw_rectangle_absolute_another_interface(
		line_gc ,
		false ,
		- FIELD_HALF_LENGTH , - FIELD_HALF_WIDTH ,
		+ FIELD_HALF_LENGTH , + FIELD_HALF_WIDTH );

	// goal(Left)
	pix.draw_rectangle_absolute_another_interface(
		goal_gc ,
		true ,
		- FIELD_HALF_LENGTH - 3.0 , - param.GOAL_WIDTH() / 2.0 ,
		- FIELD_HALF_LENGTH       , + param.GOAL_WIDTH() / 2.0 );

	// goal(Right)
	pix.draw_rectangle_absolute_another_interface(
		goal_gc ,
		true ,
		+ FIELD_HALF_LENGTH ,       - param.GOAL_WIDTH() / 2.0 ,
		+ FIELD_HALF_LENGTH + 3.0 , + param.GOAL_WIDTH() / 2.0 );

	// center circle
	pix.draw_arc_absolute_another_interface(
		line_gc ,
		false ,
		0.0 , 0.0 ,
		CENTER_CIRCLE_R , CENTER_CIRCLE_R ,
		0.0 , 360.0 );

	// center line
	pix.draw_line_absolute( line_gc ,
				0.0 , - FIELD_HALF_WIDTH ,
				0.0 , + FIELD_HALF_WIDTH );

	// penalty area(Left)
	pix.draw_rectangle_absolute_another_interface(
		line_gc ,
		false ,
		- FIELD_HALF_LENGTH ,
		- PENALTY_AREA_HALF_WIDTH ,
		- (FIELD_HALF_LENGTH - PENALTY_AREA_LENGTH) ,
		+ PENALTY_AREA_HALF_WIDTH );

	// penalty area(Right)
	pix.draw_rectangle_absolute_another_interface(
		line_gc ,
		false ,
		+ (FIELD_HALF_LENGTH -  PENALTY_AREA_LENGTH) ,
		- PENALTY_AREA_HALF_WIDTH ,
		+ FIELD_HALF_LENGTH ,
		+ PENALTY_AREA_HALF_WIDTH );

	// goal area(Left)
	pix.draw_rectangle_absolute_another_interface(
		line_gc ,
		false ,
		- FIELD_HALF_LENGTH ,
		- GOAL_AREA_HALF_WIDTH ,
		- (FIELD_HALF_LENGTH - GOAL_AREA_LENGTH) ,
		+ GOAL_AREA_HALF_WIDTH );

	// goal area(Right)
	pix.draw_rectangle_absolute_another_interface(
		line_gc ,
		false ,
		+ (FIELD_HALF_LENGTH -  GOAL_AREA_LENGTH) ,
		- GOAL_AREA_HALF_WIDTH ,
		+ FIELD_HALF_LENGTH ,
		+ GOAL_AREA_HALF_WIDTH );

	// penalty area arc(Left)
	pix.draw_arc_absolute_another_interface(
		line_gc ,
		false ,
		- (FIELD_HALF_LENGTH - PENALTY_SPOT_DIST) , 0.0 ,
		CENTER_CIRCLE_R , CENTER_CIRCLE_R ,
		- PENALTY_ARC_DIGREE , PENALTY_ARC_DIGREE * 2.0 );

	// penalty area arc(Right)
	pix.draw_arc_absolute_another_interface(
		line_gc ,
		false ,
		+ (FIELD_HALF_LENGTH - PENALTY_SPOT_DIST) , 0.0 ,
		CENTER_CIRCLE_R , CENTER_CIRCLE_R ,
		- PENALTY_ARC_DIGREE + 180.0 , PENALTY_ARC_DIGREE * 2.0 );

	// corner arc(Left Top)
	pix.draw_arc_absolute_another_interface
		( line_gc ,
		  false ,
		  - FIELD_HALF_LENGTH , FIELD_HALF_WIDTH ,
		  CORNER_CIRCLE_R , CORNER_CIRCLE_R ,
		  270.0 , 90.0 );

	// corner arc(Left Bottom)
	pix.draw_arc_absolute_another_interface
		( line_gc ,
		  false ,
		  - FIELD_HALF_LENGTH , - FIELD_HALF_WIDTH ,
		  CORNER_CIRCLE_R , CORNER_CIRCLE_R ,
		  0.0 , 90.0 );

	// corner arc(Right Top)
	pix.draw_arc_absolute_another_interface
		( line_gc ,
		  false ,
		  + FIELD_HALF_LENGTH , + FIELD_HALF_WIDTH ,
		  CORNER_CIRCLE_R , CORNER_CIRCLE_R ,
		  180.0 , 90.0 );

	// corner arc(Right Bottom)
	pix.draw_arc_absolute_another_interface
		( line_gc ,
		  false ,
		  + FIELD_HALF_LENGTH , - FIELD_HALF_WIDTH ,
		  CORNER_CIRCLE_R , CORNER_CIRCLE_R ,
		  90.0 , 90.0 );

	// corner arc(Right Bottom)
	pix.entity().draw_rectangle
		( frame_gc ,
		  false ,
		  0 ,
		  0 ,
		  std::min<gint>( pix.width()  - 1 , 0 ) ,
		  std::min<gint>( pix.height() - 1 , 0 ) );
}


//
// drop_ball button callback
//
void   Field_Canvas::drop_ball()
{
	drop_menu_window.hide();

	controller.send_foul( drop_point.x() , drop_point.y() ,
			      S_Side_LR::Unknown , true );
}

//
// free_kick_left_button callback
//
void   Field_Canvas::free_kick_left()
{
	drop_menu_window.hide();

	controller.send_foul( drop_point.x() , drop_point.y() ,
			      S_Side_LR::Left_Side , true );
}

//
// free_kick_right_button callback
//
void   Field_Canvas::free_kick_right()
{
	drop_menu_window.hide();

	controller.send_foul( drop_point.x() , drop_point.y() ,
			      S_Side_LR::Right_Side , true );
}
