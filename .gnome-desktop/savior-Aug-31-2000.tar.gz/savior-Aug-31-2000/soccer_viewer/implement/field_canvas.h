#ifndef	   FIELD_CANVAS_H_INCLUDED
#define	   FIELD_CANVAS_H_INCLUDED

#include  <gtk--.h>
#include  <string>
#include  "sserver_param.h"
#include  "view_controller.h"
#include  "view_config.h"
#include  "monitor_view.h"
#include  "field_recog_interface.h"
#include  "coordinate_view_pixmap.h"
#include  "transparent_pixmap.h"
#include  "gdk_gc_wrapper.h"

class  Field_View;


class  Field_Canvas : public Gtk::DrawingArea
{
public:
	static	const	gint	DEFAULT_WIDTH;
	static	const	gint	DEFAULT_HEIGHT;
	static	const	gdouble	DEFAULT_MAGNIFY;

protected:
	static	const	gdouble	FIELD_HALF_WIDTH;
	static	const	gdouble	FIELD_HALF_LENGTH;
	static	const	gdouble	FIELD_WIDTH;
	static	const	gdouble	FIELD_LENGTH;
	static	const	gdouble	PENALTY_AREA_LENGTH;
	static	const	gdouble	PENALTY_AREA_HALF_WIDTH;
	static	const	gdouble	GOAL_AREA_LENGTH;
	static	const	gdouble	GOAL_AREA_HALF_WIDTH;
	static	const	gdouble	CENTER_CIRCLE_R;
	static	const	gdouble	CORNER_CIRCLE_R;
	static	const	gdouble	PENALTY_SPOT_DIST;

protected:
	const	gdouble		PENALTY_ARC_DIGREE;


protected:
	View_Config &			config;
	const SServer_Param &		param;
	View_Controller &		controller;
	Field_View &			field_view;

	gdouble				ratio;
	gdouble				center_x;
	gdouble				center_y;
	bool				inverse_x;
	bool				inverse_y;

protected:
	Coordinate_View_Pixmap<Gdk_Pixmap>	field_environment_pixmap;
	Coordinate_View_Pixmap<Transparent_Pixmap>	pixmap;

	Gdk_GC_Wrapper			window_gc;
	Gdk_GC_Wrapper			frame_gc;

	Gdk_GC_Wrapper			ground_gc;
	Gdk_GC_Wrapper			field_gc;
	Gdk_GC_Wrapper			line_gc;
	Gdk_GC_Wrapper			goal_gc;
	Gdk_GC_Wrapper			grid_gc;


	// XXX
	Gdk_GC_Wrapper			ball_gc;
	// XXX
	Gdk_GC_Wrapper			debug_ball_gc;
	Gdk_GC_Wrapper			ball_edge_gc;
	Gdk_GC_Wrapper			ball_comment_gc;

	Gdk_GC_Wrapper			left_field_player_gc;
	Gdk_GC_Wrapper			left_goalie_gc;
	Gdk_GC_Wrapper			right_field_player_gc;
	Gdk_GC_Wrapper			right_goalie_gc;
	Gdk_GC_Wrapper			self_player_gc;
	Gdk_GC_Wrapper			unknown_player_gc;
	Gdk_GC_Wrapper			player_bg_gc;
	Gdk_GC_Wrapper			left_player_uniform_number_gc;
	Gdk_GC_Wrapper			right_player_uniform_number_gc;
	Gdk_GC_Wrapper			unknown_player_uniform_number_gc;
	Gdk_GC_Wrapper			catch_fault_gc;

	Gdk_Font			uniform_number_font;
	Gdk_Font			comment_font;

#if 0
	Gdk_GC_Wrapper			popup_gc;
#endif
	Gdk_GC_Wrapper			popup_string_gc;
	Gdk_Font			popup_font;

	gint				max_number_char_width;
	gint				auto_kick_off_message_x;
	gint				auto_kick_off_message_y;
	gint				auto_kick_off_message_width;
	gint				auto_drop_message_x;
	gint				auto_drop_message_y;
	gint				auto_drop_message_width;

	bool				gc_font_initialized;

protected:
	virtual	void	gc_font_initialize();

	virtual	void	draw_field_environment_to_pixmap(
			  Coordinate_View_Pixmap<Gdk_Pixmap> &  pix );

	virtual	void	draw_grid_to_pixmap(
			  Coordinate_View_Pixmap<Transparent_Pixmap> &  pix ,
			  gdouble  grid_width );

	virtual	void	draw_ball_to_pixmap(
			  Coordinate_View_Pixmap<Transparent_Pixmap> &  pix ,
			  const View_Config &  config ,
			  const D2_Vector &  ball ,
			  const Monitor_View::Monitor_Play_Mode &  mode ,
			  bool  for_debug = false ,
			  const char *  comment = 0 );

	virtual	void	draw_player_to_pixmap(
			  Coordinate_View_Pixmap<Transparent_Pixmap> &  pix ,
			  const View_Config &  config ,
			  const Monitor_View::Player_State &  player ,
			  bool  for_debug = false ,
			  bool  self_player = false ,
			  const char *  comment = 0 );

	virtual	void	draw_popup_to_pixmap(
			  Coordinate_View_Pixmap<Transparent_Pixmap> &  pix ,
			  const View_Config &  config ,
			  const Monitor_View::Monitor_Play_Mode &  mode ,
			  const string &  left_teamname ,
			  const string &  right_teamname );

	virtual	void	draw_auto_kick_off_count_down_to_pixmap(
			  Coordinate_View_Pixmap<Transparent_Pixmap> &  pix ,
			  glong  auto_kick_off_rest_count );

	virtual	void	draw_auto_drop_count_down_to_pixmap(
			  Coordinate_View_Pixmap<Transparent_Pixmap> &  pix ,
			  glong  auto_drop_rest_count );

protected:
	Gtk::Window			drop_menu_window;
	Gtk::VBox			drop_menu_vbox;
	Gtk::Button			drop_ball_button;
	Gtk::Button			free_kick_left_button;
	Gtk::Button			free_kick_right_button;

	D2_Vector			drop_point;

	virtual	void	drop_ball();
	virtual	void	free_kick_left();
	virtual	void	free_kick_right();

public:
		 Field_Canvas( View_Controller &  controller ,
			       Field_View &  field_view ,
			       View_Config &  config ,
			       const SServer_Param &  param ,
			       gdouble  view_point_x = 0.0 ,
			       gdouble  view_point_y = 0.0 ,
			       gdouble  mag = DEFAULT_MAGNIFY ,
			       bool  inv_x = false ,
			       bool  inv_y = false );

	virtual	~Field_Canvas();

	virtual	void	view_change( gdouble  view_point_x = 0.0 ,
				     gdouble  view_point_y = 0.0 ,
				     gdouble  mag = DEFAULT_MAGNIFY ,
				     bool  inv_x = false ,
				     bool  inv_y = false );

	virtual	gint	configure();

	virtual	gint	configure_event_impl( GdkEventConfigure * );
	virtual	gint	expose_event_impl( GdkEventExpose *  event );
	virtual	gint	button_press_event_impl( GdkEventButton * );
	virtual	gint	button_release_event_impl( GdkEventButton * );
#if 0
	virtual	gint	key_press_event_impl( GdkEventKey *  event );
#endif

	virtual	void	clear_field();

	virtual	void	draw_grid( gdouble  grid_width );

	virtual	void	draw_monitor_view( const Monitor_View &  monitor_view ,
					   const View_Config &  config );

	virtual	void	draw_auto_kick_off_count_down
				( glong  auto_kick_off_rest_count );

	virtual	void	draw_auto_drop_count_down
				( glong  auto_drop_rest_count );

	virtual	void	draw_offside_line( const Monitor_View &  monitor_view ,
					   const View_Config &  config );

	virtual	void	draw_user_debug_ball( const Ball_Reference &  ball ,
					      S_Side_LR  self_side ,
					      const View_Config &  config ,
					      const char *  comment = 0 );

	virtual	void	draw_user_debug_player
				( const Player_Reference &  player ,
				  S_Side_LR  self_side ,
				  bool  self_player ,
				  const View_Config &  config ,
				  const char *  comment = 0 );

	virtual	void	update_field();
};


#endif	/* FIELD_CANVAS_H_INCLUDED */
