#include  "field_view.h"
#include  "field_recog_interface.h"

Field_View::Field_View( View_Controller &  controller ,
			View_Config &  config ,
			View_Controll_Panel &  panel )
	: controller( controller ) , config( config ) , panel( panel ) ,
	  canvas( controller , *this , config , controller.sserver_param() ,
		  0.0 , 0.0 , config.field_magnify ) ,
	  view_point_type( config.view_point.type ) ,
	  canvas_magnify( config.field_magnify ) ,
	  view_point_coordinate( config.view_point.coordinate ) ,
	  view_point_player( config.view_point.player ) ,
	  inverse_x( config.inverse_x ) , inverse_y( config.inverse_y ) ,
	  auto_adjust_magnify( config.auto_adjust_magnify ) ,
	  old_ball_coordinate( 0.0 , 0.0 )
{
	//
	// Field
	//
	canvas.show();
	this -> pack_start( canvas );


	//
	// this
	//
	this -> set_spacing( 5 );
	this -> show();
}

Field_View::~Field_View()
{
}

void   Field_View::config_changed()
{
	panel.config_changed();
}

void   Field_View::display()
{
	//
	// View Change
	//
	if ( config.view_point.type == View_Config::View_Point::Ball
	  || config.view_point.type == View_Config::View_Point::Player
	  || canvas_magnify != config.field_magnify
	  || view_point_type != config.view_point.type
	  || view_point_coordinate != config.view_point.coordinate
	  || view_point_player != config.view_point.player
	  || inverse_x != config.inverse_x
	  || inverse_y != config.inverse_y
	  || auto_adjust_magnify != config.auto_adjust_magnify )
	{
		canvas_magnify = config.field_magnify;
		view_point_type = config.view_point.type;
		view_point_coordinate = config.view_point.coordinate;
		view_point_player = config.view_point.player;
		inverse_x = config.inverse_x;
		inverse_y = config.inverse_y;
		auto_adjust_magnify = config.auto_adjust_magnify;

		switch( view_point_type )
		{
		case View_Config::View_Point::Point:
			canvas.view_change( config.view_point.coordinate.x() ,
					    config.view_point.coordinate.y() ,
					    config.field_magnify ,
					    config.inverse_x ,
					    config.inverse_y );
			break;

		case View_Config::View_Point::Ball:
			if ( controller.monitor_view() )
			{
				canvas.view_change
				  ( controller.monitor_view() -> ball.x() ,
				    controller.monitor_view() -> ball.y() ,
				    config.field_magnify ,
				    config.inverse_x ,
				    config.inverse_y );
			}
			break;

		case View_Config::View_Point::Player:
			// XXX
			break;
		}
	}


	//
	// Clear Field
	//
	canvas.clear_field();

	// if no snapshot, return with no drawing.
	if ( ! controller.snapshot() )
	{
		//
		// Update Field
		//
		canvas.update_field();

		return;
	}


	//
	// Draw Grid
	//
	if ( config.draw_grid )
	{
		canvas.draw_grid( config.grid_width );
	}

	//
	// Monitor View
	//
	if ( config.monitor_view && controller.monitor_view() )
	{
		canvas.draw_monitor_view(
		    *(controller.monitor_view()) , config );
	}


	//
	// Auto Kick Off: Count Down
	//
	if ( controller.auto_kick_off_mode()
	     && controller.live_mode()
	     && controller.monitor_view()
	     && controller.monitor_view() -> play_mode
		  == Monitor_View::Monitor_Play_Mode::Before_Kick_Off )
	{
		canvas.draw_auto_kick_off_count_down
			( controller.auto_kick_off_rest_second() );
	}


	//
	// Auto Drop Ball: Count Down
	//
	if ( controller.auto_drop_mode()
	     && controller.live_mode()
	     && controller.monitor_view()
	     && controller.monitor_view() -> play_mode
		  != Monitor_View::Monitor_Play_Mode::Before_Kick_Off )
	{
		if ( controller.auto_drop_rest_second()
		     <= View_Controller::AUTO_DROP_COUNT )
		{
			canvas.draw_auto_drop_count_down
				( controller.auto_drop_rest_second() );
		}
	}


	//
	// Offside Line
	//
	if ( config.offside_line && controller.monitor_view() )
	{
		canvas.draw_offside_line( *(controller.monitor_view()) ,
					  config );
	}


	//
	// Client Debug View
	//
	S_Side_LR	side_list[2];
	side_list[0] = S_Side_LR::Left_Side;
	side_list[1] = S_Side_LR::Right_Side;

	for ( int  s = 0  ;  s < 2  ;  s ++ )
	{
		for ( int  p = 1  ;  p <= MAX_PLAYER  ;  p ++ )
		{
			if ( ! controller.client_view( side_list[s] , p )
			  || ! (controller.client_view( side_list[s] , p )
				 -> snapshot() ) )
			{
				continue;
			}

			ref_count_ptr<const Debug_Client_Field_Recog>	recog
				 = controller.client_view( side_list[s] , p );

			Field_Recog_Interface	interface
						    ( recog -> snapshot() );

			const View_Config::Debug_View_Config &	c
				= config.debug_config( side_list[s] , p );

			// Debug Other Players
			if ( c.debug_players )
			{
				// Debug Teammate Player
				for ( int  i = 1  ;  i <= MAX_PLAYER  ;  i ++ )
				{
					if ( i == interface.self()
							    .player_number() )
					{
						continue;
					}

					if ( interface.teammate( i )
						    .coordinate().have_info() )
					{
						canvas.draw_user_debug_player
						 ( interface.teammate( i ) ,
						   interface.our_team()
								.side_lr() ,
						   false ,
						   config ,
						   (c.debug_comment ?
						    recog
						      -> teammate_comment(i)
						    : 0 ) );
					}
				}

				// Debug Opponent Player
				for ( int  i = 1  ;  i <= MAX_PLAYER  ;  i ++ )
				{
					if ( interface.opponent( i )
						    .coordinate().have_info() )
					{
						canvas.draw_user_debug_player
						 ( interface.opponent( i ) ,
						   interface.our_team()
								.side_lr() ,
						   false ,
						   config ,
						   (c.debug_comment ?
						    recog
						      -> opponent_comment(i)
						    : 0 ) );
					}
				}

				// Debug Unknown Player
				for ( size_t  i = 0  ;
				      i < interface.n_unknown_player()  ;
				      i ++ )
				{
					if ( interface.unknown_player( i )
						    .coordinate().have_info() )
					{
						canvas.draw_user_debug_player
						 ( interface
						     .unknown_player( i ) ,
						   interface.our_team()
								.side_lr() ,
						   false ,
						   config );
					}
				}
			}

			// Debug Self
			if ( c.debug_self
			  && interface.self().coordinate().have_info() )
			{
				canvas.draw_user_debug_player
					( interface.self() ,
					  interface.our_team().side_lr() ,
					  true ,
					  config );
			}

			// Debug Ball
			if ( c.debug_ball
			  && interface.ball().coordinate().have_info() )
			{
				canvas.draw_user_debug_ball
					( interface.ball() ,
					  interface.our_team().side_lr() ,
					  config ,
					  (c.debug_comment ?
					    recog -> ball_comment() : 0) );
			}
		}
	}


	//
	// Update Field
	//
	canvas.update_field();
}
