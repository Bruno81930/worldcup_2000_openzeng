#ifndef	   FIELD_VIEW_H_INCLUDED
#define	   FIELD_VIEW_H_INCLUDED

#include  <gtk--.h>
#include  "field_canvas.h"
#include  "view_controller.h"
#include  "view_config.h"
#include  "view_controll_panel.h"

class  Field_View : public Gtk::VBox
{
protected:
	View_Controller &		controller;
	View_Config &			config;
	View_Controll_Panel &		panel;

	Field_Canvas			canvas;

	View_Config::View_Point::Type	view_point_type;
	gdouble				canvas_magnify;
	D2_Vector			view_point_coordinate;
	SObject_Player_Identifier	view_point_player;

	bool				inverse_x;
	bool				inverse_y;

	bool				auto_adjust_magnify;

	D2_Vector			old_ball_coordinate;

public:
		 Field_View( View_Controller &  controller ,
			     View_Config &  config ,
			     View_Controll_Panel &  panel );

	virtual	~Field_View();

	virtual	void	display();

	virtual	void	config_changed();
};


#endif	/* FIELD_VIEW_H_INCLUDED */
