#ifndef	   QUIT_BUTTON_H_INCLUDED
#define	   QUIT_BUTTON_H_INCLUDED

// Author:		H. Shimora
// Last-Modified:	May  4 2000
// Created:		May  4 2000
// Version:		1.00

///-----------------------------------------------
/// Change Log:
///-----------------------------------------------
// version 1.00  May  4 2000    base version.
//
//


#include  <gtk--.h>

class  Quit_Button : public Gtk::Button
{
public:
		 Quit_Button()
			 : Gtk::Button() {}

		 Quit_Button( const std::string &  label )
			 : Gtk::Button( label ) {}

	virtual	~Quit_Button(){}

	virtual	void	clicked_impl()
	{
		Gtk::Main::quit();
	}
};


#endif	/* QUIT_BUTTON_H_INCLUDED */
