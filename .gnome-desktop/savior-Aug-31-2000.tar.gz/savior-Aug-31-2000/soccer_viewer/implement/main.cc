//
// Display part is based on soccermonitor provided by Itsuki Noda.
//

#include  "view_controller.h"
#include  "soccer_viewer.h"
#include  "view_controller_updater.h"
#include  "soccer_viwer_option_analyzer.h"
#include  "ref_count_ptr.h"
#include  "debugstream.h"
#include  <gtk--.h>
#include  <sys/types.h>
#include  <sys/time.h>
#include  <sys/resource.h>

int   main( int  argc ,  char  *argv[] )
{
	Debug_Stream::dbg.inhibit();

	Soccer_Viwer_Option_Analyzer	opt;

	if ( ! opt.analyse( argc , argv ) )
	{
		opt.usage();

		return(1);
	}
	else if ( opt.help() )
	{
		opt.usage();

		return(0);
	}

	View_Controller		controller( opt.server_hostname() ,
					    opt.server_port_number() ,
					    opt.debug_port_number() );

	Gtk::Main		gtk( &argc , &argv );

	controller.set_viewer( new Soccer_Viewer(controller) );
	controller.set_updater( new View_Controller_Updater(controller) );

	gtk.run();

	return( 0 );
}
