#include "soccer_viewer.h"

//
// Soccer_Viewer_Window
//
gint   Soccer_Viewer_Window::delete_event_impl( GdkEventAny * )
{
	Gtk::Main::quit();
	return( false );
}

Soccer_Viewer_Window::~Soccer_Viewer_Window()
{
}


//
// Soccer_Viewer
//
Soccer_Viewer::Soccer_Viewer( View_Controller &  c )
	: config() , controller( c ) ,
	  window() , controll_panel( c , config , *this ) ,
	  field( c , config , controll_panel ) , mode_line( c , config ) ,
	  text_field( c )
{
	// mode line
	vbox.pack_start( mode_line , false );

	// field
	vbox.pack_start( field );

	// text field
	vbox.pack_start( text_field );

	// controll panel
	vbox.pack_start( controll_panel , false );

	// vbox
	vbox.set_spacing( 3 );
	vbox.show();
	mode_line.show();
	field.show();
	controll_panel.show();


	// window
	window.add( vbox );
	window.set_title( "Soccer Viewer" );
	window.set_border_width( 4 );
	window.set_policy( /* allow_shrink = */ true ,
			   /* allow_grow   = */ true ,
			   /* auto_shrink  = */ true );
	window.show();
}

Soccer_Viewer::~Soccer_Viewer()
{
}

void   Soccer_Viewer::display()
{
	if ( ! window.is_realized() )
	{
		return;
	}

	if ( config.show_text_field )
	{
		text_field.show();
	}
	else
	{
		text_field.hide();
	}

	mode_line     .display();
	field         .display();
	text_field    .display();
	controll_panel.display();
}

void   Soccer_Viewer::config_changed()
{
	this -> display();
}
