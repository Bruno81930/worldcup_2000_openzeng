#ifndef	   SOCCER_VIEWER_H_INCLUDED
#define	   SOCCER_VIEWER_H_INCLUDED

// Author:		H. Shimora
// Last-Modified:	May 22 2000
// Created:		May 22 2000
// Version:		0.00

///-----------------------------------------------
/// Change Log:
///-----------------------------------------------
// version 0.00  May 22 2000    base version.
//
//

#include  "view_config.h"
#include  "view_controller.h"
#include  "view_controll_panel.h"
#include  "field_view.h"
#include  "game_info_mode_line.h"
#include  "text_field.h"
#include  "view_config.h"
#include  <gtk--.h>

class  Soccer_Viewer_Window : public Gtk::Window
{
public:
	virtual		~Soccer_Viewer_Window();
	virtual	gint	delete_event_impl( GdkEventAny * );
};


class  Soccer_Viewer : public Soccer_Viewer_Abstract
{
protected:
	View_Config			config;

	View_Controller &		controller;

	Soccer_Viewer_Window		window;
	Gtk::VBox			vbox;

	View_Controll_Panel		controll_panel;

	Field_View			field;

	Game_Info_Mode_Line		mode_line;

	Text_Field			text_field;

public:
		 Soccer_Viewer( View_Controller & );
	virtual	~Soccer_Viewer();

	virtual	void	display();
	virtual	void	config_changed();
};


#endif	/* SOCCER_VIEWER_H_INCLUDED */
