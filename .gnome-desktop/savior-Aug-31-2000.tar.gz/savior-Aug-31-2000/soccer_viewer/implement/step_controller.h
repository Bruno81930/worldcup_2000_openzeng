#ifndef	   STEP_CONTROLLER_H_INCLUDED
#define	   STEP_CONTROLLER_H_INCLUDED

// Author:		H. Shimora
// Last-Modified:	Jun  7 2000
// Created:		Jun  7 2000
// Version:		0.00

///-----------------------------------------------
/// Change Log:
///-----------------------------------------------
// version 0.00  Jun  7 2000    base version.
//
//

#include  "view_controller.h"
#include  <gtk--.h>

class  Step_Controller : public Gtk::HBox
{
protected:
	View_Controller &	view_controller;

	Gtk::Button		backward_fast_button;
	Gtk::Button		backward_button;
	Gtk::Button		backward_step_button;
	Gtk::Button		stop_button;
	Gtk::Button		forward_step_button;
	Gtk::Button		forward_button;
	Gtk::Button		forward_fast_button;

	Gtk::Button		live_log_button;

	Gtk::Entry		time_set_entry;

public:
		 Step_Controller( View_Controller &  view_controller );
	virtual	~Step_Controller();

	virtual	void	display();

	virtual	void	forward_fast();
	virtual	void	forward();
	virtual	void	forward_step();
	virtual	void	stop();
	virtual	void	backward_step();
	virtual	void	backward();
	virtual	void	backward_fast();

	virtual	void	live_log_toggle();

	virtual	void	time_set_entry_input();
};

#endif	/* STEP_CONTROLLER_H_INCLUDED */
