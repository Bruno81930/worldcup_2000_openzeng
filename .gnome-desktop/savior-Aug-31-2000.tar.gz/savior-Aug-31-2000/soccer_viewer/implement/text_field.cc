#include  "text_field.h"

Text_Field::Text_Field( const View_Controller &  c )
	: controller( c ) , audio_field() , command_field()
{
	this -> pack_start( audio_field );
	this -> pack_start( command_field );

	audio_field.show();
	command_field.show();
}

Text_Field::~Text_Field()
{
}

void   Text_Field::display()
{
}
