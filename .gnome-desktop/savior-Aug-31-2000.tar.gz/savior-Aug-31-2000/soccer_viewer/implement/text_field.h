#ifndef	   TEXT_FIELD_H_INCLUDED
#define	   TEXT_FIELD_H_INCLUDED

#include  <gtk--.h>
#include  "view_controller.h"

class  Text_Field : public Gtk::HBox
{
protected:
	const View_Controller &	controller;

	Gtk::Text		audio_field;
	Gtk::Text		command_field;

public:
		 Text_Field( const View_Controller &  c );
	virtual	~Text_Field();

	virtual	void	display();
};


#endif	/* TEXT_FIELD_H_INCLUDED */
