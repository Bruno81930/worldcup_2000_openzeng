#ifndef	   VIEW_CONTROLLER_UPDATER_H_INCLUDED
#define	   VIEW_CONTROLLER_UPDATER_H_INCLUDED

// Author:		H. Shimora
// Last-Modified:	May 21 2000
// Created:		May 21 2000
// Version:		0.00

///-----------------------------------------------
/// Change Log:
///-----------------------------------------------
// version 0.00  May 21 2000    base version.
//
//

#include  <gtk--.h>
#include  "view_controller.h"

class  View_Controller_Updater : public View_Controller_Updater_Abstract
{
protected:
	class  Gtk_View_Controller_Updater : public Gtk::Widget
	{
	protected:
		View_Controller &	controller;

	protected:
		static	void	update_view_controller_func
					( gpointer data ,
					  gint ,
					  GdkInputCondition )
		{
			static_cast<View_Controller *>(data) -> update();
		}

		gint	update_view_controller()
		{
			controller.update();

			return( true );
		}


	public:
		Gtk_View_Controller_Updater( View_Controller &  controller )
			: controller( controller )
		{
			for ( size_t  i = 0  ;
			      i < controller.input_list().size()  ;  i ++ )
			{
				gtk_input_add_full
					( static_cast<gint>
					  ( controller.input_list()[i] ) ,
					  static_cast<GdkInputCondition>
					  ( GDK_INPUT_READ
					    | GDK_INPUT_EXCEPTION ) ,
					  &Gtk_View_Controller_Updater
					     ::update_view_controller_func ,
					  static_cast<GtkCallbackMarshal>(0) ,
					  &controller ,
					  static_cast<GtkDestroyNotify>(0) );
			}

			Gtk::Main::timeout.connect
				( SigC::slot( this ,
					      &Gtk_View_Controller_Updater
					         ::update_view_controller ) ,
				  1000 /* msec */ );
		}

		void	add_timer( gint  timer )
		{
			Gtk::Main::timeout.connect
				( SigC::slot( this ,
					      &Gtk_View_Controller_Updater
					       ::timer_callback ) ,
				  timer /* msec */ );
		}

		gint	timer_callback()
		{
			gint	next_interval = controller.timed_out();

			if ( next_interval != 0 )
			{
				Gtk::Main::timeout.connect
				    ( SigC::slot( this ,
						  &Gtk_View_Controller_Updater
						  ::timer_callback ) ,
				      next_interval /* msec */ );
			}

			return( false );
		}
	};

protected:
	Gtk_View_Controller_Updater	updater;

public:
		 View_Controller_Updater( View_Controller &  controller )
			: updater( controller ) {}

	virtual	~View_Controller_Updater(){}

	virtual	void	add_timer( int  timer )
	{
		updater.add_timer( timer );
	}
};


#endif	/* VIEW_CONTROLLER_UPDATER_H_INCLUDED */
