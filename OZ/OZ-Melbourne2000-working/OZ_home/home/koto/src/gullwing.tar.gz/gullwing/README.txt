$BJ!0f=)%-%c%s%W;22C0JMh!"2?$bJQ$o$C$F$$$J$$(B gullwing $B$G$9!#(B

$B%3%s%Q%$%kJ}K!(B
% make

$B<B9TJ}K!(B
% cp hoge/server/server.conf .
% ./start.sh server_name team_name

$B:G=i$K%4!<%k%-!<%Q!<$H$7$F@\B3$r;n$_!"<:GT$9$k$H0lHL%W%l%$%d!<$H$7$F@\B3$7$^$9!#(B
soccerserver $B$r=*N;$5$;$k$H!"<+F0$G=*N;$7$^$9!#(B



$B$H$j$"$($:(B OZ $B;22C<T$N$_$X$N8x3+$K$7$^$9!#(B