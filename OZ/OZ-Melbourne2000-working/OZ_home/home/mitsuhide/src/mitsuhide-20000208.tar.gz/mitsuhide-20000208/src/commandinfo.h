double min_sin(double dir, double dir_error) ;
double max_sin(double dir, double dir_error) ;
double min_cos(double dir, double dir_error) ;
double max_cos(double dir, double dir_error) ;
