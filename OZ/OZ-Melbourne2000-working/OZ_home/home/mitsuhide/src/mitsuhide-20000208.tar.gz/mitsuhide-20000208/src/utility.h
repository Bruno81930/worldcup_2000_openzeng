#define square(x) pow((x), 2)

char* next_token(char* msg);
double normalize_angle(double dir);

