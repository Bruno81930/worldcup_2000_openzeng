#!/bin/csh

./Gemini -k $* > /dev/null &
sleep 1
./Gemini $* > /dev/null &
./Gemini $* > /dev/null &
./Gemini $* > /dev/null &
./Gemini $* > /dev/null &
./Gemini $* > /dev/null &
./Gemini $* > /dev/null &
./Gemini $* > /dev/null &
./Gemini $* > /dev/null &
./Gemini $* > /dev/null &
./Gemini $* > /dev/null &

